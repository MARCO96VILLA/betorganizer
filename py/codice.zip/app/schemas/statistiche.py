from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel

from app.models.enums import TipoRegola


class MetricheRead(BaseModel):
    numero_giocate: int
    profitto: Decimal
    giocato: Decimal
    yield_: Optional[Decimal] = None
    rendimento_capitale: Optional[Decimal] = None
    win_rate: Decimal
    quota_media: Decimal
    quota_media_ponderata: Decimal
    stake_medio: Decimal
    yield_visibile: bool
    stima_incerta: bool


class DrawdownRead(BaseModel):
    valore_assoluto: Decimal
    percentuale: Optional[Decimal]
    data_inizio: datetime
    data_fine: datetime


class SerieRead(BaseModel):
    max_vinte_consecutive: int
    max_perse_consecutive: int


class VoceBreakdownRead(BaseModel):
    chiave: str
    numero_giocate: int
    profitto: Decimal
    yield_: Optional[Decimal] = None


class BreakdownRead(BaseModel):
    sport: list[VoceBreakdownRead]
    bookmaker: list[VoceBreakdownRead]
    tipo_giocata: list[VoceBreakdownRead]
    fascia_quota: list[VoceBreakdownRead]
    giorno_settimana: list[VoceBreakdownRead]
    tag: list[VoceBreakdownRead]
    squadra: list[VoceBreakdownRead]
    campionato: list[VoceBreakdownRead]


class StatisticheRead(BaseModel):
    numero_giocate_regolate: int
    metriche: Optional[MetricheRead]
    drawdown: Optional[DrawdownRead]
    serie: SerieRead
    breakdown: BreakdownRead
    rendimenti: list[float]
    margine_atteso_casuale: Decimal


class CostoRegolaRead(BaseModel):
    tipo: TipoRegola
    profitto: Decimal


class AderenzaRead(BaseModel):
    numero_giocate: int
    numero_conformi: int
    punteggio: Optional[Decimal]
    costo_per_regola: list[CostoRegolaRead]
    metriche_conformi: Optional[MetricheRead]
    metriche_non_conformi: Optional[MetricheRead]
    rendimenti_conformi: list[float]
    rendimenti_non_conformi: list[float]
