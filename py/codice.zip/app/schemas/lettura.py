from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, Field

from app.schemas.giocate import ComponenteBetBuilder


class SelezioneLetta(BaseModel):
    sport: str
    competizione: Optional[str] = None
    squadra_casa: str
    squadra_trasferta: Optional[str] = None
    mercato: str
    esito_giocato: Optional[str] = None
    quota: Optional[Decimal] = None
    esito: str
    inizio_evento: Optional[datetime] = None
    risultato_evento: Optional[str] = None
    mercato_giocatore: bool = False
    testo_mercato: str = ""
    avvisi: list[str] = Field(default_factory=list)
    # bet builder: più mercati sulla stessa partita con una sola quota
    componenti: Optional[list[ComponenteBetBuilder]] = None


class SchedinaLetta(BaseModel):
    """Bozza letta da uno screenshot: da controllare e correggere prima di salvarla."""

    nome_file: str
    # se l'immagine non si è potuta leggere, `errore` spiega perché e gli altri campi sono vuoti
    errore: Optional[str] = None
    bookmaker: Optional[str] = None
    riferimento: Optional[str] = None
    piazzata_il: Optional[datetime] = None
    stake: Optional[Decimal] = None
    quota_totale: Optional[Decimal] = None
    vincita: Optional[Decimal] = None
    bonus_multipla_pct: Decimal = Decimal("0")
    stato: str = "in_corso"
    tags: list[str] = Field(default_factory=list)
    selezioni: list[SelezioneLetta] = Field(default_factory=list)
    avvisi: list[str] = Field(default_factory=list)
    duplicata: bool = False
    motivo_duplicata: Optional[str] = None


class LetturaRisposta(BaseModel):
    schedine: list[SchedinaLetta]
