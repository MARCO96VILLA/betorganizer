from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.models.enums import TipoMovimento


class BankrollRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    valuta: str
    colore: Optional[str]
    archiviato: bool
    creato_il: datetime


class BankrollCreate(BaseModel):
    nome: str
    valuta: str = "EUR"
    colore: Optional[str] = None


class BankrollAggiorna(BaseModel):
    nome: Optional[str] = None
    colore: Optional[str] = None
    archiviato: Optional[bool] = None


class SaldoContoRead(BaseModel):
    """Saldi di un singolo conto (bookmaker) all'interno del bankroll."""

    bookmaker: str
    saldo_liquido: Decimal
    capitale_in_gioco: Decimal
    capitale_da_regolare: Decimal
    giocate_da_regolare: int
    schedine_in_corso: int = 0
    # saldo disponibile se tutte le schedine in corso fossero vinte (stake già scalato dal disponibile)
    saldo_ipotetico: Decimal = Decimal("0")


class SaldiRead(BaseModel):
    saldo_liquido: Decimal
    # stake di tutte le giocate pendenti; di queste, `capitale_da_regolare` riguarda quelle le cui
    # partite sono tutte già concluse e attendono solo di essere regolate
    capitale_in_gioco: Decimal
    capitale_totale: Decimal
    capitale_da_regolare: Decimal = Decimal("0")
    giocate_da_regolare: int = 0
    schedine_in_corso: int = 0
    saldo_ipotetico: Decimal = Decimal("0")
    conti: list[SaldoContoRead] = []


class CondizioniBonusSchema(BaseModel):
    """Condizioni della promozione; i campi non indicati non vengono controllati."""

    selezioni_minime: Optional[int] = Field(default=None, ge=1)
    quota_minima_evento: Optional[Decimal] = Field(default=None, ge=1)
    quota_minima_totale: Optional[Decimal] = Field(default=None, ge=1)
    stake_minimo: Optional[Decimal] = Field(default=None, ge=0)


class MovimentoCreate(BaseModel):
    tipo: TipoMovimento
    importo: Decimal
    data: Optional[datetime] = None
    nota: Optional[str] = None
    bookmaker: Optional[str] = None
    scadenza: Optional[datetime] = None
    condizioni: Optional[CondizioniBonusSchema] = None

    @model_validator(mode="after")
    def valida_importo(self) -> "MovimentoCreate":
        if (
            self.tipo in (TipoMovimento.DEPOSITO, TipoMovimento.PRELIEVO, TipoMovimento.BONUS)
            and self.importo <= 0
        ):
            raise ValueError("Depositi, prelievi e bonus richiedono un importo maggiore di zero")
        if self.tipo == TipoMovimento.RETTIFICA and self.importo == 0:
            raise ValueError("Una rettifica non può avere importo zero")
        return self


class MovimentoRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    bankroll_id: int
    tipo: TipoMovimento
    importo: Decimal
    data: datetime
    nota: Optional[str]
    bookmaker: Optional[str] = None
    scadenza: Optional[datetime] = None
    condizioni: Optional[CondizioniBonusSchema] = None


class MovimentoAggiorna(BaseModel):
    """Correzione di un movimento: tipo e importo non si cambiano (si elimina e si ricrea)."""

    data: Optional[datetime] = None
    nota: Optional[str] = None
    bookmaker: Optional[str] = None
    scadenza: Optional[datetime] = None
    condizioni: Optional[CondizioniBonusSchema] = None


class AllineaSaldoRequest(BaseModel):
    bookmaker: str
    # saldo disponibile mostrato dal conto del bookmaker, senza le giocate ancora in corso
    saldo_reale: Decimal = Field(ge=0)


class AllineaSaldoRisposta(BaseModel):
    bookmaker: str
    saldo_liquido: Decimal
    rettifica: Decimal
    movimento_creato: bool
