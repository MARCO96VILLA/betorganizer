from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr


class RegistrazioneRequest(BaseModel):
    email: EmailStr
    password: str
    nome: str
    codice_invito: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UtenteRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: EmailStr
    nome: str
    creato_il: datetime
    fuso_orario: str
