from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict

from app.models.enums import TipoRegola


class RegolaCreate(BaseModel):
    tipo: TipoRegola
    valore: Any
    attiva: bool = True


class RegolaAggiorna(BaseModel):
    valore: Optional[Any] = None
    attiva: Optional[bool] = None


class RegolaRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    strategia_id: int
    tipo: TipoRegola
    valore: Any
    attiva: bool


class StrategiaCreate(BaseModel):
    bankroll_id: int
    nome: str
    regole: list[RegolaCreate] = []


class StrategiaAggiorna(BaseModel):
    nome: Optional[str] = None
    attiva: Optional[bool] = None


class StrategiaRead(BaseModel):
    id: int
    bankroll_id: int
    nome: str
    attiva: bool
    creata_il: datetime
    regole: list[RegolaRead]


class EsempioStrategiaRegola(BaseModel):
    tipo: TipoRegola
    valore: Any


class EsempioStrategia(BaseModel):
    chiave: str
    nome: str
    descrizione: str
    regole: list[EsempioStrategiaRegola]


class ClonaEsempioRequest(BaseModel):
    bankroll_id: int
    chiave: str
