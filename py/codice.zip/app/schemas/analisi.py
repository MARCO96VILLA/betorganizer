from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, Field

from app.schemas.giocate import SelezioneCreate


class VoceGambaRead(BaseModel):
    chiave: str
    gambe: int
    vinte: int
    tasso: Decimal
    ic_basso: Decimal
    ic_alto: Decimal
    probabilita_implicita: Decimal
    vinte_attese: Decimal
    quota_media: Decimal
    campione_ridotto: bool


class VoceGruppoRead(BaseModel):
    chiave: str
    numero: int
    vinte: int
    perse: int
    giocato: Decimal
    profitto: Decimal
    yield_: Optional[Decimal] = None


class PuntoCumulatoRead(BaseModel):
    data: datetime
    giocata_id: int
    profitto: Decimal
    cumulato: Decimal


class GambaFallitaRead(BaseModel):
    squadra_casa: str
    squadra_trasferta: Optional[str]
    mercato: str
    esito_giocato: Optional[str]
    quota: Decimal


class QuasiVincitaRead(BaseModel):
    giocata_id: int
    stake: Decimal
    mancato_ritorno: Decimal
    gambe: int
    gamba_fallita: GambaFallitaRead


class FamigliaFallitaRead(BaseModel):
    famiglia: str
    conteggio: int


class QuasiVinciteRead(BaseModel):
    multiple_perse: int
    perse_per_una_gamba: int
    stake_perso_per_una_gamba: Decimal
    mancato_ritorno: Decimal
    famiglie_gamba_fallita: list[FamigliaFallitaRead]
    elenco: list[QuasiVincitaRead]


class EsposizioneEventoRead(BaseModel):
    evento: str
    data: Optional[str]
    giocate: int
    stake_totale: Decimal
    giocate_pendenti: int
    stake_pendente: Decimal
    profitto_regolato: Decimal


class VinteAtteseRead(BaseModel):
    giocate: int
    vinte: int
    vinte_attese: Decimal


class ValoreBonusRead(BaseModel):
    giocate_vinte_con_bonus: int
    bonus_incassato: Decimal


class AnalisiRead(BaseModel):
    giocate_regolate: int
    gambe_valutate: int
    # a livello di gamba (selezione)
    per_famiglia: list[VoceGambaRead]
    per_mercato: list[VoceGambaRead]
    per_tipo_mercato: list[VoceGambaRead]
    per_squadra_coinvolta: list[VoceGambaRead]
    per_squadra_puntata: list[VoceGambaRead]
    per_competizione: list[VoceGambaRead]
    per_sport: list[VoceGambaRead]
    per_fascia_quota_gamba: list[VoceGambaRead]
    # a livello di giocata
    per_numero_gambe: list[VoceGruppoRead]
    per_fascia_oraria: list[VoceGruppoRead]
    per_giorno_settimana: list[VoceGruppoRead]
    per_anticipo: list[VoceGruppoRead]
    per_fascia_stake: list[VoceGruppoRead]
    per_bookmaker: list[VoceGruppoRead]
    per_mese: list[VoceGruppoRead]
    per_giorno: list[VoceGruppoRead]
    serie_cumulata: list[PuntoCumulatoRead]
    vinte_attese: VinteAtteseRead
    quasi_vincite: QuasiVinciteRead
    esposizione_eventi: list[EsposizioneEventoRead]
    bonus: ValoreBonusRead


# --- prima di giocare


class BozzaGiocata(BaseModel):
    """La schedina che si sta per giocare, anche incompleta (lo stake è facoltativo)."""

    bankroll_id: int
    bookmaker: Optional[str] = None
    stake: Optional[Decimal] = Field(default=None, gt=0)
    bonus_multipla_pct: Decimal = Field(default=Decimal("0"), ge=0, le=200)
    selezioni: list[SelezioneCreate] = Field(min_length=1, max_length=20)


class SelezioneBozzaRead(BaseModel):
    famiglia: str
    fascia_quota: str
    quota: Decimal
    probabilita_implicita: Decimal
    storico_famiglia: Optional[VoceGambaRead]
    storico_fascia: Optional[VoceGambaRead]


class SovrapposizioneRead(BaseModel):
    giocata_id: int
    stake: Decimal
    evento: str


class RequisitoRead(BaseModel):
    descrizione: str
    soddisfatto: bool


class BonusBozzaRead(BaseModel):
    movimento_id: int
    importo: Decimal
    bookmaker: Optional[str]
    scadenza: Optional[datetime]
    giorni_rimanenti: Optional[int]
    requisiti: list[RequisitoRead]
    rispettati: bool


class AnalisiBozzaRead(BaseModel):
    numero_giocate: int
    quota_totale: Decimal
    probabilita_pareggio: Decimal
    margine_ipotetico: Decimal
    ritorno_atteso_per_euro: Decimal
    probabilita_dallo_storico: Optional[Decimal]
    ritorno_atteso_storico: Optional[Decimal]
    selezioni: list[SelezioneBozzaRead]
    sovrapposizioni: list[SovrapposizioneRead]
    bonus: list[BonusBozzaRead]
    # quante giocate dello storico alimentano le stime e quante vengono da screenshot (campione parziale)
    giocate_storico: int
    giocate_storico_da_screenshot: int
