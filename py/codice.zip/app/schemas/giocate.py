from datetime import datetime
from decimal import Decimal
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import EsitoSelezione, StatoGiocata, TipoGiocata


class ComponenteBetBuilder(BaseModel):
    """Un mercato di un bet builder: la partita e la quota sono quelle della selezione che lo contiene."""

    mercato: str = Field(min_length=1)
    esito_giocato: Optional[str] = None
    mercato_giocatore: bool = False


class SelezioneCreate(BaseModel):
    sport: str
    competizione: Optional[str] = None
    squadra_casa: str
    squadra_trasferta: Optional[str] = None
    mercato: str
    esito_giocato: Optional[str] = None
    quota: Decimal = Field(ge=Decimal("1.01"))
    inizio_evento: Optional[datetime] = None
    risultato_evento: Optional[str] = None
    mercato_giocatore: bool = False
    # bet builder: almeno due mercati sulla stessa partita, una sola quota
    componenti: Optional[list[ComponenteBetBuilder]] = Field(default=None, min_length=2, max_length=12)


class SistemaCreate(BaseModel):
    combinazioni_attive: list[int]
    stake_per_combinazione: Decimal = Field(gt=0)

    @field_validator("combinazioni_attive")
    @classmethod
    def non_vuoto(cls, valore: list[int]) -> list[int]:
        if not valore:
            raise ValueError("combinazioni_attive non può essere vuoto")
        return valore


class GiocataCreate(BaseModel):
    bankroll_id: int
    bookmaker: str
    # per singola/multipla è lo stake della giocata; per un sistema è ignorato e ricalcolato
    # lato server come stake_per_combinazione × numero linee (sezione 5.2).
    stake: Optional[Decimal] = Field(default=None, gt=0)
    e_free_bet: bool = False
    bonus_multipla_pct: Decimal = Field(default=Decimal("0"), ge=0, le=200)
    piazzata_il: Optional[datetime] = None
    note: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    selezioni: list[SelezioneCreate] = Field(min_length=1, max_length=20)
    sistema: Optional[SistemaCreate] = None

    @model_validator(mode="after")
    def stake_obbligatorio_se_non_sistema(self) -> "GiocataCreate":
        if self.sistema is None and self.stake is None:
            raise ValueError("stake è obbligatorio per singola e multipla")
        return self


class GiocataAggiorna(BaseModel):
    bookmaker: Optional[str] = None
    stake: Optional[Decimal] = Field(default=None, gt=0)
    note: Optional[str] = None
    tags: Optional[list[str]] = None
    piazzata_il: Optional[datetime] = None


class RegolaRapidaRequest(BaseModel):
    esito: EsitoSelezione

    @field_validator("esito")
    @classmethod
    def solo_esiti_uniformi(cls, valore: EsitoSelezione) -> EsitoSelezione:
        consentiti = {EsitoSelezione.VINTA, EsitoSelezione.PERSA, EsitoSelezione.ANNULLATA}
        if valore not in consentiti:
            raise ValueError("La regolazione rapida accetta solo vinta, persa o annullata")
        return valore


class RegolaSelezioneRequest(BaseModel):
    # "pendente" serve a correggere un esito registrato per errore: la giocata torna in corso
    esito: EsitoSelezione


class CashoutTotaleRequest(BaseModel):
    cashout_importo: Decimal = Field(gt=0)


class CashoutParzialeRequest(BaseModel):
    cashout_importo: Decimal = Field(gt=0)
    cashout_stake_liberato: Decimal = Field(gt=0)


class SelezioneRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    ordine: int
    sport: str
    competizione: Optional[str]
    squadra_casa: str
    squadra_trasferta: Optional[str]
    mercato: str
    esito_giocato: Optional[str]
    quota: Decimal
    esito: EsitoSelezione
    inizio_evento: Optional[datetime] = None
    risultato_evento: Optional[str] = None
    mercato_giocatore: bool = False
    componenti: Optional[list[ComponenteBetBuilder]] = None
    bet_builder: bool = False
    # famiglia del mercato (Multigol, Cartellini, ...), derivata lato server in domain.analytics
    famiglia: str = ""
    # True se la selezione è ancora pendente ma la partita è finita da tempo (attende solo l'esito)
    evento_concluso: bool = False
    # per le selezioni pendenti: "futuro", "live" (partita in corso) o "concluso"; altrimenti None
    fase_evento: Optional[str] = None


class SistemaRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    combinazioni_attive: list[int]
    stake_per_combinazione: Decimal


class GiocataRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    bankroll_id: int
    tipo_giocata: TipoGiocata
    bookmaker: str
    stake: Decimal
    quota_totale: Optional[Decimal]
    e_free_bet: bool
    bonus_multipla_pct: Decimal = Decimal("0")
    stato: StatoGiocata
    piazzata_il: datetime
    regolata_il: Optional[datetime]
    ritorno_lordo: Decimal
    profitto: Decimal
    cashout_importo: Optional[Decimal]
    cashout_stake_liberato: Optional[Decimal]
    note: Optional[str]
    tags: list[str]
    riferimento_esterno: Optional[str] = None
    orario_approssimato: bool = False
    # pendente con tutte le partite ancora da regolare già concluse: non è più "in gioco"
    da_regolare: bool = False
    # per le giocate pendenti: "da_giocare", "in_corso" o "da_regolare"; altrimenti None
    fase: Optional[str] = None
    regole_violate: list[Any] = []
    selezioni: list[SelezioneRead]
    sistema: Optional[SistemaRead] = None


# --- importazione di giocate già regolate (storico) ----------------------------------------


class SelezioneImporta(SelezioneCreate):
    esito: EsitoSelezione = EsitoSelezione.PENDENTE


class GiocataImporta(BaseModel):
    # identificativo stabile nel file di origine: una seconda importazione lo riconosce e salta la giocata
    riferimento: str = Field(min_length=1, max_length=120)
    bookmaker: str
    stake: Decimal = Field(gt=0)
    piazzata_il: datetime
    orario_approssimato: bool = False
    bonus_multipla_pct: Decimal = Field(default=Decimal("0"), ge=0, le=200)
    e_free_bet: bool = False
    regolata_il: Optional[datetime] = None
    # vincita lorda riportata dal bookmaker, solo per segnalare differenze con il ricalcolo
    vincita_dichiarata: Optional[Decimal] = None
    note: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    selezioni: list[SelezioneImporta] = Field(min_length=1, max_length=20)


class ImportaRequest(BaseModel):
    bankroll_id: int
    # gli orari nel file sono ora italiana (Europe/Rome), non UTC
    giocate: list[GiocataImporta] = Field(min_length=1, max_length=500)


class DiscrepanzaImporta(BaseModel):
    riferimento: str
    ritorno_calcolato: Decimal
    ritorno_dichiarato: Decimal


class ImportaRisposta(BaseModel):
    importate: int
    saltate_duplicate: int
    regolate: int
    pendenti: int
    discrepanze: list[DiscrepanzaImporta]
