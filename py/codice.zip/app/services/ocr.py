"""Lettura del testo da uno screenshot, tutta in locale: Pillow per preparare l'immagine, Tesseract per leggerla.

Nessun dato esce dal server: Tesseract è un programma installato nel container (vedi Dockerfile).
Il risultato è una lista di righe di testo; dove nella riga c'è un grande spazio orizzontale (per Eplay24, tra
l'etichetta del mercato e il riquadro rosso con scelta e quota) si inserisce un carattere di tabulazione, che il
parser (`domain/lettura_schedina.py`) usa per separare le due parti.
"""

from __future__ import annotations

import io
import json
import shutil
import statistics
import subprocess
from collections import defaultdict
from contextvars import ContextVar, Token

from PIL import Image, ImageChops, ImageOps, ImageStat, UnidentifiedImageError

# difesa da immagini enormi (una foto da 100 megapixel non è uno screenshot)
Image.MAX_IMAGE_PIXELS = 40_000_000

LARGHEZZA_MASSIMA = 4000
LATO_MINIMO = 200
SOGLIA_SCURO = 110
FATTORE_INGRANDIMENTO = 2.0
GAMMA = 1.0
GAMMA_ALTERNATIVA = 2.0  # per il secondo tentativo, vedi services/lettura_screenshot.py
SPAZIO_RIGA = 0.8  # salto verticale tra due righe, in altezze di riga, oltre il quale si inserisce una riga vuota
SPAZIO_COLONNA = 1.9  # spazio tra due parole, in altezze di riga, oltre il quale si separa con una tabulazione
TIMEOUT_SECONDI = 60


class ErroreLettura(Exception):
    """L'immagine non si può leggere; il messaggio è pronto da mostrare all'utente."""


class OcrNonDisponibile(Exception):
    """Tesseract non è installato sul server."""


class DaEseguire(Exception):
    """Il motore OCR è fuori da Python (tesseract.js nel browser) e non ha ancora il testo di questa immagine.

    Non è un errore: è il primo tempo del protocollo descritto in `pwa/ocr_browser.py`. Chi chiama non deve
    catturarla (il router la lascia passare): il gestore installato dalla versione locale la trasforma in una risposta
    HTTP che chiede a JavaScript di leggere `png` e di ripetere la richiesta con il testo ottenuto.
    """

    def __init__(self, chiave: str, png: bytes, gamma: float):
        super().__init__(f"Lettura da eseguire ({chiave})")
        self.chiave = chiave
        self.png = png
        self.gamma = gamma


# testi già letti fuori da Python per la richiesta in corso: {chiave: TSV}. Lo imposta il router a ogni richiesta.
_letture_esterne: ContextVar[dict[str, str]] = ContextVar("letture_esterne", default={})


def imposta_letture_esterne(testo_json: str | None) -> Token:
    """Registra i testi OCR che il client ha già ottenuto (JSON `{chiave: tsv}`); un valore non valido si ignora."""
    letture: dict[str, str] = {}
    if testo_json:
        try:
            dati = json.loads(testo_json)
        except ValueError:
            dati = None
        if isinstance(dati, dict):
            letture = {k: v for k, v in dati.items() if isinstance(k, str) and isinstance(v, str)}
    return _letture_esterne.set(letture)


def ripristina_letture_esterne(token: Token) -> None:
    _letture_esterne.reset(token)


def letture_esterne() -> dict[str, str]:
    return _letture_esterne.get()


def tesseract_disponibile() -> bool:
    """Il motore OCR in uso può leggere (sul server: Tesseract è installato; nel browser: sempre sì)."""
    return _motore.disponibile()


def prepara_immagine(contenuto: bytes, gamma: float = GAMMA) -> Image.Image:
    """Scala di grigi con il canale più scuro (il testo bianco su sfondo colorato resta leggibile),
    negativo se il tema è scuro, ingrandimento 2x e contrasto automatico.

    Con `gamma` > 1 i toni medi si scuriscono: serve per il grigio chiaro su fondo chiaro (campionato e orario
    nelle schede Betsson), che con la preparazione normale Tesseract a volte salta.
    """
    try:
        immagine = Image.open(io.BytesIO(contenuto))
        immagine.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as errore:
        raise ErroreLettura("Il file non è un'immagine leggibile (usa uno screenshot JPG o PNG).") from errore
    if min(immagine.size) < LATO_MINIMO or max(immagine.size) > LARGHEZZA_MASSIMA:
        raise ErroreLettura("L'immagine è troppo piccola o troppo grande per essere letta.")

    rgb = ImageOps.exif_transpose(immagine).convert("RGB")
    rosso, verde, blu = rgb.split()
    grigio = ImageChops.darker(ImageChops.darker(rosso, verde), blu)
    if ImageStat.Stat(rgb.convert("L")).mean[0] < SOGLIA_SCURO:
        grigio = ImageOps.invert(grigio)
    grigio = grigio.resize(
        (int(grigio.width * FATTORE_INGRANDIMENTO), int(grigio.height * FATTORE_INGRANDIMENTO)), Image.LANCZOS
    )
    contrastato = ImageOps.autocontrast(grigio, cutoff=1)
    if gamma == 1.0:
        return contrastato
    return contrastato.point(lambda p: int(255 * (p / 255) ** gamma))


def righe_da_tsv(tsv: str) -> list[str]:
    """Righe di testo dall'output TSV di Tesseract, con una tabulazione dove c'è un grande spazio."""
    parole: dict[tuple[int, int, int], list[tuple[int, int, int, int, str]]] = defaultdict(list)
    ordine: list[tuple[int, int, int]] = []
    for riga in tsv.splitlines()[1:]:
        campi = riga.split("\t")
        if len(campi) < 12 or campi[0] != "5" or not campi[11].strip():
            continue
        chiave = (int(campi[2]), int(campi[3]), int(campi[4]))
        if chiave not in parole:
            ordine.append(chiave)
        parole[chiave].append((int(campi[6]), int(campi[8]), int(campi[9]), int(campi[7]), campi[11].strip()))

    righe: list[str] = []
    estremi: list[tuple[int, int]] = []  # (alto, basso) di ogni riga
    for chiave in ordine:
        elementi = sorted(parole[chiave])
        altezza = statistics.median(h for _, _, h, _, _ in elementi)
        pezzi = [elementi[0][4]]
        for (sinistra_prec, larghezza_prec, _, _, _), (sinistra, _, _, _, testo) in zip(elementi, elementi[1:]):
            spazio = sinistra - (sinistra_prec + larghezza_prec)
            pezzi.append("\t" if spazio > SPAZIO_COLONNA * altezza else " ")
            pezzi.append(testo)
        righe.append("".join(pezzi))
        estremi.append((min(t for _, _, _, t, _ in elementi), max(t + h for _, _, h, t, _ in elementi)))

    if len(righe) < 2:
        return righe
    altezza_tipica = statistics.median(basso - alto for alto, basso in estremi)
    con_vuote = [righe[0]]
    for (_, basso_prec), (alto, _), riga in zip(estremi, estremi[1:], righe[1:]):
        if alto - basso_prec > SPAZIO_RIGA * altezza_tipica:
            con_vuote.append("")
        con_vuote.append(riga)
    return con_vuote


def png_preparato(contenuto: bytes, gamma: float = GAMMA) -> bytes:
    """Immagine preparata (vedi `prepara_immagine`) codificata in PNG, pronta per il motore OCR."""
    buffer = io.BytesIO()
    prepara_immagine(contenuto, gamma).save(buffer, format="PNG")
    return buffer.getvalue()


class MotoreOcr:
    """Chi trasforma uno screenshot in TSV di Tesseract. Sul server è Tesseract (sotto); nel browser, tesseract.js
    con il protocollo a due tempi di `pwa/ocr_browser.py`. Tutto il resto (preparazione, righe, parser, secondo
    tentativo) è lo stesso nei due ambienti."""

    def disponibile(self) -> bool:
        raise NotImplementedError

    def tsv(self, contenuto: bytes, gamma: float) -> str:
        """TSV di Tesseract (`--psm 6 tsv`) per lo screenshot `contenuto` preparato con `gamma`."""
        raise NotImplementedError


class MotoreTesseract(MotoreOcr):
    """Il programma `tesseract` installato nel container."""

    def disponibile(self) -> bool:
        return shutil.which("tesseract") is not None

    def tsv(self, contenuto: bytes, gamma: float) -> str:
        png = png_preparato(contenuto, gamma)
        try:
            esito = subprocess.run(
                ["tesseract", "stdin", "stdout", "-l", "ita", "--psm", "6", "tsv"],
                input=png,
                capture_output=True,
                timeout=TIMEOUT_SECONDI,
                check=True,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as errore:
            raise ErroreLettura("Non sono riuscito a leggere il testo dell'immagine.") from errore
        return esito.stdout.decode("utf-8", errors="replace")


_motore: MotoreOcr = MotoreTesseract()


def imposta_motore(motore: MotoreOcr) -> MotoreOcr:
    """Sostituisce il motore OCR (la versione locale installa quello del browser); restituisce il precedente."""
    global _motore
    precedente, _motore = _motore, motore
    return precedente


def leggi_righe(contenuto: bytes, gamma: float = GAMMA) -> list[str]:
    """Righe di testo di uno screenshot (bytes di un JPG/PNG)."""
    if not tesseract_disponibile():
        raise OcrNonDisponibile("La lettura degli screenshot non è disponibile su questo server.")
    return righe_da_tsv(_motore.tsv(contenuto, gamma))
