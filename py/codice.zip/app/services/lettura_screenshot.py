"""Da uno screenshot a una bozza di schedina: OCR + parser, con un secondo tentativo se la prima lettura ha dubbi."""

from app.domain.lettura_schedina import (
    BozzaSchedina,
    leggi_schedina,
    scegli_lettura,
    vale_un_secondo_tentativo,
)
from app.services import ocr


def leggi_bozza(contenuto: bytes) -> BozzaSchedina:
    """Legge uno screenshot. Se la prima lettura ha avvisi (giocate o intestazioni mancanti), rilegge l'immagine con i
    toni medi più scuri e tiene la lettura migliore: il testo grigio chiaro delle schede Betsson, ad esempio,
    con la preparazione normale viene saltato a volte.

    Solleva `ocr.ErroreLettura` se l'immagine non è leggibile, `ocr.OcrNonDisponibile` se manca Tesseract.
    """
    bozza = leggi_schedina(ocr.leggi_righe(contenuto))
    if vale_un_secondo_tentativo(bozza):
        try:
            alternativa = leggi_schedina(ocr.leggi_righe(contenuto, gamma=ocr.GAMMA_ALTERNATIVA))
        except ocr.ErroreLettura:
            return bozza
        return scegli_lettura(bozza, alternativa)
    return bozza
