"""Esportazione dei dati dell'utente: CSV (per Excel italiano) ed Excel con tre fogli. Serve da copia di sicurezza."""

import csv
import io
from datetime import datetime
from decimal import Decimal
from typing import Any, Iterable, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from openpyxl import Workbook
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.domain.tempo import da_utc_a_locale
from app.models import Bankroll, Giocata, MovimentoBankroll, Selezione, Utente
from pwa.persistenza import ErroreBackup, crea_backup_da_connessione

router = APIRouter(prefix="/api/esporta", tags=["esporta"])

INTESTAZIONI_SCHEDINE = [
    "Id", "Piazzata il", "Conto", "Tipo", "Puntata", "Quota totale", "Stato", "Ritorno", "Profitto",
    "Bonus multipla %", "Free bet", "Regolata il", "Numero giocate", "Tag", "Note",
]
INTESTAZIONI_GIOCATE = [
    "Id schedina", "Evento", "Competizione", "Sport", "Mercato", "Scelta", "Quota", "Esito", "Inizio partita",
    "Risultato", "Bet builder",
]
INTESTAZIONI_MOVIMENTI = ["Data", "Tipo", "Conto", "Importo", "Nota", "Scade il"]


def _bankroll_utente(bankroll_id: int, utente: Utente, session: Session) -> Bankroll:
    bankroll = session.get(Bankroll, bankroll_id)
    if bankroll is None or bankroll.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankroll non trovato")
    return bankroll


def _quando(valore: Optional[datetime]) -> str:
    """Istante UTC del database -> 'GG/MM/AAAA HH:MM' in ora italiana."""
    return da_utc_a_locale(valore).strftime("%d/%m/%Y %H:%M") if valore else ""


def _numero(valore: Optional[Decimal]) -> Optional[Decimal]:
    return None if valore is None else Decimal(valore)


def _righe_schedine(bankroll_id: int, utente: Utente, session: Session) -> list[list[Any]]:
    giocate = session.exec(
        select(Giocata)
        .where(Giocata.bankroll_id == bankroll_id, Giocata.utente_id == utente.id)
        .order_by(Giocata.piazzata_il)
    ).all()
    numero_selezioni: dict[int, int] = {}
    if giocate:
        for s in session.exec(select(Selezione).where(Selezione.giocata_id.in_([g.id for g in giocate]))).all():
            numero_selezioni[s.giocata_id] = numero_selezioni.get(s.giocata_id, 0) + 1
    return [
        [
            g.id, _quando(g.piazzata_il), g.bookmaker, g.tipo_giocata.value, _numero(g.stake),
            _numero(g.quota_totale), g.stato.value, _numero(g.ritorno_lordo), _numero(g.profitto),
            _numero(g.bonus_multipla_pct), "sì" if g.e_free_bet else "no", _quando(g.regolata_il),
            numero_selezioni.get(g.id, 0), ", ".join(g.tags or []), g.note or "",
        ]
        for g in giocate
    ]


def _righe_giocate(bankroll_id: int, utente: Utente, session: Session) -> list[list[Any]]:
    giocate = session.exec(
        select(Giocata)
        .where(Giocata.bankroll_id == bankroll_id, Giocata.utente_id == utente.id)
        .order_by(Giocata.piazzata_il)
    ).all()
    righe = []
    for g in giocate:
        selezioni = session.exec(
            select(Selezione).where(Selezione.giocata_id == g.id).order_by(Selezione.ordine)
        ).all()
        for s in selezioni:
            evento = f"{s.squadra_casa} - {s.squadra_trasferta}" if s.squadra_trasferta else s.squadra_casa
            righe.append([
                g.id, evento, s.competizione or "", s.sport, s.mercato, s.esito_giocato or "", _numero(s.quota),
                s.esito.value, _quando(s.inizio_evento), s.risultato_evento or "", "sì" if s.bet_builder else "no",
            ])
    return righe


def _righe_movimenti(bankroll_id: int, session: Session) -> list[list[Any]]:
    movimenti = session.exec(
        select(MovimentoBankroll).where(MovimentoBankroll.bankroll_id == bankroll_id).order_by(MovimentoBankroll.data)
    ).all()
    return [
        [_quando(m.data), m.tipo.value, m.bookmaker or "", _numero(m.importo), m.nota or "", _quando(m.scadenza)]
        for m in movimenti
    ]


def _csv(intestazioni: list[str], righe: Iterable[list[Any]]) -> Response:
    """CSV pensato per Excel in italiano: separatore ';', decimale ',', UTF-8 con BOM."""
    buffer = io.StringIO()
    scrittore = csv.writer(buffer, delimiter=";", lineterminator="\r\n")
    scrittore.writerow(intestazioni)
    for riga in righe:
        scrittore.writerow(["" if c is None else (str(c).replace(".", ",") if isinstance(c, Decimal) else c) for c in riga])
    return Response(content="﻿" + buffer.getvalue(), media_type="text/csv; charset=utf-8")


def _allegato(risposta: Response, nome: str) -> Response:
    risposta.headers["Content-Disposition"] = f'attachment; filename="{nome}"'
    return risposta


@router.get("/schedine.csv")
def esporta_schedine_csv(
    bankroll_id: int = Query(...),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    _bankroll_utente(bankroll_id, utente, session)
    return _allegato(_csv(INTESTAZIONI_SCHEDINE, _righe_schedine(bankroll_id, utente, session)), "schedine.csv")


@router.get("/giocate.csv")
def esporta_giocate_csv(
    bankroll_id: int = Query(...),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    _bankroll_utente(bankroll_id, utente, session)
    return _allegato(_csv(INTESTAZIONI_GIOCATE, _righe_giocate(bankroll_id, utente, session)), "giocate.csv")


@router.get("/movimenti.csv")
def esporta_movimenti_csv(
    bankroll_id: int = Query(...),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    _bankroll_utente(bankroll_id, utente, session)
    return _allegato(_csv(INTESTAZIONI_MOVIMENTI, _righe_movimenti(bankroll_id, session)), "movimenti.csv")


@router.get("/dati.xlsx")
def esporta_excel(
    bankroll_id: int = Query(...),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    _bankroll_utente(bankroll_id, utente, session)
    cartella = Workbook()
    fogli = [
        ("Schedine", INTESTAZIONI_SCHEDINE, _righe_schedine(bankroll_id, utente, session)),
        ("Giocate", INTESTAZIONI_GIOCATE, _righe_giocate(bankroll_id, utente, session)),
        ("Movimenti", INTESTAZIONI_MOVIMENTI, _righe_movimenti(bankroll_id, session)),
    ]
    cartella.remove(cartella.active)
    for nome, intestazioni, righe in fogli:
        foglio = cartella.create_sheet(nome)
        foglio.append(intestazioni)
        for riga in righe:
            foglio.append([float(c) if isinstance(c, Decimal) else c for c in riga])
        foglio.freeze_panes = "A2"
    uscita = io.BytesIO()
    cartella.save(uscita)
    risposta = Response(
        content=uscita.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    return _allegato(risposta, "bet-tracker.xlsx")


@router.get("/backup")
def esporta_backup(
    bankroll_id: Optional[int] = Query(None),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    """File `.bettracker` con TUTTI i dati dell'utente collegato (e di nessun altro), da importare nella versione locale."""
    if bankroll_id is not None:
        _bankroll_utente(bankroll_id, utente, session)
    # la sessione ha già una transazione aperta: la copia legge dalla stessa connessione
    connessione = session.connection().connection.driver_connection
    try:
        dati = crea_backup_da_connessione(connessione, {"origine": "server"}, solo_utente_id=utente.id)
    except ErroreBackup as errore:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=errore.messaggio)
    return _allegato(Response(content=dati, media_type="application/octet-stream"), "bet-tracker.bettracker")
