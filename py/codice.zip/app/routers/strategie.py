from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.models import Bankroll, Regola, Strategia, Utente
from app.models.enums import TipoRegola
from app.schemas.strategie import (
    ClonaEsempioRequest,
    EsempioStrategia,
    EsempioStrategiaRegola,
    RegolaAggiorna,
    RegolaCreate,
    RegolaRead,
    StrategiaAggiorna,
    StrategiaCreate,
    StrategiaRead,
)

router = APIRouter(prefix="/api/strategie", tags=["strategie"])


ESEMPI: dict[str, EsempioStrategia] = {
    "flat_staking": EsempioStrategia(
        chiave="flat_staking",
        nome="Flat Staking",
        descrizione="Stake sempre uguale, una piccola percentuale fissa del capitale.",
        regole=[EsempioStrategiaRegola(tipo=TipoRegola.STAKE_MASSIMO_PERCENTUALE, valore="0.01")],
    ),
    "kelly_frazionario": EsempioStrategia(
        chiave="kelly_frazionario",
        nome="Kelly Frazionario",
        descrizione="Stake proporzionale al vantaggio percepito, con un tetto prudente sul capitale.",
        regole=[EsempioStrategiaRegola(tipo=TipoRegola.STAKE_MASSIMO_PERCENTUALE, valore="0.05")],
    ),
    "value_betting": EsempioStrategia(
        chiave="value_betting",
        nome="Value Betting",
        descrizione="Solo quote con valore percepito sopra 1.80, stake contenuto al 2% del capitale.",
        regole=[
            EsempioStrategiaRegola(tipo=TipoRegola.QUOTA_MINIMA, valore="1.80"),
            EsempioStrategiaRegola(tipo=TipoRegola.STAKE_MASSIMO_PERCENTUALE, valore="0.02"),
        ],
    ),
    "specialista": EsempioStrategia(
        chiave="specialista",
        nome="Specialista",
        descrizione="Un solo sport ammesso. Personalizza l'elenco dopo la clonazione.",
        regole=[EsempioStrategiaRegola(tipo=TipoRegola.SPORT_AMMESSI, valore=[])],
    ),
}


def _get_bankroll_utente(bankroll_id: int, utente: Utente, session: Session) -> Bankroll:
    bankroll = session.get(Bankroll, bankroll_id)
    if bankroll is None or bankroll.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankroll non trovato")
    return bankroll


def _get_strategia_utente(strategia_id: int, utente: Utente, session: Session) -> Strategia:
    strategia = session.get(Strategia, strategia_id)
    if strategia is None or strategia.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Strategia non trovata")
    return strategia


def _get_regola_utente(regola_id: int, utente: Utente, session: Session) -> Regola:
    regola = session.get(Regola, regola_id)
    if regola is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Regola non trovata")
    strategia = session.get(Strategia, regola.strategia_id)
    if strategia is None or strategia.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Regola non trovata")
    return regola


def _regole_di(strategia_id: int, session: Session) -> list[Regola]:
    return list(session.exec(select(Regola).where(Regola.strategia_id == strategia_id)))


def _a_strategia_read(strategia: Strategia, regole: list[Regola]) -> StrategiaRead:
    return StrategiaRead(
        id=strategia.id,
        bankroll_id=strategia.bankroll_id,
        nome=strategia.nome,
        attiva=strategia.attiva,
        creata_il=strategia.creata_il,
        regole=[RegolaRead.model_validate(r) for r in regole],
    )


def _disattiva_altre(bankroll_id: int, tranne_id: int, session: Session) -> None:
    altre = session.exec(
        select(Strategia).where(Strategia.bankroll_id == bankroll_id, Strategia.id != tranne_id)
    )
    for altra in altre:
        altra.attiva = False
        session.add(altra)


@router.get("/esempi", response_model=list[EsempioStrategia])
def elenca_esempi() -> list[EsempioStrategia]:
    return list(ESEMPI.values())


@router.post("/clona", response_model=StrategiaRead, status_code=status.HTTP_201_CREATED)
def clona_esempio(
    dati: ClonaEsempioRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> StrategiaRead:
    esempio = ESEMPI.get(dati.chiave)
    if esempio is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Esempio non trovato")
    _get_bankroll_utente(dati.bankroll_id, utente, session)

    strategia = Strategia(
        utente_id=utente.id, bankroll_id=dati.bankroll_id, nome=esempio.nome, attiva=False
    )
    session.add(strategia)
    session.commit()
    session.refresh(strategia)

    regole = []
    for r in esempio.regole:
        regola = Regola(strategia_id=strategia.id, tipo=r.tipo, valore=r.valore, attiva=True)
        session.add(regola)
        regole.append(regola)
    session.commit()
    for r in regole:
        session.refresh(r)

    return _a_strategia_read(strategia, regole)


@router.get("", response_model=list[StrategiaRead])
def elenca_strategie(
    bankroll_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[StrategiaRead]:
    _get_bankroll_utente(bankroll_id, utente, session)
    strategie = list(
        session.exec(
            select(Strategia)
            .where(Strategia.bankroll_id == bankroll_id, Strategia.utente_id == utente.id)
            .order_by(Strategia.creata_il)
        )
    )
    return [_a_strategia_read(s, _regole_di(s.id, session)) for s in strategie]


@router.post("", response_model=StrategiaRead, status_code=status.HTTP_201_CREATED)
def crea_strategia(
    dati: StrategiaCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> StrategiaRead:
    _get_bankroll_utente(dati.bankroll_id, utente, session)

    strategia = Strategia(
        utente_id=utente.id, bankroll_id=dati.bankroll_id, nome=dati.nome, attiva=False
    )
    session.add(strategia)
    session.commit()
    session.refresh(strategia)

    regole = []
    for r in dati.regole:
        regola = Regola(strategia_id=strategia.id, tipo=r.tipo, valore=r.valore, attiva=r.attiva)
        session.add(regola)
        regole.append(regola)
    session.commit()
    for r in regole:
        session.refresh(r)

    return _a_strategia_read(strategia, regole)


@router.patch("/{strategia_id}", response_model=StrategiaRead)
def aggiorna_strategia(
    strategia_id: int,
    dati: StrategiaAggiorna,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> StrategiaRead:
    strategia = _get_strategia_utente(strategia_id, utente, session)

    for campo, valore in dati.model_dump(exclude_unset=True).items():
        setattr(strategia, campo, valore)

    session.add(strategia)
    if dati.attiva:
        _disattiva_altre(strategia.bankroll_id, strategia.id, session)
    session.commit()
    session.refresh(strategia)

    return _a_strategia_read(strategia, _regole_di(strategia.id, session))


@router.delete("/{strategia_id}", status_code=status.HTTP_204_NO_CONTENT)
def elimina_strategia(
    strategia_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    strategia = _get_strategia_utente(strategia_id, utente, session)
    for regola in _regole_di(strategia.id, session):
        session.delete(regola)
    session.delete(strategia)
    session.commit()


@router.post("/{strategia_id}/regole", response_model=RegolaRead, status_code=status.HTTP_201_CREATED)
def aggiungi_regola(
    strategia_id: int,
    dati: RegolaCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Regola:
    strategia = _get_strategia_utente(strategia_id, utente, session)
    regola = Regola(strategia_id=strategia.id, tipo=dati.tipo, valore=dati.valore, attiva=dati.attiva)
    session.add(regola)
    session.commit()
    session.refresh(regola)
    return regola


@router.patch("/regole/{regola_id}", response_model=RegolaRead)
def aggiorna_regola(
    regola_id: int,
    dati: RegolaAggiorna,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Regola:
    regola = _get_regola_utente(regola_id, utente, session)
    for campo, valore in dati.model_dump(exclude_unset=True).items():
        setattr(regola, campo, valore)
    session.add(regola)
    session.commit()
    session.refresh(regola)
    return regola


@router.delete("/regole/{regola_id}", status_code=status.HTTP_204_NO_CONTENT)
def elimina_regola(
    regola_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    regola = _get_regola_utente(regola_id, utente, session)
    session.delete(regola)
    session.commit()
