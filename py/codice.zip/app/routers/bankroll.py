from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from typing import Optional
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.domain.bankroll import RisultatoSaldi, calcola_saldi
from app.domain.eventi import giocata_da_regolare
from app.domain.tempo import da_locale_a_utc
from app.domain.payout import SelezioneEsito, calcola_payout
from app.domain.system import calcola_payout_sistema
from app.models import (
    Bankroll,
    ConfigurazioneSistema,
    Giocata,
    MovimentoBankroll,
    Selezione,
    Utente,
)
from app.models.enums import EsitoSelezione, StatoGiocata, TipoGiocata, TipoMovimento
from app.schemas.bankroll import (
    BankrollAggiorna,
    BankrollCreate,
    BankrollRead,
    MovimentoAggiorna,
    MovimentoCreate,
    AllineaSaldoRequest,
    AllineaSaldoRisposta,
    MovimentoRead,
    SaldiRead,
    SaldoContoRead,
)

router = APIRouter(prefix="/api/bankroll", tags=["bankroll"])


def _get_bankroll_utente(bankroll_id: int, utente: Utente, session: Session) -> Bankroll:
    bankroll = session.get(Bankroll, bankroll_id)
    if bankroll is None or bankroll.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankroll non trovato")
    return bankroll


def _somma(session: Session, query) -> Decimal:
    risultato = session.exec(query).first()
    return risultato if risultato is not None else Decimal("0")


@router.get("", response_model=list[BankrollRead])
def elenca_bankroll(
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[Bankroll]:
    return list(
        session.exec(
            select(Bankroll).where(Bankroll.utente_id == utente.id).order_by(Bankroll.creato_il)
        )
    )


@router.post("", response_model=BankrollRead, status_code=status.HTTP_201_CREATED)
def crea_bankroll(
    dati: BankrollCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Bankroll:
    bankroll = Bankroll(utente_id=utente.id, nome=dati.nome, valuta=dati.valuta, colore=dati.colore)
    session.add(bankroll)
    session.commit()
    session.refresh(bankroll)
    return bankroll


@router.patch("/{bankroll_id}", response_model=BankrollRead)
def aggiorna_bankroll(
    bankroll_id: int,
    dati: BankrollAggiorna,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Bankroll:
    bankroll = _get_bankroll_utente(bankroll_id, utente, session)
    for campo, valore in dati.model_dump(exclude_unset=True).items():
        setattr(bankroll, campo, valore)
    session.add(bankroll)
    session.commit()
    session.refresh(bankroll)
    return bankroll


def _filtro_conto(query, modello, bookmaker: Optional[str]):
    return query.where(modello.bookmaker == bookmaker) if bookmaker is not None else query


def ottieni_saldi(
    bankroll_id: int, session: Session, bookmaker: Optional[str] = None
) -> RisultatoSaldi:
    """Saldi del bankroll, oppure di un solo conto (bookmaker) se indicato."""

    def somma_movimenti(tipo: TipoMovimento) -> Decimal:
        query = select(func.sum(MovimentoBankroll.importo)).where(
            MovimentoBankroll.bankroll_id == bankroll_id, MovimentoBankroll.tipo == tipo
        )
        return _somma(session, _filtro_conto(query, MovimentoBankroll, bookmaker))

    profitti_regolate = _somma(
        session,
        _filtro_conto(
            select(func.sum(Giocata.profitto)).where(
                Giocata.bankroll_id == bankroll_id, Giocata.stato != StatoGiocata.PENDENTE
            ),
            Giocata,
            bookmaker,
        ),
    )
    stake_pendenti = _somma(
        session,
        _filtro_conto(
            select(func.sum(Giocata.stake)).where(
                Giocata.bankroll_id == bankroll_id,
                Giocata.stato == StatoGiocata.PENDENTE,
                Giocata.e_free_bet == False,  # noqa: E712
            ),
            Giocata,
            bookmaker,
        ),
    )

    return calcola_saldi(
        depositi=somma_movimenti(TipoMovimento.DEPOSITO),
        prelievi=somma_movimenti(TipoMovimento.PRELIEVO),
        rettifiche=somma_movimenti(TipoMovimento.RETTIFICA),
        bonus=somma_movimenti(TipoMovimento.BONUS),
        profitti_giocate_regolate=profitti_regolate,
        stake_giocate_pendenti=stake_pendenti,
    )


@dataclass(frozen=True)
class StatoInGioco:
    schedine_in_corso: int
    stake_da_regolare: Decimal
    schedine_da_regolare: int
    ritorno_potenziale: Decimal


def _ritorno_potenziale(giocata: Giocata, selezioni: list[Selezione], sistema) -> Decimal:
    """Ritorno lordo se tutte le selezioni ancora aperte fossero vinte (quelle annullate valgono 1)."""
    ipotesi = [
        SelezioneEsito(
            quota=s.quota,
            esito=EsitoSelezione.ANNULLATA
            if s.esito == EsitoSelezione.ANNULLATA
            else EsitoSelezione.VINTA,
        )
        for s in selezioni
    ]
    if giocata.tipo_giocata == TipoGiocata.SISTEMA and sistema is not None:
        return calcola_payout_sistema(
            sistema.stake_per_combinazione, ipotesi, sistema.combinazioni_attive
        ).ritorno_lordo
    return calcola_payout(
        giocata.stake, ipotesi, giocata.e_free_bet, giocata.bonus_multipla_pct
    ).ritorno_lordo


def _stato_in_gioco(
    bankroll_id: int, session: Session, bookmaker: Optional[str], ora: datetime
) -> StatoInGioco:
    """Schedine pendenti: quante sono, quali attendono solo l'esito e quanto renderebbero se vinte."""
    giocate = list(
        session.exec(
            _filtro_conto(
                select(Giocata).where(
                    Giocata.bankroll_id == bankroll_id, Giocata.stato == StatoGiocata.PENDENTE
                ),
                Giocata,
                bookmaker,
            )
        )
    )
    if not giocate:
        return StatoInGioco(0, Decimal("0"), 0, Decimal("0"))

    ids = [g.id for g in giocate]
    selezioni_per_giocata: dict[int, list[Selezione]] = {}
    for s in session.exec(select(Selezione).where(Selezione.giocata_id.in_(ids))):
        selezioni_per_giocata.setdefault(s.giocata_id, []).append(s)
    sistemi = {
        c.giocata_id: c
        for c in session.exec(
            select(ConfigurazioneSistema).where(ConfigurazioneSistema.giocata_id.in_(ids))
        )
    }

    stake_da_regolare = Decimal("0")
    n_da_regolare = 0
    potenziale = Decimal("0")
    for g in giocate:
        selezioni = selezioni_per_giocata.get(g.id, [])
        potenziale += _ritorno_potenziale(g, selezioni, sistemi.get(g.id))
        pendenti = [s.inizio_evento for s in selezioni if s.esito == EsitoSelezione.PENDENTE]
        if not g.e_free_bet and giocata_da_regolare(pendenti, ora):
            stake_da_regolare += g.stake
            n_da_regolare += 1
    return StatoInGioco(len(giocate), stake_da_regolare, n_da_regolare, potenziale)


def _bookmaker_del_bankroll(bankroll_id: int, session: Session) -> list[str]:
    da_giocate = session.exec(
        select(Giocata.bookmaker).where(Giocata.bankroll_id == bankroll_id).distinct()
    )
    da_movimenti = session.exec(
        select(MovimentoBankroll.bookmaker)
        .where(MovimentoBankroll.bankroll_id == bankroll_id, MovimentoBankroll.bookmaker.is_not(None))
        .distinct()
    )
    return sorted({*da_giocate, *da_movimenti})


def _condizioni_json(condizioni) -> Optional[dict]:
    """Condizioni in forma serializzabile (i Decimal diventano stringhe); None se non ce n'è nessuna."""
    if condizioni is None:
        return None
    campi = {k: (str(v) if isinstance(v, Decimal) else v) for k, v in condizioni.model_dump().items() if v is not None}
    return campi or None


def _ora_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@router.get("/{bankroll_id}/saldo", response_model=SaldiRead)
def saldo_bankroll(
    bankroll_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> SaldiRead:
    _get_bankroll_utente(bankroll_id, utente, session)
    ora = _ora_utc()
    risultato = ottieni_saldi(bankroll_id, session)
    totale = _stato_in_gioco(bankroll_id, session, None, ora)

    conti = []
    for nome in _bookmaker_del_bankroll(bankroll_id, session):
        saldi_conto = ottieni_saldi(bankroll_id, session, nome)
        stato_conto = _stato_in_gioco(bankroll_id, session, nome, ora)
        conti.append(
            SaldoContoRead(
                bookmaker=nome,
                saldo_liquido=saldi_conto.saldo_liquido,
                capitale_in_gioco=saldi_conto.capitale_in_gioco,
                capitale_da_regolare=stato_conto.stake_da_regolare,
                giocate_da_regolare=stato_conto.schedine_da_regolare,
                schedine_in_corso=stato_conto.schedine_in_corso,
                saldo_ipotetico=saldi_conto.saldo_liquido + stato_conto.ritorno_potenziale,
            )
        )

    return SaldiRead(
        saldo_liquido=risultato.saldo_liquido,
        capitale_in_gioco=risultato.capitale_in_gioco,
        capitale_totale=risultato.capitale_totale,
        capitale_da_regolare=totale.stake_da_regolare,
        giocate_da_regolare=totale.schedine_da_regolare,
        schedine_in_corso=totale.schedine_in_corso,
        saldo_ipotetico=risultato.saldo_liquido + totale.ritorno_potenziale,
        conti=conti,
    )


@router.post("/{bankroll_id}/allinea-saldo", response_model=AllineaSaldoRisposta)
def allinea_saldo(
    bankroll_id: int,
    dati: AllineaSaldoRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> AllineaSaldoRisposta:
    """Registra una rettifica che porta il saldo disponibile di un conto al valore reale indicato.

    Va usata quando tutte le giocate concluse sono già state regolate: la rettifica assorbe ciò che
    l'app non conosce (depositi, prelievi, giocate non registrate). Se la differenza è nulla non
    crea alcun movimento.
    """
    _get_bankroll_utente(bankroll_id, utente, session)
    attuale = ottieni_saldi(bankroll_id, session, dati.bookmaker).saldo_liquido
    rettifica = dati.saldo_reale - attuale
    if rettifica == 0:
        return AllineaSaldoRisposta(
            bookmaker=dati.bookmaker,
            saldo_liquido=attuale,
            rettifica=Decimal("0.00"),
            movimento_creato=False,
        )

    movimento = MovimentoBankroll(
        bankroll_id=bankroll_id,
        tipo=TipoMovimento.RETTIFICA,
        importo=rettifica,
        data=datetime.now(timezone.utc),
        nota=f"Allineamento al saldo reale del conto {dati.bookmaker}",
        bookmaker=dati.bookmaker,
    )
    session.add(movimento)
    session.commit()
    return AllineaSaldoRisposta(
        bookmaker=dati.bookmaker,
        saldo_liquido=dati.saldo_reale,
        rettifica=rettifica,
        movimento_creato=True,
    )


@router.get("/{bankroll_id}/movimenti", response_model=list[MovimentoRead])
def elenca_movimenti(
    bankroll_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[MovimentoBankroll]:
    _get_bankroll_utente(bankroll_id, utente, session)
    return list(
        session.exec(
            select(MovimentoBankroll)
            .where(MovimentoBankroll.bankroll_id == bankroll_id)
            .order_by(MovimentoBankroll.data.desc())
        )
    )


@router.post(
    "/{bankroll_id}/movimenti", response_model=MovimentoRead, status_code=status.HTTP_201_CREATED
)
def crea_movimento(
    bankroll_id: int,
    dati: MovimentoCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> MovimentoBankroll:
    _get_bankroll_utente(bankroll_id, utente, session)
    movimento = MovimentoBankroll(
        bankroll_id=bankroll_id,
        tipo=dati.tipo,
        importo=dati.importo,
        data=dati.data or datetime.now(timezone.utc),
        nota=dati.nota,
        bookmaker=dati.bookmaker,
        scadenza=da_locale_a_utc(dati.scadenza) if dati.scadenza else None,
        condizioni=_condizioni_json(dati.condizioni),
    )
    session.add(movimento)
    session.commit()
    session.refresh(movimento)
    return movimento


@router.patch("/{bankroll_id}/movimenti/{movimento_id}", response_model=MovimentoRead)
def aggiorna_movimento(
    bankroll_id: int,
    movimento_id: int,
    dati: MovimentoAggiorna,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> MovimentoBankroll:
    _get_bankroll_utente(bankroll_id, utente, session)
    movimento = session.get(MovimentoBankroll, movimento_id)
    if movimento is None or movimento.bankroll_id != bankroll_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movimento non trovato")

    campi = dati.model_dump(exclude_unset=True)
    if dati.data is not None:
        movimento.data = da_locale_a_utc(dati.data)
    if "nota" in campi:
        movimento.nota = campi["nota"]
    if "bookmaker" in campi:
        movimento.bookmaker = campi["bookmaker"]
    if "scadenza" in campi:
        movimento.scadenza = da_locale_a_utc(dati.scadenza) if dati.scadenza else None
    if "condizioni" in campi:
        movimento.condizioni = _condizioni_json(dati.condizioni)
    session.add(movimento)
    session.commit()
    session.refresh(movimento)
    return movimento


@router.delete("/{bankroll_id}/movimenti/{movimento_id}", status_code=status.HTTP_204_NO_CONTENT)
def elimina_movimento(
    bankroll_id: int,
    movimento_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    _get_bankroll_utente(bankroll_id, utente, session)
    movimento = session.get(MovimentoBankroll, movimento_id)
    if movimento is None or movimento.bankroll_id != bankroll_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movimento non trovato")
    session.delete(movimento)
    session.commit()
