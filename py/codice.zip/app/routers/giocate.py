from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlmodel import Session, or_, select

from app.auth import get_current_user
from app.db import get_session
from app.domain.payout import (
    SelezioneEsito,
    calcola_cashout_parziale_finale,
    calcola_cashout_totale,
    calcola_payout,
    deriva_stato_giocata,
    quota_totale_dichiarata,
)
from app.domain.analytics import famiglia_selezione
from app.domain.eventi import DA_REGOLARE, fase_evento, fase_giocata
from app.domain.tempo import da_locale_a_utc
from app.domain.rules import CandidataGiocata, ContestoRegole, RegolaDef, valuta_regole
from app.domain.system import calcola_payout_sistema, deriva_stato_sistema, stake_totale_sistema
from app.models import (
    Bankroll,
    ConfigurazioneSistema,
    Giocata,
    Regola,
    Selezione,
    Strategia,
    Utente,
)
from app.models.enums import EsitoSelezione, StatoGiocata, TipoGiocata
from app.routers.bankroll import ottieni_saldi
from app.schemas.giocate import (
    CashoutParzialeRequest,
    CashoutTotaleRequest,
    DiscrepanzaImporta,
    GiocataAggiorna,
    GiocataCreate,
    GiocataImporta,
    GiocataRead,
    ImportaRequest,
    ImportaRisposta,
    RegolaRapidaRequest,
    RegolaSelezioneRequest,
    SelezioneRead,
    SistemaRead,
)

router = APIRouter(prefix="/api/giocate", tags=["giocate"])


# --- helpers --------------------------------------------------------------------------------


def _get_bankroll_utente(bankroll_id: int, utente: Utente, session: Session) -> Bankroll:
    bankroll = session.get(Bankroll, bankroll_id)
    if bankroll is None or bankroll.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankroll non trovato")
    return bankroll


def _get_giocata_utente(giocata_id: int, utente: Utente, session: Session) -> Giocata:
    giocata = session.get(Giocata, giocata_id)
    if giocata is None or giocata.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Schedina non trovata")
    return giocata


def _selezioni_di(giocata_id: int, session: Session) -> list[Selezione]:
    return list(
        session.exec(
            select(Selezione).where(Selezione.giocata_id == giocata_id).order_by(Selezione.ordine)
        )
    )


def _sistema_di(giocata_id: int, session: Session) -> Optional[ConfigurazioneSistema]:
    return session.exec(
        select(ConfigurazioneSistema).where(ConfigurazioneSistema.giocata_id == giocata_id)
    ).first()


def _ora_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _a_selezione_read(selezione: Selezione, ora: Optional[datetime] = None) -> SelezioneRead:
    letta = SelezioneRead.model_validate(selezione)
    letta.bet_builder = selezione.bet_builder
    letta.famiglia = famiglia_selezione(selezione)
    # la fase della partita (futura, in campo, finita) vale anche per le giocate già regolate: serve a
    # raggruppare le partite; senza un orario noto se ne parla solo per le giocate ancora aperte
    if selezione.esito == EsitoSelezione.PENDENTE or selezione.inizio_evento is not None:
        letta.fase_evento = fase_evento(selezione.inizio_evento, ora or _ora_utc())
    if selezione.esito == EsitoSelezione.PENDENTE:
        letta.evento_concluso = letta.fase_evento == "concluso"
    return letta


def _a_giocata_read(
    giocata: Giocata, selezioni: list[Selezione], sistema: Optional[ConfigurazioneSistema]
) -> GiocataRead:
    ora = _ora_utc()
    fase = None
    if giocata.stato == StatoGiocata.PENDENTE:
        pendenti = [s.inizio_evento for s in selezioni if s.esito == EsitoSelezione.PENDENTE]
        fase = fase_giocata(pendenti, len(pendenti) < len(selezioni), ora)
    return GiocataRead(
        id=giocata.id,
        bankroll_id=giocata.bankroll_id,
        tipo_giocata=giocata.tipo_giocata,
        bookmaker=giocata.bookmaker,
        stake=giocata.stake,
        quota_totale=giocata.quota_totale,
        e_free_bet=giocata.e_free_bet,
        bonus_multipla_pct=giocata.bonus_multipla_pct,
        stato=giocata.stato,
        piazzata_il=giocata.piazzata_il,
        regolata_il=giocata.regolata_il,
        ritorno_lordo=giocata.ritorno_lordo,
        profitto=giocata.profitto,
        cashout_importo=giocata.cashout_importo,
        cashout_stake_liberato=giocata.cashout_stake_liberato,
        note=giocata.note,
        tags=giocata.tags,
        riferimento_esterno=giocata.riferimento_esterno,
        orario_approssimato=giocata.orario_approssimato,
        regole_violate=giocata.regole_violate,
        fase=fase,
        da_regolare=fase == DA_REGOLARE,
        selezioni=[_a_selezione_read(s, ora) for s in selezioni],
        sistema=SistemaRead.model_validate(sistema) if sistema else None,
    )


def _selezioni_esiti(selezioni: list[Selezione]) -> list[SelezioneEsito]:
    return [SelezioneEsito(quota=s.quota, esito=s.esito) for s in selezioni]


def _valuta_regole_giocata(
    bankroll_id: int, candidata: CandidataGiocata, session: Session, ora: datetime
) -> list[dict]:
    """Valuta le regole della strategia attiva del bankroll contro la giocata candidata
    (sezione 8). Non blocca mai la creazione: restituisce solo lo snapshot delle violazioni.
    """
    strategia_attiva = session.exec(
        select(Strategia).where(
            Strategia.bankroll_id == bankroll_id, Strategia.attiva == True  # noqa: E712
        )
    ).first()
    if strategia_attiva is None:
        return []

    regole_attive = list(
        session.exec(
            select(Regola).where(
                Regola.strategia_id == strategia_attiva.id, Regola.attiva == True  # noqa: E712
            )
        )
    )
    if not regole_attive:
        return []

    inizio_giorno = ora.replace(hour=0, minute=0, second=0, microsecond=0)

    giocate_oggi = session.exec(
        select(func.count())
        .select_from(Giocata)
        .where(Giocata.bankroll_id == bankroll_id, Giocata.piazzata_il >= inizio_giorno)
    ).one()

    profitto_oggi = session.exec(
        select(func.sum(Giocata.profitto)).where(
            Giocata.bankroll_id == bankroll_id,
            Giocata.regolata_il >= inizio_giorno,
            Giocata.stato != StatoGiocata.PENDENTE,
        )
    ).first()
    perdita_netta_oggi = max(Decimal("0"), -(profitto_oggi or Decimal("0")))

    ultima_persa = session.exec(
        select(Giocata.regolata_il)
        .where(Giocata.bankroll_id == bankroll_id, Giocata.stato == StatoGiocata.PERSA)
        .order_by(Giocata.regolata_il.desc())
    ).first()

    saldi = ottieni_saldi(bankroll_id, session)

    contesto = ContestoRegole(
        capitale_totale=saldi.capitale_totale,
        giocate_piazzate_oggi=giocate_oggi,
        perdita_netta_oggi=perdita_netta_oggi,
        ultima_giocata_persa_regolata_il=ultima_persa,
        ora=ora,
    )

    regole_def = [RegolaDef(tipo=r.tipo, valore=r.valore) for r in regole_attive]
    violazioni = valuta_regole(regole_def, candidata, contesto)
    return [{"tipo": v.tipo.value, "descrizione": v.descrizione} for v in violazioni]


def _deduci_tipo_stake_quota(dati: GiocataCreate) -> tuple:
    if dati.sistema and len(dati.selezioni) < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Un sistema richiede almeno 2 giocate",
        )
    if dati.sistema:
        for k in dati.sistema.combinazioni_attive:
            if k < 1 or k > len(dati.selezioni):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="combinazioni_attive contiene un valore non valido per il numero di giocate",
                )
        tipo_giocata = TipoGiocata.SISTEMA
    elif len(dati.selezioni) == 1:
        tipo_giocata = TipoGiocata.SINGOLA
    else:
        tipo_giocata = TipoGiocata.MULTIPLA

    quota_totale = quota_totale_dichiarata([s.quota for s in dati.selezioni])

    if tipo_giocata == TipoGiocata.SISTEMA:
        stake = stake_totale_sistema(
            dati.sistema.stake_per_combinazione,
            len(dati.selezioni),
            dati.sistema.combinazioni_attive,
        )
    else:
        stake = dati.stake

    return tipo_giocata, stake, quota_totale


def _ricalcola_giocata(giocata: Giocata, selezioni: list[Selezione], session: Session) -> None:
    """Ricalcola stato/ritorno/profitto una volta che la giocata è decisa.

    Una singola o multipla con una selezione persa è persa subito, anche se altre selezioni sono
    ancora pendenti (come fa il bookmaker). Altrimenti non fa nulla finché restano selezioni
    pendenti. Sistemi e cash-out parziali aspettano sempre tutte le selezioni.
    """
    ha_pendenti = any(s.esito == EsitoSelezione.PENDENTE for s in selezioni)
    gia_persa = (
        ha_pendenti
        and any(s.esito == EsitoSelezione.PERSA for s in selezioni)
        and giocata.tipo_giocata != TipoGiocata.SISTEMA
        and giocata.cashout_stake_liberato is None
    )
    if ha_pendenti and not gia_persa:
        if giocata.stato != StatoGiocata.PENDENTE:
            # una correzione ha rimesso in corso una giocata: la schedina torna aperta
            giocata.stato = StatoGiocata.PENDENTE
            giocata.ritorno_lordo = Decimal("0")
            giocata.profitto = Decimal("0")
            giocata.regolata_il = None
            session.add(giocata)
        return

    # le selezioni ancora pendenti di una giocata già persa non incidono sul calcolo
    selezioni_esiti = [
        SelezioneEsito(
            quota=s.quota,
            esito=EsitoSelezione.ANNULLATA if s.esito == EsitoSelezione.PENDENTE else s.esito,
        )
        for s in selezioni
    ]

    if giocata.tipo_giocata == TipoGiocata.SISTEMA:
        sistema = _sistema_di(giocata.id, session)
        risultato = calcola_payout_sistema(
            sistema.stake_per_combinazione, selezioni_esiti, sistema.combinazioni_attive
        )
        giocata.stato = deriva_stato_sistema(risultato, selezioni_esiti)
        giocata.ritorno_lordo = risultato.ritorno_lordo
        giocata.profitto = risultato.profitto
    elif giocata.cashout_stake_liberato is not None:
        risultato = calcola_cashout_parziale_finale(
            stake=giocata.stake,
            cashout_importo=giocata.cashout_importo,
            cashout_stake_liberato=giocata.cashout_stake_liberato,
            selezioni=selezioni_esiti,
        )
        giocata.stato = StatoGiocata.CASHOUT
        giocata.ritorno_lordo = risultato.ritorno_lordo
        giocata.profitto = risultato.profitto
    else:
        risultato = calcola_payout(
            giocata.stake, selezioni_esiti, giocata.e_free_bet, giocata.bonus_multipla_pct
        )
        giocata.stato = deriva_stato_giocata(selezioni_esiti)
        giocata.ritorno_lordo = risultato.ritorno_lordo
        giocata.profitto = risultato.profitto

    giocata.regolata_il = datetime.now(timezone.utc)
    session.add(giocata)


# --- CRUD -------------------------------------------------------------------------------------


@router.post("", response_model=GiocataRead, status_code=status.HTTP_201_CREATED)
def crea_giocata(
    dati: GiocataCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    _get_bankroll_utente(dati.bankroll_id, utente, session)

    tipo_giocata, stake, quota_totale = _deduci_tipo_stake_quota(dati)

    ora = datetime.now(timezone.utc)
    candidata = CandidataGiocata(
        tipo_giocata=tipo_giocata,
        quota_totale=quota_totale,
        stake=stake,
        numero_selezioni=len(dati.selezioni),
        sport=[s.sport for s in dati.selezioni],
    )
    regole_violate = _valuta_regole_giocata(dati.bankroll_id, candidata, session, ora)

    giocata = Giocata(
        bankroll_id=dati.bankroll_id,
        utente_id=utente.id,
        tipo_giocata=tipo_giocata,
        bookmaker=dati.bookmaker,
        stake=stake,
        quota_totale=quota_totale,
        e_free_bet=dati.e_free_bet,
        bonus_multipla_pct=dati.bonus_multipla_pct,
        stato=StatoGiocata.PENDENTE,
        piazzata_il=da_locale_a_utc(dati.piazzata_il) if dati.piazzata_il else ora,
        note=dati.note,
        tags=dati.tags,
        regole_violate=regole_violate,
    )
    session.add(giocata)
    session.commit()
    session.refresh(giocata)

    selezioni: list[Selezione] = []
    for ordine, sel in enumerate(dati.selezioni):
        selezione = Selezione(
            giocata_id=giocata.id,
            ordine=ordine,
            sport=sel.sport,
            competizione=sel.competizione,
            squadra_casa=sel.squadra_casa,
            squadra_trasferta=sel.squadra_trasferta,
            mercato=sel.mercato,
            esito_giocato=sel.esito_giocato,
            quota=sel.quota,
            inizio_evento=da_locale_a_utc(sel.inizio_evento) if sel.inizio_evento else None,
            risultato_evento=sel.risultato_evento,
            mercato_giocatore=sel.mercato_giocatore,
            componenti=[c.model_dump() for c in sel.componenti] if sel.componenti else None,
        )
        session.add(selezione)
        selezioni.append(selezione)

    sistema_obj: Optional[ConfigurazioneSistema] = None
    if dati.sistema:
        sistema_obj = ConfigurazioneSistema(
            giocata_id=giocata.id,
            combinazioni_attive=dati.sistema.combinazioni_attive,
            stake_per_combinazione=dati.sistema.stake_per_combinazione,
        )
        session.add(sistema_obj)

    session.commit()
    for s in selezioni:
        session.refresh(s)
    if sistema_obj:
        session.refresh(sistema_obj)

    return _a_giocata_read(giocata, selezioni, sistema_obj)


# --- importazione dello storico -------------------------------------------------------------

DURATA_STIMATA_EVENTO = timedelta(hours=2)


def _regola_importata(
    giocata: Giocata, selezioni: list[Selezione], regolata_il: Optional[datetime]
) -> None:
    """Regola una giocata importata dagli esiti già noti delle sue selezioni.

    Una multipla con almeno una selezione persa è persa anche se altre selezioni sono ancora
    pendenti (come fa il bookmaker). Altrimenti resta pendente finché non sono tutte regolate.
    """
    ha_persa = any(s.esito == EsitoSelezione.PERSA for s in selezioni)
    ha_pendenti = any(s.esito == EsitoSelezione.PENDENTE for s in selezioni)
    if ha_pendenti and not ha_persa:
        return

    # le selezioni ancora pendenti di una giocata già persa non incidono sul calcolo
    esiti = [
        SelezioneEsito(
            quota=s.quota,
            esito=EsitoSelezione.ANNULLATA if s.esito == EsitoSelezione.PENDENTE else s.esito,
        )
        for s in selezioni
    ]
    risultato = calcola_payout(giocata.stake, esiti, giocata.e_free_bet, giocata.bonus_multipla_pct)
    giocata.stato = StatoGiocata.PERSA if ha_persa else deriva_stato_giocata(esiti)
    giocata.ritorno_lordo = risultato.ritorno_lordo
    giocata.profitto = risultato.profitto

    if regolata_il is None:
        # stima: una persa si sa a fine della prima selezione persa, una vinta a fine dell'ultima
        if ha_persa:
            inizi = [
                s.inizio_evento
                for s in selezioni
                if s.esito == EsitoSelezione.PERSA and s.inizio_evento
            ]
            riferimento = min(inizi) if inizi else None
        else:
            inizi = [s.inizio_evento for s in selezioni if s.inizio_evento]
            riferimento = max(inizi) if inizi else None
        regolata_il = (
            riferimento + DURATA_STIMATA_EVENTO
            if riferimento
            else giocata.piazzata_il + DURATA_STIMATA_EVENTO
        )
    giocata.regolata_il = regolata_il


@router.post("/importa", response_model=ImportaRisposta)
def importa_giocate(
    dati: ImportaRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> ImportaRisposta:
    """Importa lo storico di giocate già piazzate (e in parte già regolate) da un file JSON.

    Il server ricalcola ritorno e profitto dagli esiti delle selezioni; se il file riporta la
    vincita dichiarata dal bookmaker e differisce dal ricalcolo, la differenza è segnalata.
    Le giocate già importate (stesso `riferimento`) vengono saltate.
    """
    _get_bankroll_utente(dati.bankroll_id, utente, session)

    riferimenti_esistenti = set(
        session.exec(
            select(Giocata.riferimento_esterno).where(
                Giocata.utente_id == utente.id, Giocata.riferimento_esterno.is_not(None)
            )
        )
    )

    risposta = ImportaRisposta(
        importate=0, saltate_duplicate=0, regolate=0, pendenti=0, discrepanze=[]
    )
    visti: set[str] = set()
    for item in dati.giocate:
        if item.riferimento in riferimenti_esistenti or item.riferimento in visti:
            risposta.saltate_duplicate += 1
            continue
        visti.add(item.riferimento)

        quota_totale = quota_totale_dichiarata([s.quota for s in item.selezioni])
        giocata = Giocata(
            bankroll_id=dati.bankroll_id,
            utente_id=utente.id,
            tipo_giocata=TipoGiocata.SINGOLA if len(item.selezioni) == 1 else TipoGiocata.MULTIPLA,
            bookmaker=item.bookmaker,
            stake=item.stake,
            quota_totale=quota_totale,
            e_free_bet=item.e_free_bet,
            bonus_multipla_pct=item.bonus_multipla_pct if len(item.selezioni) > 1 else Decimal("0"),
            stato=StatoGiocata.PENDENTE,
            piazzata_il=da_locale_a_utc(item.piazzata_il),
            orario_approssimato=item.orario_approssimato,
            riferimento_esterno=item.riferimento,
            note=item.note,
            tags=item.tags,
        )
        session.add(giocata)
        session.flush()

        selezioni: list[Selezione] = []
        for ordine, sel in enumerate(item.selezioni):
            selezione = Selezione(
                giocata_id=giocata.id,
                ordine=ordine,
                sport=sel.sport,
                competizione=sel.competizione,
                squadra_casa=sel.squadra_casa,
                squadra_trasferta=sel.squadra_trasferta,
                mercato=sel.mercato,
                esito_giocato=sel.esito_giocato,
                quota=sel.quota,
                esito=sel.esito,
                inizio_evento=da_locale_a_utc(sel.inizio_evento) if sel.inizio_evento else None,
                risultato_evento=sel.risultato_evento,
                mercato_giocatore=sel.mercato_giocatore,
                componenti=[c.model_dump() for c in sel.componenti] if sel.componenti else None,
            )
            session.add(selezione)
            selezioni.append(selezione)

        _regola_importata(
            giocata, selezioni, da_locale_a_utc(item.regolata_il) if item.regolata_il else None
        )
        session.add(giocata)

        risposta.importate += 1
        if giocata.stato == StatoGiocata.PENDENTE:
            risposta.pendenti += 1
        else:
            risposta.regolate += 1
        if (
            item.vincita_dichiarata is not None
            and giocata.stato == StatoGiocata.VINTA
            and abs(giocata.ritorno_lordo - item.vincita_dichiarata) > Decimal("0.05")
        ):
            risposta.discrepanze.append(
                DiscrepanzaImporta(
                    riferimento=item.riferimento,
                    ritorno_calcolato=giocata.ritorno_lordo,
                    ritorno_dichiarato=item.vincita_dichiarata,
                )
            )

    session.commit()
    return risposta


@router.post("/valuta-regole", response_model=list[dict])
def valuta_regole_anteprima(
    dati: GiocataCreate,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[dict]:
    """Anteprima non persistente delle violazioni di regola, per l'avviso live nel form."""
    _get_bankroll_utente(dati.bankroll_id, utente, session)
    tipo_giocata, stake, quota_totale = _deduci_tipo_stake_quota(dati)
    candidata = CandidataGiocata(
        tipo_giocata=tipo_giocata,
        quota_totale=quota_totale,
        stake=stake,
        numero_selezioni=len(dati.selezioni),
        sport=[s.sport for s in dati.selezioni],
    )
    return _valuta_regole_giocata(
        dati.bankroll_id, candidata, session, datetime.now(timezone.utc)
    )


@router.get("", response_model=list[GiocataRead])
def elenca_giocate(
    stato: Optional[StatoGiocata] = None,
    bankroll_id: Optional[int] = None,
    tipo_giocata: Optional[TipoGiocata] = None,
    q: Optional[str] = None,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[GiocataRead]:
    query = select(Giocata).where(Giocata.utente_id == utente.id)
    if stato is not None:
        query = query.where(Giocata.stato == stato)
    if bankroll_id is not None:
        query = query.where(Giocata.bankroll_id == bankroll_id)
    if tipo_giocata is not None:
        query = query.where(Giocata.tipo_giocata == tipo_giocata)
    if q:
        pattern = f"%{q}%"
        ids_da_selezioni = select(Selezione.giocata_id).where(
            or_(
                Selezione.squadra_casa.ilike(pattern),
                Selezione.squadra_trasferta.ilike(pattern),
                Selezione.mercato.ilike(pattern),
                Selezione.esito_giocato.ilike(pattern),
                Selezione.competizione.ilike(pattern),
                Selezione.sport.ilike(pattern),
            )
        )
        query = query.where(
            or_(Giocata.bookmaker.ilike(pattern), Giocata.id.in_(ids_da_selezioni))
        )
    query = query.order_by(Giocata.piazzata_il.desc())

    giocate = list(session.exec(query))
    if not giocate:
        return []

    giocata_ids = [g.id for g in giocate]
    tutte_selezioni = list(
        session.exec(
            select(Selezione)
            .where(Selezione.giocata_id.in_(giocata_ids))
            .order_by(Selezione.ordine)
        )
    )
    selezioni_per_giocata: dict[int, list[Selezione]] = {}
    for s in tutte_selezioni:
        selezioni_per_giocata.setdefault(s.giocata_id, []).append(s)

    sistemi = list(
        session.exec(
            select(ConfigurazioneSistema).where(
                ConfigurazioneSistema.giocata_id.in_(giocata_ids)
            )
        )
    )
    sistema_per_giocata = {s.giocata_id: s for s in sistemi}

    return [
        _a_giocata_read(
            g, selezioni_per_giocata.get(g.id, []), sistema_per_giocata.get(g.id)
        )
        for g in giocate
    ]


@router.get("/{giocata_id}", response_model=GiocataRead)
def dettaglio_giocata(
    giocata_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    selezioni = _selezioni_di(giocata.id, session)
    sistema = _sistema_di(giocata.id, session)
    return _a_giocata_read(giocata, selezioni, sistema)


@router.patch("/{giocata_id}", response_model=GiocataRead)
def aggiorna_giocata(
    giocata_id: int,
    dati: GiocataAggiorna,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)

    for campo, valore in dati.model_dump(exclude_unset=True).items():
        setattr(giocata, campo, valore)

    session.add(giocata)
    session.commit()
    session.refresh(giocata)

    selezioni = _selezioni_di(giocata.id, session)
    sistema = _sistema_di(giocata.id, session)
    return _a_giocata_read(giocata, selezioni, sistema)


@router.delete("/{giocata_id}", status_code=status.HTTP_204_NO_CONTENT)
def elimina_giocata(
    giocata_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    for selezione in _selezioni_di(giocata.id, session):
        session.delete(selezione)
    sistema = _sistema_di(giocata.id, session)
    if sistema:
        session.delete(sistema)
    session.delete(giocata)
    session.commit()


# --- regolazione --------------------------------------------------------------------------


def _partita_iniziata(selezione: Selezione, ora: datetime) -> bool:
    """Senza orario non si può escludere che sia iniziata: si lascia regolare."""
    return selezione.inizio_evento is None or selezione.inizio_evento <= ora


def _verifica_regolabile(selezioni_da_regolare: list[Selezione], esito: EsitoSelezione, richiede_tutte: bool) -> None:
    """Una vinta o una persa non si può registrare prima che la partita sia iniziata."""
    if esito == EsitoSelezione.ANNULLATA or esito == EsitoSelezione.PENDENTE:
        return
    ora = _ora_utc()
    iniziate = [_partita_iniziata(s, ora) for s in selezioni_da_regolare]
    if (richiede_tutte and not all(iniziate)) or (not richiede_tutte and not any(iniziate)):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La partita non è ancora iniziata: la schedina è ancora in corso",
        )


@router.post("/{giocata_id}/regola-rapida", response_model=GiocataRead)
def regola_rapida(
    giocata_id: int,
    dati: RegolaRapidaRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    if giocata.stato != StatoGiocata.PENDENTE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="La schedina non è più in corso"
        )

    selezioni = _selezioni_di(giocata.id, session)
    pendenti = [s for s in selezioni if s.esito == EsitoSelezione.PENDENTE]
    # vinta: serve che tutte le partite aperte siano iniziate; persa: basta che una lo sia
    _verifica_regolabile(pendenti, dati.esito, richiede_tutte=dati.esito == EsitoSelezione.VINTA)
    for selezione in pendenti:
        selezione.esito = dati.esito
        session.add(selezione)

    _ricalcola_giocata(giocata, selezioni, session)
    session.commit()
    session.refresh(giocata)

    return _a_giocata_read(giocata, selezioni, _sistema_di(giocata.id, session))


@router.patch("/{giocata_id}/selezioni/{selezione_id}", response_model=GiocataRead)
def regola_selezione(
    giocata_id: int,
    selezione_id: int,
    dati: RegolaSelezioneRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    if giocata.stato == StatoGiocata.CASHOUT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Con il cash-out l'esito delle giocate non si corregge",
        )

    selezione = session.get(Selezione, selezione_id)
    if selezione is None or selezione.giocata_id != giocata.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Giocata non trovata")

    _verifica_regolabile([selezione], dati.esito, richiede_tutte=True)
    selezione.esito = dati.esito
    session.add(selezione)

    selezioni = _selezioni_di(giocata.id, session)
    _ricalcola_giocata(giocata, selezioni, session)
    session.commit()
    session.refresh(giocata)

    return _a_giocata_read(giocata, selezioni, _sistema_di(giocata.id, session))


@router.post("/{giocata_id}/riapri", response_model=GiocataRead)
def riapri_giocata(
    giocata_id: int,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    """Annulla una regolazione sbagliata: la schedina torna in corso con tutte le giocate da regolare."""
    giocata = _get_giocata_utente(giocata_id, utente, session)
    if giocata.stato == StatoGiocata.PENDENTE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="La schedina è già in corso"
        )
    if giocata.stato == StatoGiocata.CASHOUT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Una schedina chiusa con il cash-out non si può riaprire",
        )

    selezioni = _selezioni_di(giocata.id, session)
    for selezione in selezioni:
        selezione.esito = EsitoSelezione.PENDENTE
        session.add(selezione)
    giocata.stato = StatoGiocata.PENDENTE
    giocata.ritorno_lordo = Decimal("0")
    giocata.profitto = Decimal("0")
    giocata.regolata_il = None
    session.add(giocata)
    session.commit()
    session.refresh(giocata)

    return _a_giocata_read(giocata, selezioni, _sistema_di(giocata.id, session))


@router.post("/{giocata_id}/cashout-totale", response_model=GiocataRead)
def cashout_totale(
    giocata_id: int,
    dati: CashoutTotaleRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    if giocata.stato != StatoGiocata.PENDENTE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="La schedina non è più in corso"
        )
    if giocata.tipo_giocata == TipoGiocata.SISTEMA:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Il cash-out non è supportato sui sistemi in questa versione",
        )

    risultato = calcola_cashout_totale(giocata.stake, dati.cashout_importo)
    giocata.stato = StatoGiocata.CASHOUT
    giocata.ritorno_lordo = risultato.ritorno_lordo
    giocata.profitto = risultato.profitto
    giocata.cashout_importo = dati.cashout_importo
    giocata.regolata_il = datetime.now(timezone.utc)
    session.add(giocata)
    session.commit()
    session.refresh(giocata)

    return _a_giocata_read(giocata, _selezioni_di(giocata.id, session), None)


@router.post("/{giocata_id}/cashout-parziale", response_model=GiocataRead)
def cashout_parziale(
    giocata_id: int,
    dati: CashoutParzialeRequest,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> GiocataRead:
    giocata = _get_giocata_utente(giocata_id, utente, session)
    if giocata.stato != StatoGiocata.PENDENTE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="La schedina non è più in corso"
        )
    if giocata.tipo_giocata == TipoGiocata.SISTEMA:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Il cash-out non è supportato sui sistemi in questa versione",
        )
    if dati.cashout_stake_liberato >= giocata.stake:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="cashout_stake_liberato deve essere minore dello stake",
        )

    giocata.cashout_importo = dati.cashout_importo
    giocata.cashout_stake_liberato = dati.cashout_stake_liberato
    session.add(giocata)
    session.commit()
    session.refresh(giocata)

    return _a_giocata_read(giocata, _selezioni_di(giocata.id, session), None)
