import logging
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.domain.lettura_schedina import (
    BozzaSchedina,
    DATA_REGISTRAZIONE_COMPLETA,
    TAG_STORICO_SCREENSHOT,
    riferimento_bozza,
)
from app.domain.tempo import da_locale_a_utc
from app.models import Giocata, Utente
from app.schemas.lettura import LetturaRisposta, SchedinaLetta, SelezioneLetta
from app.services import ocr
from app.services.lettura_screenshot import leggi_bozza

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/lettura", tags=["lettura"])

MAX_FILE = 12
MAX_BYTE = 10 * 1024 * 1024


def _trova_duplicata(session: Session, utente: Utente, bozza: BozzaSchedina, riferimento: str) -> Optional[str]:
    """Motivo per cui la schedina risulta già nel registro (stesso codice ADM oppure stessa ora e puntata)."""
    esistenti = session.exec(select(Giocata).where(Giocata.utente_id == utente.id)).all()
    if bozza.riferimento:
        for g in esistenti:
            if g.riferimento_esterno and bozza.riferimento in g.riferimento_esterno:
                return "Già nel registro (stesso codice del biglietto)."
    if bozza.piazzata_il and bozza.stake is not None:
        piazzata = da_locale_a_utc(bozza.piazzata_il)
        for g in esistenti:
            if (
                g.bookmaker == bozza.bookmaker
                and g.stake == bozza.stake
                and abs((g.piazzata_il - piazzata).total_seconds()) < 90
            ):
                return "Già nel registro (stessa ora e stessa puntata)."
    return None


def _schedina_letta(nome: str, bozza: BozzaSchedina, riferimento: str) -> SchedinaLetta:
    tag_storico = bozza.piazzata_il is not None and bozza.piazzata_il < DATA_REGISTRAZIONE_COMPLETA
    return SchedinaLetta(
        nome_file=nome,
        bookmaker=bozza.bookmaker,
        riferimento=riferimento,
        piazzata_il=bozza.piazzata_il,
        stake=bozza.stake,
        quota_totale=bozza.quota_totale,
        vincita=bozza.vincita,
        bonus_multipla_pct=bozza.bonus_multipla_pct,
        stato=bozza.stato,
        tags=[TAG_STORICO_SCREENSHOT] if tag_storico else [],
        selezioni=[SelezioneLetta(**vars(s)) for s in bozza.selezioni],
        avvisi=bozza.avvisi,
    )


@router.post("/schedine", response_model=LetturaRisposta)
async def leggi_screenshot(
    file: list[UploadFile],
    ocr_testi: Optional[str] = Form(None),
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> LetturaRisposta:
    """Legge uno o più screenshot di schedine e restituisce le bozze, senza salvare nulla.

    La lettura è locale (Tesseract nel container): nessuna immagine esce dal server né viene conservata.
    Il salvataggio avviene solo dopo la revisione, tramite `POST /api/giocate/importa`.

    `ocr_testi` (JSON `{chiave: tsv}`) serve solo alla versione locale, dove l'OCR gira in JavaScript: sono i testi
    già letti dal browser (vedi `pwa/ocr_browser.py`). Sul server non si usa.
    """
    if not file:
        raise HTTPException(status_code=422, detail="Nessun file ricevuto.")
    if len(file) > MAX_FILE:
        raise HTTPException(status_code=422, detail=f"Al massimo {MAX_FILE} screenshot alla volta.")
    if not ocr.tesseract_disponibile():
        raise HTTPException(status_code=503, detail="La lettura degli screenshot non è disponibile su questo server.")

    token = ocr.imposta_letture_esterne(ocr_testi)
    try:
        return await _leggi_file(file, utente, session)
    finally:
        ocr.ripristina_letture_esterne(token)


async def _leggi_file(file: list[UploadFile], utente: Utente, session: Session) -> LetturaRisposta:
    schedine: list[SchedinaLetta] = []
    visti: set[str] = set()
    for upload in file:
        nome = upload.filename or "screenshot"
        contenuto = await upload.read(MAX_BYTE + 1)
        if len(contenuto) > MAX_BYTE:
            schedine.append(SchedinaLetta(nome_file=nome, errore="Il file è troppo grande (massimo 10 MB)."))
            continue
        try:
            bozza = leggi_bozza(contenuto)
        except ocr.ErroreLettura as errore:
            schedine.append(SchedinaLetta(nome_file=nome, errore=str(errore)))
            continue
        except ocr.DaEseguire:
            raise  # primo tempo del protocollo OCR del browser: non è un errore
        except Exception:  # un'immagine strana non deve mai far fallire l'intero caricamento
            logger.exception("Lettura dello screenshot %s non riuscita", nome)
            schedine.append(SchedinaLetta(nome_file=nome, errore="Non sono riuscito a interpretare questo screenshot."))
            continue
        riferimento = riferimento_bozza(bozza)
        letta = _schedina_letta(nome, bozza, riferimento)
        motivo = _trova_duplicata(session, utente, bozza, riferimento)
        if motivo is None and riferimento in visti:
            motivo = "Doppione: è già in questo caricamento."
        visti.add(riferimento)
        letta.duplicata = motivo is not None
        letta.motivo_duplicata = motivo
        schedine.append(letta)
    return LetturaRisposta(schedine=schedine)
