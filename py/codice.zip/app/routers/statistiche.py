from datetime import datetime, timedelta, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.domain.rules import Aderenza, GiocataAderenza, calcola_aderenza
from app.domain.stats import (
    SOGLIA_MINIMA_CAMPIONE,
    SOGLIA_STIMA_INCERTA,
    GiocataStat,
    calcola_breakdown,
    calcola_drawdown,
    calcola_metriche,
    calcola_serie,
    fascia_quota,
    filtra_rilevanti,
    margine_atteso_casuale,
)
from app.models import Bankroll, Giocata, Selezione, Utente
from app.models.enums import TipoGiocata, TipoRegola
from app.schemas.statistiche import (
    AderenzaRead,
    BreakdownRead,
    CostoRegolaRead,
    DrawdownRead,
    MetricheRead,
    SerieRead,
    StatisticheRead,
    VoceBreakdownRead,
)

router = APIRouter(prefix="/api/statistiche", tags=["statistiche"])

PERIODI_GIORNI = {"7g": 7, "30g": 30, "90g": 90, "anno": 365}

GIORNI_SETTIMANA_IT = [
    "Lunedì",
    "Martedì",
    "Mercoledì",
    "Giovedì",
    "Venerdì",
    "Sabato",
    "Domenica",
]


def _range_periodo(
    periodo: str, da: Optional[datetime], a: Optional[datetime]
) -> tuple[Optional[datetime], Optional[datetime]]:
    if periodo == "sempre":
        return None, None
    if periodo == "personalizzato":
        return da, a
    giorni = PERIODI_GIORNI.get(periodo)
    if giorni is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Periodo non valido")
    ora = datetime.now(timezone.utc)
    return ora - timedelta(days=giorni), ora


def _get_bankroll_utente(bankroll_id: int, utente: Utente, session: Session) -> Bankroll:
    bankroll = session.get(Bankroll, bankroll_id)
    if bankroll is None or bankroll.utente_id != utente.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bankroll non trovato")
    return bankroll


def _voce_read(v) -> VoceBreakdownRead:
    return VoceBreakdownRead(chiave=v.chiave, numero_giocate=v.numero_giocate, profitto=v.profitto, yield_=v.yield_)


def _a_metriche_read(metriche_pure) -> Optional[MetricheRead]:
    if metriche_pure is None:
        return None
    n = metriche_pure.numero_giocate
    yield_visibile = n >= SOGLIA_MINIMA_CAMPIONE
    return MetricheRead(
        numero_giocate=n,
        profitto=metriche_pure.profitto,
        giocato=metriche_pure.giocato,
        yield_=metriche_pure.yield_ if yield_visibile else None,
        rendimento_capitale=metriche_pure.rendimento_capitale if yield_visibile else None,
        win_rate=metriche_pure.win_rate,
        quota_media=metriche_pure.quota_media,
        quota_media_ponderata=metriche_pure.quota_media_ponderata,
        stake_medio=metriche_pure.stake_medio,
        yield_visibile=yield_visibile,
        stima_incerta=yield_visibile and n < SOGLIA_STIMA_INCERTA,
    )


def _giocate_periodo(
    bankroll_id: int,
    periodo: str,
    da: Optional[datetime],
    a: Optional[datetime],
    utente: Utente,
    session: Session,
    escludi_tag: Optional[str] = None,
    bookmaker: Optional[str] = None,
    tipo_giocata: Optional[TipoGiocata] = None,
) -> list[Giocata]:
    inizio, fine = _range_periodo(periodo, da, a)
    query = select(Giocata).where(Giocata.bankroll_id == bankroll_id, Giocata.utente_id == utente.id)
    if bookmaker:
        query = query.where(Giocata.bookmaker == bookmaker)
    if tipo_giocata is not None:
        query = query.where(Giocata.tipo_giocata == tipo_giocata)
    if inizio is not None:
        query = query.where(Giocata.piazzata_il >= inizio)
    if fine is not None:
        query = query.where(Giocata.piazzata_il <= fine)
    giocate = list(session.exec(query))
    if escludi_tag:
        # i tag sono una lista JSON: il filtro si fa qui, non in SQL, per restare agnostici dal DB
        giocate = [g for g in giocate if escludi_tag not in (g.tags or [])]
    return giocate


@router.get("", response_model=StatisticheRead)
def statistiche(
    bankroll_id: int,
    periodo: Literal["7g", "30g", "90g", "anno", "sempre", "personalizzato"] = "sempre",
    da: Optional[datetime] = Query(default=None),
    a: Optional[datetime] = Query(default=None),
    includi_free_bet: bool = False,
    escludi_tag: Optional[str] = None,
    bookmaker: Optional[str] = None,
    tipo_giocata: Optional[TipoGiocata] = None,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> StatisticheRead:
    _get_bankroll_utente(bankroll_id, utente, session)
    giocate = _giocate_periodo(
        bankroll_id, periodo, da, a, utente, session, escludi_tag, bookmaker, tipo_giocata
    )

    if not giocate:
        return StatisticheRead(
            numero_giocate_regolate=0,
            metriche=None,
            drawdown=None,
            serie=SerieRead(max_vinte_consecutive=0, max_perse_consecutive=0),
            breakdown=BreakdownRead(
                sport=[],
                bookmaker=[],
                tipo_giocata=[],
                fascia_quota=[],
                giorno_settimana=[],
                tag=[],
                squadra=[],
                campionato=[],
            ),
            rendimenti=[],
            margine_atteso_casuale=margine_atteso_casuale(),
        )

    giocata_ids = [g.id for g in giocate]
    selezioni = list(session.exec(select(Selezione).where(Selezione.giocata_id.in_(giocata_ids))))
    sport_per_giocata: dict[int, list[str]] = {}
    squadre_per_giocata: dict[int, list[str]] = {}
    campionati_per_giocata: dict[int, list[str]] = {}
    for s in selezioni:
        sport_per_giocata.setdefault(s.giocata_id, []).append(s.sport)
        squadre_per_giocata.setdefault(s.giocata_id, []).append(s.squadra_casa)
        if s.squadra_trasferta:
            squadre_per_giocata[s.giocata_id].append(s.squadra_trasferta)
        if s.competizione:
            campionati_per_giocata.setdefault(s.giocata_id, []).append(s.competizione)

    tutte_le_stat = [
        GiocataStat(
            profitto=g.profitto,
            stake=g.stake,
            quota_totale=g.quota_totale if g.quota_totale is not None else g.stake,
            stato=g.stato,
            piazzata_il=g.piazzata_il,
            regolata_il=g.regolata_il,
            sport=tuple(sport_per_giocata.get(g.id, [])),
            squadre=tuple(squadre_per_giocata.get(g.id, [])),
            campionati=tuple(campionati_per_giocata.get(g.id, [])),
            bookmaker=g.bookmaker,
            tipo_giocata=g.tipo_giocata.value,
            tags=g.tags,
            e_free_bet=g.e_free_bet,
        )
        for g in giocate
    ]

    rilevanti = filtra_rilevanti(tutte_le_stat, includi_free_bet=includi_free_bet)
    rilevanti_ordinate = sorted(rilevanti, key=lambda g: g.regolata_il)

    metriche_read = _a_metriche_read(calcola_metriche(rilevanti))

    drawdown_puro = calcola_drawdown(rilevanti_ordinate)
    drawdown_read = (
        DrawdownRead(
            valore_assoluto=drawdown_puro.valore_assoluto,
            percentuale=drawdown_puro.percentuale,
            data_inizio=drawdown_puro.data_inizio,
            data_fine=drawdown_puro.data_fine,
        )
        if drawdown_puro
        else None
    )

    serie_pura = calcola_serie(rilevanti_ordinate)
    serie_read = SerieRead(
        max_vinte_consecutive=serie_pura.max_vinte_consecutive,
        max_perse_consecutive=serie_pura.max_perse_consecutive,
    )

    def sport_di(gs: GiocataStat) -> list[str]:
        # una giocata conta una volta per sport, anche se ha più selezioni nello stesso sport
        return sorted(set(gs.sport)) or ["Sconosciuto"]

    def giorno_settimana_di(gs: GiocataStat) -> list[str]:
        return [GIORNI_SETTIMANA_IT[gs.piazzata_il.weekday()]]

    breakdown_read = BreakdownRead(
        sport=[_voce_read(v) for v in calcola_breakdown(rilevanti, sport_di)],
        bookmaker=[_voce_read(v) for v in calcola_breakdown(rilevanti, lambda g: [g.bookmaker])],
        tipo_giocata=[_voce_read(v) for v in calcola_breakdown(rilevanti, lambda g: [g.tipo_giocata])],
        fascia_quota=[
            _voce_read(v) for v in calcola_breakdown(rilevanti, lambda g: [fascia_quota(g.quota_totale)])
        ],
        giorno_settimana=[_voce_read(v) for v in calcola_breakdown(rilevanti, giorno_settimana_di)],
        tag=[_voce_read(v) for v in calcola_breakdown(rilevanti, lambda g: g.tags or [])],
        squadra=[
            _voce_read(v)
            for v in calcola_breakdown(rilevanti, lambda g: sorted(set(g.squadre)) or ["Sconosciuta"])
        ],
        campionato=[
            _voce_read(v)
            for v in calcola_breakdown(rilevanti, lambda g: sorted(set(g.campionati)) or ["Sconosciuto"])
        ],
    )

    rendimenti = [float(gs.profitto / gs.stake) for gs in rilevanti if gs.stake > 0]

    return StatisticheRead(
        numero_giocate_regolate=len(rilevanti),
        metriche=metriche_read,
        drawdown=drawdown_read,
        serie=serie_read,
        breakdown=breakdown_read,
        rendimenti=rendimenti,
        margine_atteso_casuale=margine_atteso_casuale(),
    )


@router.get("/aderenza", response_model=AderenzaRead)
def aderenza(
    bankroll_id: int,
    periodo: Literal["7g", "30g", "90g", "anno", "sempre", "personalizzato"] = "sempre",
    da: Optional[datetime] = Query(default=None),
    a: Optional[datetime] = Query(default=None),
    includi_free_bet: bool = False,
    escludi_tag: Optional[str] = None,
    bookmaker: Optional[str] = None,
    tipo_giocata: Optional[TipoGiocata] = None,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> AderenzaRead:
    """Analisi di aderenza alla strategia attiva (sezione 8): punteggio, costo per regola,
    rendimento delle giocate conformi confrontato con quelle che hanno violato almeno una regola.
    """
    _get_bankroll_utente(bankroll_id, utente, session)
    giocate = _giocate_periodo(
        bankroll_id, periodo, da, a, utente, session, escludi_tag, bookmaker, tipo_giocata
    )

    coppie = [
        (
            GiocataStat(
                profitto=g.profitto,
                stake=g.stake,
                quota_totale=g.quota_totale if g.quota_totale is not None else g.stake,
                stato=g.stato,
                piazzata_il=g.piazzata_il,
                regolata_il=g.regolata_il,
                e_free_bet=g.e_free_bet,
            ),
            g,
        )
        for g in giocate
    ]
    rilevanti = [
        (stat, g) for stat, g in coppie if filtra_rilevanti([stat], includi_free_bet=includi_free_bet)
    ]

    conformi_stat = []
    non_conformi_stat = []
    aderenza_input = []
    for stat, g in rilevanti:
        tipi = [TipoRegola(v["tipo"]) for v in (g.regole_violate or [])]
        aderenza_input.append(GiocataAderenza(profitto=stat.profitto, tipi_violati=tipi))
        if tipi:
            non_conformi_stat.append(stat)
        else:
            conformi_stat.append(stat)

    aderenza_pura: Optional[Aderenza] = calcola_aderenza(aderenza_input)

    def rendimenti_di(stats: list[GiocataStat]) -> list[float]:
        return [float(s.profitto / s.stake) for s in stats if s.stake > 0]

    return AderenzaRead(
        numero_giocate=aderenza_pura.numero_giocate if aderenza_pura else 0,
        numero_conformi=aderenza_pura.numero_conformi if aderenza_pura else 0,
        punteggio=aderenza_pura.punteggio if aderenza_pura else None,
        costo_per_regola=(
            [CostoRegolaRead(tipo=tipo, profitto=profitto) for tipo, profitto in aderenza_pura.costo_per_regola]
            if aderenza_pura
            else []
        ),
        metriche_conformi=_a_metriche_read(calcola_metriche(conformi_stat)),
        metriche_non_conformi=_a_metriche_read(calcola_metriche(non_conformi_stat)),
        rendimenti_conformi=rendimenti_di(conformi_stat),
        rendimenti_non_conformi=rendimenti_di(non_conformi_stat),
    )
