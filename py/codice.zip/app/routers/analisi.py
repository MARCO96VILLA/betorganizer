from datetime import datetime, timezone
from typing import Callable, Literal, Optional

from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from sqlmodel import Session, select

from app.auth import get_current_user
from app.db import get_session
from app.domain import analytics as an
from app.domain.bonus import CondizioniBonus, giorni_rimanenti, verifica_requisiti
from app.domain.tempo import da_locale_a_utc
from app.models import Giocata, MovimentoBankroll, Selezione, Utente
from app.models.enums import EsitoSelezione, StatoGiocata, TipoGiocata, TipoMovimento
from app.routers.statistiche import _get_bankroll_utente, _giocate_periodo
from app.schemas.analisi import (
    AnalisiBozzaRead,
    AnalisiRead,
    BonusBozzaRead,
    BozzaGiocata,
    RequisitoRead,
    SelezioneBozzaRead,
    SovrapposizioneRead,
    EsposizioneEventoRead,
    FamigliaFallitaRead,
    GambaFallitaRead,
    PuntoCumulatoRead,
    QuasiVincitaRead,
    QuasiVinciteRead,
    ValoreBonusRead,
    VinteAtteseRead,
    VoceGambaRead,
    VoceGruppoRead,
)

router = APIRouter(prefix="/api/analisi", tags=["analisi"])

ORDINE_FASCE_ORARIE = ["Notte (00–06)", "Mattina (06–12)", "Pomeriggio (12–18)", "Sera (18–24)"]
ORDINE_ANTICIPO = [
    "A evento iniziato",
    "Meno di 1 ora prima",
    "1–6 ore prima",
    "6–24 ore prima",
    "Più di 24 ore prima",
]
ORDINE_GAMBE = ["1 giocata (singola)", "2 giocate", "3 giocate", "4 giocate", "5 giocate", "6–7 giocate", "8 o più giocate"]
ORDINE_STAKE = ["meno di 10 €", "10–20 €", "20–50 €", "50 € o più"]
ORDINE_QUOTA_GAMBA = [etichetta for _, _, etichetta in an.FASCE_QUOTA_GAMBA]


def _a_selezione_an(s: Selezione) -> an.SelezioneAn:
    return an.SelezioneAn(
        sport=s.sport,
        squadra_casa=s.squadra_casa,
        mercato=s.mercato,
        quota=s.quota,
        esito=s.esito,
        competizione=s.competizione,
        squadra_trasferta=s.squadra_trasferta,
        esito_giocato=s.esito_giocato,
        inizio_evento=s.inizio_evento,
        mercato_giocatore=s.mercato_giocatore,
        bet_builder=s.bet_builder,
    )


def _a_giocata_an(g: Giocata, selezioni: list[Selezione]) -> an.GiocataAn:
    return an.GiocataAn(
        id=g.id,
        stato=g.stato,
        stake=g.stake,
        profitto=g.profitto,
        quota_totale=g.quota_totale if g.quota_totale is not None else g.stake,
        piazzata_il=g.piazzata_il,
        regolata_il=g.regolata_il,
        selezioni=tuple(_a_selezione_an(s) for s in sorted(selezioni, key=lambda s: s.ordine)),
        bonus_multipla_pct=g.bonus_multipla_pct,
        bookmaker=g.bookmaker,
        e_free_bet=g.e_free_bet,
        orario_approssimato=g.orario_approssimato,
        tags=tuple(g.tags or []),
    )


def _ordina(voci: list, ordine: list[str]) -> list:
    posizione = {chiave: i for i, chiave in enumerate(ordine)}
    return sorted(voci, key=lambda v: (posizione.get(v.chiave, len(ordine)), v.chiave))


def _gambe_read(voci: list[an.VoceGamba], ordine: Optional[list[str]] = None) -> list[VoceGambaRead]:
    voci = _ordina(voci, ordine) if ordine else sorted(voci, key=lambda v: (-v.gambe, v.chiave))
    return [VoceGambaRead(**v.__dict__) for v in voci]


def _gruppo_read(voci: list[an.VoceGruppo], ordine: Optional[list[str]] = None) -> list[VoceGruppoRead]:
    voci = _ordina(voci, ordine) if ordine else sorted(voci, key=lambda v: v.chiave)
    return [VoceGruppoRead(**v.__dict__) for v in voci]


@router.get("", response_model=AnalisiRead)
def analisi(
    bankroll_id: int,
    periodo: Literal["7g", "30g", "90g", "anno", "sempre", "personalizzato"] = "sempre",
    da: Optional[datetime] = Query(default=None),
    a: Optional[datetime] = Query(default=None),
    includi_free_bet: bool = False,
    escludi_tag: Optional[str] = None,
    bookmaker: Optional[str] = None,
    tipo_giocata: Optional[TipoGiocata] = None,
    sport: Optional[str] = None,
    competizione: Optional[str] = None,
    famiglia: Optional[str] = None,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> AnalisiRead:
    """Analisi dello storico: tassi di centro per gamba (mercato, squadra, campionato, quota),
    pattern comportamentali (orario, anticipo, numero di gambe, stake), quasi-vincite ed esposizione.
    """
    _get_bankroll_utente(bankroll_id, utente, session)
    giocate = _giocate_periodo(
        bankroll_id, periodo, da, a, utente, session, escludi_tag, bookmaker, tipo_giocata
    )

    selezioni_per_giocata: dict[int, list[Selezione]] = {}
    if giocate:
        for s in session.exec(
            select(Selezione).where(Selezione.giocata_id.in_([g.id for g in giocate]))
        ):
            selezioni_per_giocata.setdefault(s.giocata_id, []).append(s)

    tutte = [_a_giocata_an(g, selezioni_per_giocata.get(g.id, [])) for g in giocate]
    rilevanti = an.regolate_rilevanti(tutte, includi_free_bet=includi_free_bet)
    coppie = an.selezioni_affidabili(rilevanti)
    # sport, campionato e tipo di mercato riguardano la singola giocata: filtrano solo le viste per giocata
    if sport or competizione or famiglia:
        coppie = [
            (g, s)
            for g, s in coppie
            if (not sport or s.sport == sport)
            and (not competizione or s.competizione == competizione)
            and (not famiglia or an.famiglia_selezione(s) == famiglia)
        ]

    def per_gamba(fn: Callable[[an.GiocataAn, an.SelezioneAn], list[str]], ordine=None):
        return _gambe_read(an.calcola_tasso_gambe(coppie, fn), ordine)

    def per_giocata(fn: Callable[[an.GiocataAn], list[str]], ordine=None):
        return _gruppo_read(an.aggrega_per_chiave(rilevanti, fn), ordine)

    def squadre_coinvolte(_g, s):
        return [s.squadra_casa] + ([s.squadra_trasferta] if s.squadra_trasferta else [])

    def squadra_puntata(_g, s):
        squadra = an.squadra_puntata(s)
        return [squadra] if squadra else []

    def anticipo(g):
        ore = an.anticipo_ore(g)
        return [an.fascia_anticipo(ore)] if ore is not None else []

    def fascia_oraria(g):
        return [] if g.orario_approssimato else [an.fascia_oraria(g.piazzata_il)]

    quasi = an.analizza_quasi_vincite(rilevanti)
    attese = an.vinte_attese_giocate(rilevanti)
    bonus = an.valore_bonus(rilevanti)

    return AnalisiRead(
        giocate_regolate=len(rilevanti),
        gambe_valutate=len(coppie),
        per_famiglia=per_gamba(lambda g, s: [an.famiglia_selezione(s)]),
        per_mercato=per_gamba(lambda g, s: [s.mercato]),
        per_tipo_mercato=per_gamba(
            lambda g, s: ["Combinato" if an.e_mercato_combinato(s.mercato) else "Semplice"]
        ),
        per_squadra_coinvolta=per_gamba(squadre_coinvolte),
        per_squadra_puntata=per_gamba(squadra_puntata),
        per_competizione=per_gamba(lambda g, s: [s.competizione or "Sconosciuta"]),
        per_sport=per_gamba(lambda g, s: [s.sport]),
        per_fascia_quota_gamba=per_gamba(
            lambda g, s: [an.fascia_quota_gamba(s.quota)], ORDINE_QUOTA_GAMBA
        ),
        per_numero_gambe=per_giocata(lambda g: [an.fascia_gambe(len(g.selezioni))], ORDINE_GAMBE),
        per_fascia_oraria=per_giocata(fascia_oraria, ORDINE_FASCE_ORARIE),
        per_giorno_settimana=per_giocata(
            lambda g: [an.giorno_settimana(g.piazzata_il)], an.GIORNI_SETTIMANA
        ),
        per_anticipo=per_giocata(anticipo, ORDINE_ANTICIPO),
        per_fascia_stake=per_giocata(lambda g: [an.fascia_stake(g.stake)], ORDINE_STAKE),
        per_bookmaker=per_giocata(lambda g: [g.bookmaker]),
        per_mese=per_giocata(lambda g: [an.mese_di(g.regolata_il or g.piazzata_il)]),
        per_giorno=per_giocata(lambda g: [an.giorno_di(g.regolata_il or g.piazzata_il)]),
        serie_cumulata=[PuntoCumulatoRead(**p.__dict__) for p in an.serie_cumulata(rilevanti)],
        vinte_attese=VinteAtteseRead(**attese.__dict__),
        quasi_vincite=QuasiVinciteRead(
            multiple_perse=quasi.multiple_perse,
            perse_per_una_gamba=quasi.perse_per_una_gamba,
            stake_perso_per_una_gamba=quasi.stake_perso_per_una_gamba,
            mancato_ritorno=quasi.mancato_ritorno,
            famiglie_gamba_fallita=[
                FamigliaFallitaRead(famiglia=nome, conteggio=n)
                for nome, n in quasi.famiglie_gamba_fallita
            ],
            elenco=[
                QuasiVincitaRead(
                    giocata_id=q.giocata_id,
                    stake=q.stake,
                    mancato_ritorno=q.mancato_ritorno,
                    gambe=q.gambe,
                    gamba_fallita=GambaFallitaRead(
                        squadra_casa=q.gamba_fallita.squadra_casa,
                        squadra_trasferta=q.gamba_fallita.squadra_trasferta,
                        mercato=q.gamba_fallita.mercato,
                        esito_giocato=q.gamba_fallita.esito_giocato,
                        quota=q.gamba_fallita.quota,
                    ),
                )
                for q in quasi.elenco
            ],
        ),
        esposizione_eventi=[EsposizioneEventoRead(**e.__dict__) for e in an.esposizione_eventi(tutte)],
        bonus=ValoreBonusRead(**bonus.__dict__),
    )


TAG_STORICO_SCREENSHOT = "storico-screenshot"


def _condizioni_da_json(dati: Optional[dict]) -> CondizioniBonus:
    dati = dati or {}

    def dec(chiave):
        return Decimal(str(dati[chiave])) if dati.get(chiave) is not None else None

    return CondizioniBonus(
        selezioni_minime=dati.get("selezioni_minime"),
        quota_minima_evento=dec("quota_minima_evento"),
        quota_minima_totale=dec("quota_minima_totale"),
        stake_minimo=dec("stake_minimo"),
    )


@router.post("/prima-di-giocare", response_model=AnalisiBozzaRead)
def prima_di_giocare(
    bozza: BozzaGiocata,
    escludi_tag: Optional[str] = None,
    utente: Utente = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> AnalisiBozzaRead:
    """Cosa si sa di una schedina prima di giocarla: costo del margine, probabilità di pareggio, storico
    dell'utente per tipo di mercato e fascia di quota, partite già presenti in schedine aperte e requisiti
    dei bonus attivi. Nulla viene salvato.
    """
    _get_bankroll_utente(bozza.bankroll_id, utente, session)
    giocate = _giocate_periodo(bozza.bankroll_id, "sempre", None, None, utente, session, escludi_tag)
    selezioni_per_giocata: dict[int, list[Selezione]] = {}
    if giocate:
        for sel in session.exec(
            select(Selezione).where(Selezione.giocata_id.in_([g.id for g in giocate]))
        ):
            selezioni_per_giocata.setdefault(sel.giocata_id, []).append(sel)
    tutte = [_a_giocata_an(g, selezioni_per_giocata.get(g.id, [])) for g in giocate]

    coppie = an.selezioni_affidabili(an.regolate_rilevanti(tutte, includi_free_bet=True))
    selezioni_bozza = [
        an.SelezioneAn(
            sport=s.sport,
            squadra_casa=s.squadra_casa,
            mercato=s.mercato,
            quota=s.quota,
            esito=EsitoSelezione.PENDENTE,
            competizione=s.competizione,
            squadra_trasferta=s.squadra_trasferta,
            esito_giocato=s.esito_giocato,
            inizio_evento=da_locale_a_utc(s.inizio_evento) if s.inizio_evento else None,
            mercato_giocatore=s.mercato_giocatore,
            bet_builder=bool(s.componenti),
        )
        for s in bozza.selezioni
    ]

    analisi_bozza = an.analizza_bozza(selezioni_bozza, coppie, bozza.bonus_multipla_pct)
    sovrapposte = an.sovrapposizioni_bozza(selezioni_bozza, tutte)

    ora = datetime.now(timezone.utc).replace(tzinfo=None)
    quote = [s.quota for s in bozza.selezioni]
    bonus_letti: list[BonusBozzaRead] = []
    movimenti = session.exec(
        select(MovimentoBankroll).where(
            MovimentoBankroll.bankroll_id == bozza.bankroll_id,
            MovimentoBankroll.tipo == TipoMovimento.BONUS,
        )
    )
    for m in movimenti:
        if m.scadenza is not None and m.scadenza <= ora:
            continue
        if m.bookmaker and bozza.bookmaker and m.bookmaker.casefold() != bozza.bookmaker.casefold():
            continue
        condizioni = _condizioni_da_json(m.condizioni)
        if condizioni.e_vuota():
            continue
        requisiti = verifica_requisiti(condizioni, quote, bozza.stake)
        bonus_letti.append(
            BonusBozzaRead(
                movimento_id=m.id,
                importo=m.importo,
                bookmaker=m.bookmaker,
                scadenza=m.scadenza,
                giorni_rimanenti=giorni_rimanenti(m.scadenza, ora),
                requisiti=[RequisitoRead(descrizione=r.descrizione, soddisfatto=r.soddisfatto) for r in requisiti],
                rispettati=all(r.soddisfatto for r in requisiti),
            )
        )

    schede_screenshot = {g.id for g in tutte if TAG_STORICO_SCREENSHOT in g.tags}
    return AnalisiBozzaRead(
        numero_giocate=len(selezioni_bozza),
        quota_totale=analisi_bozza.quota_totale,
        probabilita_pareggio=analisi_bozza.probabilita_pareggio,
        margine_ipotetico=analisi_bozza.margine_ipotetico,
        ritorno_atteso_per_euro=analisi_bozza.ritorno_atteso_per_euro,
        probabilita_dallo_storico=analisi_bozza.probabilita_dallo_storico,
        ritorno_atteso_storico=analisi_bozza.ritorno_atteso_storico,
        selezioni=[
            SelezioneBozzaRead(
                famiglia=s.famiglia,
                fascia_quota=s.fascia_quota,
                quota=s.quota,
                probabilita_implicita=s.probabilita_implicita,
                storico_famiglia=VoceGambaRead(**s.storico_famiglia.__dict__) if s.storico_famiglia else None,
                storico_fascia=VoceGambaRead(**s.storico_fascia.__dict__) if s.storico_fascia else None,
            )
            for s in analisi_bozza.selezioni
        ],
        sovrapposizioni=[SovrapposizioneRead(**x.__dict__) for x in sovrapposte],
        bonus=bonus_letti,
        giocate_storico=len(coppie),
        giocate_storico_da_screenshot=sum(1 for g, _ in coppie if g.id in schede_screenshot),
    )
