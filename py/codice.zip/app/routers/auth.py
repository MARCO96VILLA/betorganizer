from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlmodel import Session, select

from app.auth import create_access_token, get_current_user, hash_password, verify_password
from app.config import settings
from app.db import get_session
from app.models import Bankroll, Utente
from app.schemas.auth import LoginRequest, RegistrazioneRequest, UtenteRead

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _set_session_cookie(response: Response, utente_id: int) -> None:
    token = create_access_token(utente_id)
    response.set_cookie(
        key=settings.cookie_name,
        value=token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=settings.jwt_expire_minutes * 60,
    )


@router.post("/registrati", response_model=UtenteRead, status_code=status.HTTP_201_CREATED)
def registrati(
    dati: RegistrazioneRequest,
    response: Response,
    session: Session = Depends(get_session),
) -> Utente:
    if dati.codice_invito != settings.invite_code:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Codice invito non valido")

    esistente = session.exec(select(Utente).where(Utente.email == dati.email)).first()
    if esistente is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email già registrata")

    utente = Utente(email=dati.email, password_hash=hash_password(dati.password), nome=dati.nome)
    session.add(utente)
    session.commit()
    session.refresh(utente)

    session.add(Bankroll(utente_id=utente.id, nome="Principale"))
    session.commit()

    _set_session_cookie(response, utente.id)
    return utente


@router.post("/accedi", response_model=UtenteRead)
def accedi(
    dati: LoginRequest,
    response: Response,
    session: Session = Depends(get_session),
) -> Utente:
    credenziali_non_valide = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenziali non valide"
    )
    utente = session.exec(select(Utente).where(Utente.email == dati.email)).first()
    if utente is None or not verify_password(dati.password, utente.password_hash):
        raise credenziali_non_valide

    _set_session_cookie(response, utente.id)
    return utente


@router.post("/esci", status_code=status.HTTP_204_NO_CONTENT)
def esci(response: Response) -> None:
    response.delete_cookie(key=settings.cookie_name)


@router.get("/me", response_model=UtenteRead)
def me(utente: Utente = Depends(get_current_user)) -> Utente:
    return utente
