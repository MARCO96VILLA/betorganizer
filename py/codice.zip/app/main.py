from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import analisi, auth, bankroll, esporta, giocate, lettura, statistiche, strategie

app = FastAPI(title="Bet Tracker API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analisi.router)
app.include_router(auth.router)
app.include_router(bankroll.router)
app.include_router(esporta.router)
app.include_router(giocate.router)
app.include_router(lettura.router)
app.include_router(statistiche.router)
app.include_router(strategie.router)


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok"}
