from datetime import datetime, timezone
from typing import Optional

from sqlmodel import Field, SQLModel


class Strategia(SQLModel, table=True):
    __tablename__ = "strategia"

    id: Optional[int] = Field(default=None, primary_key=True)
    utente_id: int = Field(foreign_key="utente.id", index=True)
    bankroll_id: int = Field(foreign_key="bankroll.id", index=True)
    nome: str
    attiva: bool = Field(default=True)
    creata_il: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
