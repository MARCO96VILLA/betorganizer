from typing import Any, Optional

from sqlalchemy import Column, JSON
from sqlmodel import Field, SQLModel

from app.models.enums import TipoRegola


class Regola(SQLModel, table=True):
    __tablename__ = "regola"

    id: Optional[int] = Field(default=None, primary_key=True)
    strategia_id: int = Field(foreign_key="strategia.id", index=True)
    tipo: TipoRegola
    valore: Any = Field(sa_column=Column(JSON))
    attiva: bool = Field(default=True)
