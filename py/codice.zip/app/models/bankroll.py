from datetime import datetime, timezone
from typing import Optional

from sqlmodel import Field, SQLModel


class Bankroll(SQLModel, table=True):
    __tablename__ = "bankroll"

    id: Optional[int] = Field(default=None, primary_key=True)
    utente_id: int = Field(foreign_key="utente.id", index=True)
    nome: str
    valuta: str = Field(default="EUR")
    colore: Optional[str] = None
    archiviato: bool = Field(default=False)
    creato_il: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
