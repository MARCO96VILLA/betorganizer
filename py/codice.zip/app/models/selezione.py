from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import JSON, Column, Numeric
from sqlmodel import Field, SQLModel

from app.models.enums import EsitoSelezione


class Selezione(SQLModel, table=True):
    __tablename__ = "selezione"

    id: Optional[int] = Field(default=None, primary_key=True)
    giocata_id: int = Field(foreign_key="giocata.id", index=True)
    ordine: int

    sport: str
    competizione: Optional[str] = None
    squadra_casa: str
    squadra_trasferta: Optional[str] = None
    mercato: str
    # la scelta specifica dentro al mercato (es. mercato="Ov 1T + Ov 2T", esito_giocato="0.5 - 0.5").
    # non va confuso con `esito`, che è lo stato di regolazione (vinta/persa/...).
    esito_giocato: Optional[str] = None
    quota: Decimal = Field(sa_column=Column(Numeric(10, 3)))
    esito: EsitoSelezione = Field(default=EsitoSelezione.PENDENTE)
    inizio_evento: Optional[datetime] = None
    # risultato finale dell'evento come testo libero (es. "2-1"), solo informativo
    risultato_evento: Optional[str] = None
    # True per i mercati sulle statistiche di un singolo giocatore (marcatore, tiri, ecc.)
    mercato_giocatore: bool = Field(default=False)
    # Bet builder: più mercati sulla stessa partita con UNA sola quota (quella dell'evento). Ogni voce è
    # {"mercato", "esito_giocato", "mercato_giocatore"}; `mercato` ed `esito_giocato` della selezione ne sono la sintesi.
    componenti: Optional[list] = Field(default=None, sa_column=Column(JSON))

    @property
    def bet_builder(self) -> bool:
        return bool(self.componenti) and len(self.componenti) >= 2
