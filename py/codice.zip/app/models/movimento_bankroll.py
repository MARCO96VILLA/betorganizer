from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from sqlalchemy import Column, Numeric
from sqlmodel import JSON, Field, SQLModel

from app.models.enums import TipoMovimento


class MovimentoBankroll(SQLModel, table=True):
    __tablename__ = "movimento_bankroll"

    id: Optional[int] = Field(default=None, primary_key=True)
    bankroll_id: int = Field(foreign_key="bankroll.id", index=True)
    tipo: TipoMovimento
    importo: Decimal = Field(sa_column=Column(Numeric(10, 2)))
    data: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    nota: Optional[str] = None
    # conto (bookmaker) a cui si riferisce il movimento; None = non assegnato a un conto specifico
    bookmaker: Optional[str] = Field(default=None, index=True)
    # solo per i bonus: entro quando va usato e quali condizioni deve rispettare la schedina
    # (chiavi: selezioni_minime, quota_minima_evento, quota_minima_totale, stake_minimo)
    scadenza: Optional[datetime] = None
    condizioni: Optional[dict[str, Any]] = Field(default=None, sa_column=Column(JSON))
