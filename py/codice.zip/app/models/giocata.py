from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from sqlalchemy import Column, Numeric
from sqlmodel import JSON, Field, SQLModel

from app.models.enums import StatoGiocata, TipoGiocata


class Giocata(SQLModel, table=True):
    __tablename__ = "giocata"

    id: Optional[int] = Field(default=None, primary_key=True)
    bankroll_id: int = Field(foreign_key="bankroll.id", index=True)
    utente_id: int = Field(foreign_key="utente.id", index=True)

    tipo_giocata: TipoGiocata
    bookmaker: str
    stake: Decimal = Field(sa_column=Column(Numeric(10, 2)))
    quota_totale: Optional[Decimal] = Field(default=None, sa_column=Column(Numeric(10, 3)))
    e_free_bet: bool = Field(default=False)
    # maggiorazione percentuale sulla vincita delle multiple (bonus multipla del bookmaker)
    bonus_multipla_pct: Decimal = Field(
        default=Decimal("0"),
        sa_column=Column(Numeric(6, 2), nullable=False, server_default="0"),
    )
    stato: StatoGiocata = Field(default=StatoGiocata.PENDENTE)

    piazzata_il: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    regolata_il: Optional[datetime] = None

    ritorno_lordo: Decimal = Field(default=Decimal("0"), sa_column=Column(Numeric(10, 2)))
    profitto: Decimal = Field(default=Decimal("0"), sa_column=Column(Numeric(10, 2)))

    cashout_importo: Optional[Decimal] = Field(default=None, sa_column=Column(Numeric(10, 2)))
    cashout_stake_liberato: Optional[Decimal] = Field(
        default=None, sa_column=Column(Numeric(10, 2))
    )

    strategia_id: Optional[int] = Field(default=None, foreign_key="strategia.id")
    regole_violate: list[Any] = Field(default_factory=list, sa_column=Column(JSON))
    # identificativo della schedina nel sistema di origine (usato per evitare doppie importazioni)
    riferimento_esterno: Optional[str] = Field(default=None, index=True)
    # True se l'orario di piazzamento è una stima (non visibile sullo screenshot di origine)
    orario_approssimato: bool = Field(default=False)
    note: Optional[str] = None
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
