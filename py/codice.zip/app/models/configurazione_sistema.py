from decimal import Decimal
from typing import Optional

from sqlalchemy import Column, Numeric
from sqlmodel import JSON, Field, SQLModel


class ConfigurazioneSistema(SQLModel, table=True):
    __tablename__ = "configurazione_sistema"

    id: Optional[int] = Field(default=None, primary_key=True)
    giocata_id: int = Field(foreign_key="giocata.id", index=True, unique=True)
    combinazioni_attive: list[int] = Field(default_factory=list, sa_column=Column(JSON))
    stake_per_combinazione: Decimal = Field(sa_column=Column(Numeric(10, 2)))
