from datetime import datetime, timezone
from typing import Optional

from sqlmodel import Field, SQLModel


class Utente(SQLModel, table=True):
    __tablename__ = "utente"

    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(unique=True, index=True)
    password_hash: str
    nome: str
    creato_il: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    fuso_orario: str = Field(default="Europe/Rome")
