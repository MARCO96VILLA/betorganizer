from enum import Enum


class TipoGiocata(str, Enum):
    SINGOLA = "singola"
    MULTIPLA = "multipla"
    SISTEMA = "sistema"


class StatoGiocata(str, Enum):
    PENDENTE = "pendente"
    VINTA = "vinta"
    PERSA = "persa"
    ANNULLATA = "annullata"
    MEZZA_VINTA = "mezza_vinta"
    MEZZA_PERSA = "mezza_persa"
    CASHOUT = "cashout"


class EsitoSelezione(str, Enum):
    PENDENTE = "pendente"
    VINTA = "vinta"
    PERSA = "persa"
    ANNULLATA = "annullata"
    MEZZA_VINTA = "mezza_vinta"
    MEZZA_PERSA = "mezza_persa"


class TipoMovimento(str, Enum):
    DEPOSITO = "deposito"
    PRELIEVO = "prelievo"
    RETTIFICA = "rettifica"
    # credito promozionale accreditato dal bookmaker, spendibile come saldo reale
    BONUS = "bonus"


class TipoRegola(str, Enum):
    QUOTA_MINIMA = "quota_minima"
    QUOTA_MASSIMA = "quota_massima"
    STAKE_MASSIMO_ASSOLUTO = "stake_massimo_assoluto"
    STAKE_MASSIMO_PERCENTUALE = "stake_massimo_percentuale"
    MAX_GIOCATE_GIORNO = "max_giocate_giorno"
    MAX_SELEZIONI_MULTIPLA = "max_selezioni_multipla"
    SPORT_AMMESSI = "sport_ammessi"
    TIPI_GIOCATA_AMMESSI = "tipi_giocata_ammessi"
    COOLDOWN_DOPO_PERDITA_MINUTI = "cooldown_dopo_perdita_minuti"
    PERDITA_MASSIMA_GIORNALIERA = "perdita_massima_giornaliera"
