"""Quando una partita si può considerare iniziata o finita, per distinguere le giocate da giocare,
in corso e da regolare. Pura: l'ora corrente si passa dall'esterno.
"""

from datetime import datetime, timedelta
from typing import Iterable, Optional

# durata massima plausibile di un evento dall'orario di inizio (calcio con recupero e supplementari
# esclusi, tennis e basket compresi): oltre questo margine l'esito è comunque già noto al bookmaker
DURATA_EVENTO = timedelta(hours=2, minutes=30)

FUTURO = "futuro"
LIVE = "live"
CONCLUSO = "concluso"

DA_GIOCARE = "da_giocare"
IN_CORSO = "in_corso"
DA_REGOLARE = "da_regolare"


def fase_evento(inizio: Optional[datetime], ora: datetime) -> str:
    """'futuro' se non è ancora iniziato (o manca l'orario), 'live' se è in svolgimento, 'concluso'
    se è iniziato da più di DURATA_EVENTO."""
    if inizio is None or inizio > ora:
        return FUTURO
    return CONCLUSO if inizio + DURATA_EVENTO < ora else LIVE


def evento_concluso(inizio: Optional[datetime], ora: datetime) -> bool:
    """True se l'evento è iniziato da più di DURATA_EVENTO. Senza orario non si può dire: False."""
    return fase_evento(inizio, ora) == CONCLUSO


def fase_giocata(
    inizi_selezioni_pendenti: Iterable[Optional[datetime]],
    ci_sono_selezioni_regolate: bool,
    ora: datetime,
) -> Optional[str]:
    """Fase di una giocata pendente, dalle partite delle sue selezioni ancora pendenti.

    - `da_regolare`: tutte le partite pendenti sono concluse, manca solo l'esito;
    - `da_giocare`: nessuna partita è ancora iniziata e nessuna selezione è già regolata;
    - `in_corso`: tutto il resto (una partita in svolgimento, oppure alcune già finite e altre da giocare).

    Senza selezioni pendenti non c'è nulla da dire: None.
    """
    fasi = [fase_evento(i, ora) for i in inizi_selezioni_pendenti]
    if not fasi:
        return None
    if all(f == CONCLUSO for f in fasi):
        return DA_REGOLARE
    if all(f == FUTURO for f in fasi) and not ci_sono_selezioni_regolate:
        return DA_GIOCARE
    return IN_CORSO


def giocata_da_regolare(inizi_selezioni_pendenti: Iterable[Optional[datetime]], ora: datetime) -> bool:
    """Una giocata pendente è 'da regolare' quando tutte le sue selezioni ancora pendenti sono concluse.

    Se non ha selezioni pendenti (o ne ha una sola senza orario) non è da regolare.
    """
    return fase_giocata(inizi_selezioni_pendenti, False, ora) == DA_REGOLARE
