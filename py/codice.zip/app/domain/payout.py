from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP

from app.models.enums import EsitoSelezione, StatoGiocata

DUE_DECIMALI = Decimal("0.01")
TRE_DECIMALI = Decimal("0.001")


def arrotonda_importo(valore: Decimal) -> Decimal:
    return valore.quantize(DUE_DECIMALI, rounding=ROUND_HALF_UP)


def arrotonda_quota(valore: Decimal) -> Decimal:
    return valore.quantize(TRE_DECIMALI, rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class SelezioneEsito:
    quota: Decimal
    esito: EsitoSelezione


@dataclass(frozen=True)
class RisultatoPayout:
    quota_effettiva: Decimal
    ritorno_lordo: Decimal
    profitto: Decimal


def quota_effettiva_selezione(quota: Decimal, esito: EsitoSelezione) -> Decimal:
    """Quota con cui una selezione contribuisce al prodotto della giocata, dato il suo esito."""
    if esito == EsitoSelezione.VINTA:
        return quota
    if esito == EsitoSelezione.PERSA:
        return Decimal("0")
    if esito == EsitoSelezione.ANNULLATA:
        return Decimal("1")
    if esito == EsitoSelezione.MEZZA_VINTA:
        return (quota + Decimal("1")) / Decimal("2")
    if esito == EsitoSelezione.MEZZA_PERSA:
        return Decimal("0.5")
    raise ValueError(f"Esito non regolabile: {esito}")


def quota_totale_dichiarata(quote: list[Decimal]) -> Decimal:
    """Prodotto delle quote inserite dall'utente, indipendente dall'esito (per il campo quota_totale)."""
    totale = Decimal("1")
    for quota in quote:
        totale *= quota
    return totale


def quota_effettiva_totale(selezioni: list[SelezioneEsito]) -> Decimal:
    totale = Decimal("1")
    for selezione in selezioni:
        totale *= quota_effettiva_selezione(selezione.quota, selezione.esito)
    return totale


def calcola_payout(
    stake: Decimal,
    selezioni: list[SelezioneEsito],
    e_free_bet: bool = False,
    bonus_multipla_pct: Decimal = Decimal("0"),
) -> RisultatoPayout:
    """Payout di una giocata singola o multipla già regolata (sezione 5.1 e 5.4).

    `bonus_multipla_pct` è la maggiorazione percentuale che alcuni bookmaker applicano alla
    vincita delle multiple: si applica al ritorno, mai alla quota effettiva né allo stake.
    """
    q_eff = quota_effettiva_totale(selezioni)
    moltiplicatore_bonus = Decimal("1") + bonus_multipla_pct / Decimal("100")
    q_con_bonus = q_eff * moltiplicatore_bonus

    if e_free_bet:
        profitto = max(stake * (q_con_bonus - Decimal("1")), Decimal("0"))
        ritorno_lordo = profitto
    else:
        ritorno_lordo = stake * q_con_bonus
        profitto = ritorno_lordo - stake

    return RisultatoPayout(
        quota_effettiva=q_eff,
        ritorno_lordo=arrotonda_importo(ritorno_lordo),
        profitto=arrotonda_importo(profitto),
    )


def deriva_stato_giocata(selezioni: list[SelezioneEsito]) -> StatoGiocata:
    """Etichetta complessiva di una singola/multipla regolata, dagli esiti delle selezioni.

    Tutte le selezioni devono essere già regolate (nessuna PENDENTE).
    """
    esiti = [s.esito for s in selezioni]
    if EsitoSelezione.PENDENTE in esiti:
        raise ValueError("Non tutte le giocate sono state regolate")

    if any(e == EsitoSelezione.PERSA for e in esiti):
        return StatoGiocata.PERSA
    if all(e == EsitoSelezione.ANNULLATA for e in esiti):
        return StatoGiocata.ANNULLATA
    if any(e in (EsitoSelezione.MEZZA_VINTA, EsitoSelezione.MEZZA_PERSA) for e in esiti):
        q_eff = quota_effettiva_totale(selezioni)
        return StatoGiocata.MEZZA_VINTA if q_eff >= 1 else StatoGiocata.MEZZA_PERSA
    return StatoGiocata.VINTA


def calcola_cashout_totale(stake: Decimal, cashout_importo: Decimal) -> RisultatoPayout:
    """Chiusura con cash-out totale (sezione 5.3): il valore incassato sostituisce l'esito."""
    profitto = cashout_importo - stake
    return RisultatoPayout(
        quota_effettiva=Decimal("0"),
        ritorno_lordo=arrotonda_importo(cashout_importo),
        profitto=arrotonda_importo(profitto),
    )


def calcola_cashout_parziale_finale(
    stake: Decimal,
    cashout_importo: Decimal,
    cashout_stake_liberato: Decimal,
    selezioni: list[SelezioneEsito],
) -> RisultatoPayout:
    """Regolazione finale di un cash-out parziale: incassato ora + esito sullo stake residuo."""
    if cashout_stake_liberato >= stake:
        raise ValueError("cashout_stake_liberato deve essere minore dello stake")
    if cashout_importo <= 0:
        raise ValueError("cashout_importo deve essere maggiore di zero")

    stake_residuo = stake - cashout_stake_liberato
    q_eff = quota_effettiva_totale(selezioni)
    ritorno_residuo = stake_residuo * q_eff
    ritorno_lordo = cashout_importo + ritorno_residuo
    profitto = ritorno_lordo - stake

    return RisultatoPayout(
        quota_effettiva=q_eff,
        ritorno_lordo=arrotonda_importo(ritorno_lordo),
        profitto=arrotonda_importo(profitto),
    )
