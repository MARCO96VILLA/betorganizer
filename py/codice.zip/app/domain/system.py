from dataclasses import dataclass
from decimal import Decimal
from itertools import combinations
from math import comb

from app.domain.payout import SelezioneEsito, arrotonda_importo, quota_effettiva_selezione
from app.models.enums import EsitoSelezione, StatoGiocata


@dataclass(frozen=True)
class RisultatoSistema:
    numero_linee: int
    stake_totale: Decimal
    ritorno_lordo: Decimal
    profitto: Decimal


def numero_linee(numero_selezioni: int, combinazioni_attive: list[int]) -> int:
    """Numero totale di linee di un sistema: somma di C(N, k) per ogni k attivo (sezione 5.2)."""
    return sum(comb(numero_selezioni, k) for k in combinazioni_attive)


def stake_totale_sistema(
    stake_per_combinazione: Decimal, numero_selezioni: int, combinazioni_attive: list[int]
) -> Decimal:
    return stake_per_combinazione * numero_linee(numero_selezioni, combinazioni_attive)


def calcola_payout_sistema(
    stake_per_combinazione: Decimal,
    selezioni: list[SelezioneEsito],
    combinazioni_attive: list[int],
) -> RisultatoSistema:
    """Payout di un sistema già regolato: ogni combinazione calcolata a sé, poi sommata."""
    n = len(selezioni)
    linee = numero_linee(n, combinazioni_attive)
    stake_totale = stake_per_combinazione * linee

    ritorno_lordo = Decimal("0")
    for k in combinazioni_attive:
        for indici in combinations(range(n), k):
            quota_combinazione = Decimal("1")
            for i in indici:
                quota_combinazione *= quota_effettiva_selezione(
                    selezioni[i].quota, selezioni[i].esito
                )
            ritorno_lordo += stake_per_combinazione * quota_combinazione

    profitto = ritorno_lordo - stake_totale

    return RisultatoSistema(
        numero_linee=linee,
        stake_totale=arrotonda_importo(stake_totale),
        ritorno_lordo=arrotonda_importo(ritorno_lordo),
        profitto=arrotonda_importo(profitto),
    )


def deriva_stato_sistema(
    risultato: RisultatoSistema, selezioni: list[SelezioneEsito]
) -> StatoGiocata:
    """Etichetta complessiva di un sistema regolato, dal risultato aggregato e dagli esiti."""
    esiti = [s.esito for s in selezioni]
    if EsitoSelezione.PENDENTE in esiti:
        raise ValueError("Non tutte le giocate sono state regolate")

    if all(e == EsitoSelezione.ANNULLATA for e in esiti):
        return StatoGiocata.ANNULLATA
    if risultato.ritorno_lordo == 0:
        return StatoGiocata.PERSA
    if risultato.profitto > 0:
        return StatoGiocata.VINTA
    return StatoGiocata.MEZZA_PERSA
