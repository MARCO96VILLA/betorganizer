"""Condizioni delle promozioni dei bookmaker (es. "multipla con quota totale minima 5").

Pura: dato un insieme di condizioni e una schedina (quote e stake) dice quali requisiti sono rispettati.
"""

import math
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Optional


@dataclass(frozen=True)
class CondizioniBonus:
    selezioni_minime: Optional[int] = None
    quota_minima_evento: Optional[Decimal] = None
    quota_minima_totale: Optional[Decimal] = None
    stake_minimo: Optional[Decimal] = None

    def e_vuota(self) -> bool:
        return all(
            v is None
            for v in (
                self.selezioni_minime,
                self.quota_minima_evento,
                self.quota_minima_totale,
                self.stake_minimo,
            )
        )


@dataclass(frozen=True)
class Requisito:
    descrizione: str
    soddisfatto: bool


def _fmt(valore: Decimal) -> str:
    return f"{valore:.2f}".replace(".", ",")


def verifica_requisiti(
    condizioni: CondizioniBonus, quote: list[Decimal], stake: Optional[Decimal]
) -> list[Requisito]:
    """Requisiti della promozione rispettati (o no) da una schedina. Quelli non impostati si ignorano.

    Lo stake mancante non viene valutato: finché non è inserito non si può dire se basta.
    """
    requisiti: list[Requisito] = []

    if condizioni.selezioni_minime is not None:
        n = len(quote)
        requisiti.append(
            Requisito(
                f"Almeno {condizioni.selezioni_minime} giocate (ora {n})",
                n >= condizioni.selezioni_minime,
            )
        )

    if condizioni.quota_minima_evento is not None and quote:
        piu_bassa = min(quote)
        requisiti.append(
            Requisito(
                f"Quota minima {_fmt(condizioni.quota_minima_evento)} per ogni giocata "
                f"(la più bassa è {_fmt(piu_bassa)})",
                piu_bassa >= condizioni.quota_minima_evento,
            )
        )

    if condizioni.quota_minima_totale is not None:
        totale = Decimal("1")
        for q in quote:
            totale *= q
        requisiti.append(
            Requisito(
                f"Quota totale minima {_fmt(condizioni.quota_minima_totale)} (ora {_fmt(totale)})",
                totale >= condizioni.quota_minima_totale,
            )
        )

    if condizioni.stake_minimo is not None and stake is not None:
        requisiti.append(
            Requisito(
                f"Puntata minima {_fmt(condizioni.stake_minimo)} € (ora {_fmt(stake)} €)",
                stake >= condizioni.stake_minimo,
            )
        )

    return requisiti


def giorni_rimanenti(scadenza: Optional[datetime], ora: datetime) -> Optional[int]:
    """Giorni interi che mancano alla scadenza (arrotondati per eccesso); 0 se scade oggi, negativo se scaduto.

    None se la promozione non ha scadenza.
    """
    if scadenza is None:
        return None
    secondi = (scadenza - ora).total_seconds()
    if secondi <= 0:
        return -math.ceil(-secondi / 86400) if secondi < 0 else 0
    return math.ceil(secondi / 86400)
