"""Lettura di una schedina dal testo OCR di uno screenshot.

Modulo puro: riceve le righe di testo già estratte (niente OCR, niente DB) e restituisce una *bozza*
strutturata, che l'utente controlla e corregge prima del salvataggio. Non indovina mai: un campo non
leggibile resta vuoto e genera un avviso; un esito si scrive solo se lo stato della schedina lo rende certo.

Il testo OCR può contenere il carattere di tabulazione: indica un grande spazio orizzontale nella riga
(per Eplay24, quello tra l'etichetta del mercato e il riquadro rosso con scelta e quota).

I layout riconosciuti sono due, quelli visti negli screenshot dell'utente:
  - Betsson: scheda con "IN CORSO | SINGOLA (1) data ora", righe "COMPETIZIONE | partita", "Mercato: scelta (quota)"
    e in fondo "Puntata / Quota Totale / Vincita"; anche la vista elenco con "Importo / Bonus / Quota totale".
  - Eplay24: pagina "Giocata" con "Giocata del:", "ADM:", partite "data ora - sport - competizione",
    "Casa vs Trasferta" e, in fondo, "Quota totale / Importo pagato / Vincita".
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field, replace
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Optional

from app.domain.analytics import famiglia_mercato

BETSSON = "Betsson"
EPLAY24 = "Eplay24"

STATO_IN_CORSO = "in_corso"
STATO_VINTA = "vinta"
STATO_PERSA = "persa"

# Dal 18/10/2026 l'utente registra ogni schedina giocata, vinta o persa: da quel giorno il campione è completo.
# Le schedine precedenti vengono da screenshot scelti (spesso solo vincite) e portano il tag "storico-screenshot".
DATA_REGISTRAZIONE_COMPLETA = datetime(2026, 10, 18)
TAG_STORICO_SCREENSHOT = "storico-screenshot"

SOGLIA_BONUS_PCT = Decimal("0.5")  # sotto questa stima è rumore di arrotondamento, non un bonus
BONUS_PCT_MASSIMO = Decimal("100")
TOLLERANZA_QUOTA = Decimal("0.02")  # scarto relativo accettato tra quota totale letta e prodotto delle quote

_CENT = Decimal("0.01")


@dataclass
class BozzaSelezione:
    """Una giocata (scelta dentro una schedina), così come letta."""

    sport: str = "Calcio"
    competizione: Optional[str] = None
    squadra_casa: str = ""
    squadra_trasferta: Optional[str] = None
    mercato: str = ""
    esito_giocato: Optional[str] = None
    quota: Optional[Decimal] = None
    esito: str = "pendente"
    inizio_evento: Optional[datetime] = None
    risultato_evento: Optional[str] = None
    mercato_giocatore: bool = False
    testo_mercato: str = ""  # etichetta e scelta come stampate nello screenshot, per il confronto in revisione
    avvisi: list[str] = field(default_factory=list)
    # bet builder: più mercati sulla stessa partita con una sola quota; ogni voce {mercato, esito_giocato, mercato_giocatore}
    componenti: Optional[list[dict]] = None


@dataclass
class BozzaSchedina:
    bookmaker: Optional[str] = None
    riferimento: Optional[str] = None  # codice ADM / Ref. quando visibile
    piazzata_il: Optional[datetime] = None
    stake: Optional[Decimal] = None
    quota_totale: Optional[Decimal] = None
    vincita: Optional[Decimal] = None
    bonus_importo: Optional[Decimal] = None
    bonus_multipla_pct: Decimal = Decimal("0")
    stato: str = STATO_IN_CORSO
    selezioni: list[BozzaSelezione] = field(default_factory=list)
    avvisi: list[str] = field(default_factory=list)


# --- numeri, date, codici -------------------------------------------------------------------------

_RE_NUMERO = re.compile(r"\d+(?:[.,]\d+)?")
_RE_DATA_ORA = re.compile(r"(\d{2})/(\d{2})/(\d{4})[\s.]*(?:[-–]\s*)?(\d{1,2}):(\d{2})")
_RE_DATA = re.compile(r"(\d{2})/(\d{2})/(\d{4})")


def decimale(testo: str) -> Optional[Decimal]:
    """Legge un numero scritto all'italiana o all'inglese ("1.52", "10,00 €", "1.234,56"); None se non valido."""
    s = testo.replace("€", "").replace(" ", "").strip()
    s = re.sub(r"(?<=\d)[:;]+(?=\d)", ".", s)  # l'OCR legge spesso il separatore decimale come due punti
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", ".")
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def numeri_in_riga(riga: str) -> list[Decimal]:
    return [decimale(m) for m in _RE_NUMERO.findall(riga)]


def data_ora(testo: str) -> Optional[datetime]:
    m = _RE_DATA_ORA.search(testo)
    if not m:
        return None
    giorno, mese, anno, ore, minuti = (int(x) for x in m.groups())
    try:
        return datetime(anno, mese, giorno, ore, minuti)
    except ValueError:
        return None


def _data_senza_ora(testo: str) -> Optional[datetime]:
    giorno, mese, anno = (int(x) for x in _RE_DATA.search(testo).groups())
    try:
        return datetime(anno, mese, giorno)
    except ValueError:
        return None


_ESADECIMALI = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1"})
_RE_CODICE = re.compile(r"\b([A-Z0-9]{16,24})\b")


def codice_adm(testo: str) -> Optional[str]:
    """Codice ADM / Ref. del biglietto (esadecimale, 20 caratteri). L'OCR confonde O/0 e I/1: si correggono.

    Se dopo la correzione non è esadecimale è una lettura sbagliata e non si usa come identificativo.
    """
    for candidato in _RE_CODICE.findall(testo.upper()):
        corretto = candidato.translate(_ESADECIMALI)
        if re.fullmatch(r"[0-9A-F]{16,24}", corretto):
            return corretto
    return None


def _arrotonda(valore: Decimal) -> Decimal:
    return valore.quantize(_CENT, rounding=ROUND_HALF_UP)


# --- preparazione delle righe ---------------------------------------------------------------------

_RE_SOLO_ORA = re.compile(r"^\s*\d{1,2}:\d{2}\s*$")
_RE_FINISCE_CON_DATA = re.compile(r"\d{2}/\d{2}/\d{4}\s*$")
# "PAESE | Competizione" senza la data, che l'OCR ha messo nella riga dopo (a volte preceduta da un "|" o da una cifra)
_RE_INTESTAZIONE_SENZA_DATA = re.compile(r"^\W*[^|\d/]+\|[^|\d/]*\|?\s*$")
_RE_DATA_CON_RUMORE = re.compile(r"^\W{0,3}(?:\d\s)?(\d{2}/\d{2}/\d{4}.*)$")


def pulisci_righe(righe: list[str]) -> list[str]:
    """Riunisce le righe spezzate dall'OCR (data e ora su righe diverse) e riduce le righe vuote a una sola.

    Una riga vuota segna un salto verticale nello screenshot: serve a separare i mercati di un bet builder.
    """
    pulite: list[str] = []
    for grezza in righe:
        riga = grezza.strip()
        if not riga:
            if pulite and pulite[-1]:
                pulite.append("")
            continue
        ultima = max((i for i, r in enumerate(pulite) if r), default=None)
        precedente = pulite[ultima] if ultima is not None else ""
        data_a_capo = _RE_DATA_CON_RUMORE.match(riga)
        if ultima is not None and _RE_SOLO_ORA.match(riga) and _RE_FINISCE_CON_DATA.search(precedente):
            pulite[ultima:] = [f"{precedente} {riga}"]
        elif ultima is not None and data_a_capo and _RE_INTESTAZIONE_SENZA_DATA.match(precedente):
            pulite[ultima:] = [f"{precedente.rstrip(' |')} | {data_a_capo.group(1)}"]
        else:
            pulite.append(riga)
    while pulite and not pulite[-1]:
        pulite.pop()
    return pulite


# --- competizioni --------------------------------------------------------------------------------

_COMPETIZIONI_NOTE = [
    "Serie A", "Serie B", "Serie C", "Coppa Italia", "Premier League", "Championship", "LaLiga", "Bundesliga",
    "Ligue 1", "Eredivisie", "Primeira Liga", "Champions League", "Europa League", "Conference League",
    "UEFA Nations League", "Qualificazioni Mondiali", "Amichevoli", "Europei", "Mondiali",
]


# Betsson le scrive con "UEFA", Eplay24 senza: lo storico le raggruppa con il nome corto
_ALIAS_COMPETIZIONI = {
    "uefa champions league": "Champions League",
    "uefa europa league": "Europa League",
    "uefa conference league": "Conference League",
}


def correggi_competizione(testo: str) -> str:
    """Corregge gli errori di battitura dell'OCR ("Serle A") sui nomi di campionato più comuni."""
    if testo.lower() in _ALIAS_COMPETIZIONI:
        return _ALIAS_COMPETIZIONI[testo.lower()]
    if any(nota.lower() in testo.lower() for nota in _COMPETIZIONI_NOTE):
        return testo  # già corretto, anche se più lungo ("UEFA Champions League")
    vicini = difflib.get_close_matches(testo, _COMPETIZIONI_NOTE, n=1, cutoff=0.85)
    return vicini[0] if vicini else testo


# --- normalizzazione del mercato ------------------------------------------------------------------

_SIGLE = {"U/O", "DC", "MG", "1X2", "1X", "X2", "12", "T.R.", "GG/NG", "1T", "2T"}
_RE_GIOCATORE = re.compile(
    r"giocator|marcator|assist|palo/traversa|\bsegna o\b|\bsostituto\b|\bsegna\b.*\([a-zà-ü .]+\)|,\s*[a-zà-ü]+\s*\(", re.I
)

# lettere che l'OCR scambia con cifre dentro i numeri ("U/0" -> "U/O", "1.S" -> "1.5")
_CORREZIONI_ETICHETTA = [
    (re.compile(r"\bU+/[O0]|\b0/[0O]\b"), "U/O"),
    (re.compile(r"U/O(?=\d)"), "U/O "),
    (re.compile(r"\b0SPITE|\b0SP\b"), "OSPITE"),
    (re.compile(r"\bINC(?:L)?\.?\s*T\.?S\.?"), ""),
    (re.compile(r"\s*\|\s*"), " "),  # barra del riquadro rimasta nell'etichetta
    (re.compile(r"(?<=[A-Z]) 0 (?=[A-Z])"), " O "),  # la "O" di una frase letta come zero
    (re.compile(r"\b1[RKH]2\b"), "1X2"),
    (re.compile(r"\bIX\b"), "1X"),
    (re.compile(r"\bPP\b"), ""),
    (re.compile(r"DOPPIA CHANCE\s+OUT\b|\bDC\s?OUT\b"), "DC Out"),
    (re.compile(r"DOPPIA CHANCE\s+IN\b|\bDC\s?IN\b"), "DC"),
    (re.compile(r"DOPPIA CHANCE"), "DC"),
    (re.compile(r"\bESITO FINALE\b"), ""),
    (re.compile(r"GOAL\s*/\s*NO(?:\s*GOAL)?\b|GOL\s*/\s*NO(?:\s*GOL)?\b|GG\s*/\s*NG"), "Gol/NoGol"),
    (re.compile(r"MULTIGOAL|MULTIGOL|MULTIG\b"), "MG"),
    (re.compile(r"CALCI\s+(?:D'?\s?)?ANGOLO|CORNER"), "Corner"),
    (re.compile(r"\bTEAM (\d)"), r"SQUADRA \1"),
    (re.compile(r"\b[1I]\s*°\s*TEMPO|\bI°\s*TEMPO"), "1T"),
    (re.compile(r"\b2\s*°\s*TEMPO"), "2T"),
    (re.compile(r"\bOSPITE\b|\bOSP\b"), "OSPITE"),
]


_PAROLE_CON_INIZIALE = {"casa", "ospite", "cartellini", "parate", "tiri", "corner", "handicap", "squadra", "out", "gol"}


def _tipo_parola(parola: str) -> str:
    if parola in _SIGLE or re.search(r"\d", parola) or parola.startswith("Gol/"):
        return parola
    minuscola = parola.lower()
    return minuscola.capitalize() if minuscola in _PAROLE_CON_INIZIALE else minuscola


def _pulisci_etichetta(testo: str) -> str:
    s = testo.upper().replace("—", " ").replace("–", " ")
    s = s.replace("\t", " ").strip(" :;|")
    for schema, sostituto in _CORREZIONI_ETICHETTA:
        s = schema.sub(sostituto, s)
    return re.sub(r"\s+", " ", s).strip(" :")


def _maiuscole(testo: str) -> str:
    """Parole in minuscolo salvo sigle e numeri; maiuscola solo all'inizio della frase."""
    parole = " ".join(_tipo_parola(p) for p in testo.split())
    return parole[:1].upper() + parole[1:]


_RE_UO_GRUPPO = re.compile(r"^U/O X (?P<cosa>.+?) INCONTRI DEL GRUPPO .+ (?P<numero>\d+\.\d)$")
_RE_UO_PARAM = re.compile(r"^U/O (\d+(?:\.\d)?)(?:\s+(.+))?$")
_RE_UO_PARAM_FINALE = re.compile(r"^U/O (?P<resto>\D.*?)\s+(?P<numero>\d+\.\d)$")
_RE_OVER_UNDER_LATO = re.compile(r"^(OVER|UNDER) (\d+(?:\.\d)?)\s+(CASA|OSPITE)$")
_RE_MG_PARAM = re.compile(r"^MG\s*(\d)\s*[-–.]?\s*(\d)(?:\s+(CASA|OSPITE))?$")
_RE_MG_LATO = re.compile(r"^MG\s*(CASA|OSPITE)\s+(\d)\s*[-–]?\s*(\d)$")
_RE_ESITO = re.compile(r"^(1X|X2|12)$")
_RE_OV_1T_2T = re.compile(r"^OV(?:ER)?\s*1\W?T\s*[+/]\s*OV(?:ER)?\s*2\W?T\s*\(?\s*([\d.,]+)\s*[-–\s]\s*([\d.,]+)\s*\)?$")
_PAROLE_SCELTA_IGNORATE = {"SI", "SÌ", "MG", "MULTIG", "MULTIGOL", "MULTIGOAL"}


def _scelta_pulita(token: str) -> str:
    t = token.strip(" |:!{}()[]")
    maiusc = re.sub(r"^[0O]+(?=OV$|UN$)", "", t.upper())
    if maiusc in ("OV", "OVER"):
        return "Over"
    if maiusc in ("UN", "UNDER"):
        return "Under"
    if maiusc in ("GG", "GOAL", "GOL"):
        return "Gol"
    if maiusc in ("NG", "NOGOAL", "NOGOL", "NO GOAL", "NO GOL"):
        return "NoGol"
    if maiusc in ("SI", "SÌ"):
        return "SI"
    if re.fullmatch(r"1X|X2|12|1|2|X|NO", maiusc):
        return maiusc
    return t


def _componenti_scelta(scelta: str) -> list[str]:
    scelta = scelta.replace("\t", " ").strip(" |:!{}")
    scelta = re.sub(r"^(?:PP|Y|V|P)\s+", "", scelta)  # icone lette come lettere
    # "1X +OV", "2+UN", "X2+ MULTIG": il segno più separa le parti anche senza spazi
    pezzi = [p.strip() for p in re.split(r"\s*\+\s*", scelta) if p.strip()]
    return [_scelta_pulita(p) for p in pezzi]


_RE_GIOCATORE_ALMENO = re.compile(
    r"^(?P<nome>.+?\))\s+E IL SUO SOSTITUTO\s+IN TOTALE\s+(?:EFFETTUANO\s+)?ALMENO\s+(?P<n>\d+)\s+"
    r"(?P<cosa>TIRI IN PORTA|TIRI TOTALI|TIRI|FALLI|CARTELLINI|PARATE)\s*(?P<resto>.*)$"
)
_RE_GIOCATORE_GENERICO = re.compile(
    r"^(?P<nome>[^,()]+,[^()]+\([^)]+\))\s+(?:E IL SUO SOSTITUTO|O (?:IL )?SUO SOSTITUTO|O SOSTITUTO)\s*(?:IN TOTALE\s+)?(?P<resto>.+)$"
)
_RE_NUMERI_IN_FONDO = re.compile(r"\s*\(\s*(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*\)\s*$")


def _numeri_uo_in_fondo(etichetta: str) -> str:
    """"U/O CARTELLINI SQUADRA 1 + U/O CARTELLINI SQUADRA 2 (0.5-0.5)": i due numeri passano davanti a ciascun U/O."""
    m = _RE_NUMERI_IN_FONDO.search(etichetta)
    if not m or len(re.findall(r"U/O (?!\d)", etichetta)) != 2:
        return etichetta
    corpo = etichetta[: m.start()]
    corpo = re.sub(r"U/O (?!\d)", f"U/O {m.group(1)} ", corpo, count=1)
    return re.sub(r"U/O (?!\d)", f"U/O {m.group(2)} ", corpo, count=1)


def normalizza_mercato(etichetta: str, scelta: str) -> tuple[str, str, bool]:
    """(mercato, scelta, riconosciuto): nome coerente con quelli dello storico e scelta ripulita.

    Gli stessi mercati hanno scritture diverse nei due bookmaker ("DOPPIA CHANCE IN + MULTIGOAL 1-4" su
    Eplay24, "1X + MULTIGOAL 1-4" su Betsson): qui si riportano a un nome solo, perché le statistiche per
    famiglia di mercato (`domain/analytics.py`) raggruppano per nome. Ciò che non si riconosce resta com'è,
    solo ripulito, con `riconosciuto=False`.
    """
    pulita = _pulisci_etichetta(etichetta)
    giocatore = _RE_GIOCATORE_ALMENO.match(pulita)
    if giocatore:
        # "ROSSI, MARIO (INTER) E IL SUO SOSTITUTO IN TOTALE ALMENO 3 TIRI TOTALI" + "SI"
        extra = ", pali/traverse incluse" if "PALI/TRAVERSE" in giocatore.group("resto") else ""
        mercato = f"{giocatore.group('cosa').capitalize()} giocatore (almeno {giocatore.group('n')}{extra})"
        return mercato, f"{giocatore.group('nome').title()}: {scelta.strip(' |:!{}')}", True
    giocatore = _RE_GIOCATORE_GENERICO.match(pulita)
    if giocatore:
        resto = giocatore.group("resto").lower()
        return f"Giocatore: {resto}", f"{giocatore.group('nome').title()}: {scelta.strip(' |:!{}')}", True
    if _RE_GIOCATORE.search(pulita) or _RE_GIOCATORE.search(etichetta):
        return pulita.title(), scelta.strip(" |:!{}"), True

    pulita = _numeri_uo_in_fondo(pulita)
    ov = _RE_OV_1T_2T.match(pulita)
    if ov:
        return "Ov 1T + Ov 2T", f"{ov.group(1)} - {ov.group(2)}".replace(",", "."), True

    componenti = [c.strip() for c in re.split(r"\s*\+\s*", pulita) if c.strip()]
    scelte = _componenti_scelta(scelta)
    nomi: list[str] = []
    risultato: list[str] = []
    tutti_riconosciuti = bool(componenti)
    stesso_tipo = len(componenti) > 1
    tipi: set[str] = set()

    for comp in componenti:
        param: Optional[str] = None
        nome = comp
        tipo = "altro"
        m_uo = _RE_UO_PARAM.match(comp)
        m_lato = _RE_OVER_UNDER_LATO.match(comp)
        m_mg = _RE_MG_PARAM.match(comp)
        m_mg_lato = _RE_MG_LATO.match(comp)
        m_gruppo = _RE_UO_GRUPPO.match(comp)
        m_uo_finale = _RE_UO_PARAM_FINALE.match(comp)
        if m_uo_finale and not m_gruppo:
            # il numero della linea è in fondo ("U/O TIRI IN PORTA SQUADRA 1 4.5"): si porta davanti
            comp = f"U/O {m_uo_finale.group('numero')} {m_uo_finale.group('resto')}"
            m_uo = _RE_UO_PARAM.match(comp)
        if m_gruppo:
            lato_uo = scelte.pop(0) if scelte and scelte[0] in ("Over", "Under") else None
            nome = _maiuscole(f"U/O {m_gruppo.group('cosa')} gruppo di partite")
            param = f"{lato_uo} {m_gruppo.group('numero')}" if lato_uo else m_gruppo.group("numero")
            tipo = "uo"
        elif m_lato:
            lato = "Casa" if m_lato.group(3) == "CASA" else "Ospite"
            nome, param, tipo = f"U/O Gol {lato}", f"{m_lato.group(1).capitalize()} {m_lato.group(2)}", "uo"
        elif m_uo:
            numero, resto = m_uo.group(1), m_uo.group(2)
            if resto:
                nome, tipo = _maiuscole(f"U/O {resto}"), "uo"
                lato_uo = scelte.pop(0) if scelte and scelte[0] in ("Over", "Under") else None
                param = f"{lato_uo} {numero}" if lato_uo else numero
                tutti_riconosciuti = tutti_riconosciuti and lato_uo is not None
            else:
                nome, tipo = f"U/O {numero}", "uo"  # totale gol: il numero resta nel nome, la scelta è Over/Under
        elif m_mg or m_mg_lato:
            if m_mg:
                intervallo, lato = f"{m_mg.group(1)}-{m_mg.group(2)}", m_mg.group(3)
            else:
                lato, intervallo = m_mg_lato.group(1), f"{m_mg_lato.group(2)}-{m_mg_lato.group(3)}"
            nome = "MG Totale" if lato is None else f"MG {lato.capitalize()}"
            param, tipo = intervallo, "mg"
        elif _RE_ESITO.match(comp):
            nome, param, tipo = "DC", comp, "esito"
            if scelte and scelte[0].upper() == comp:
                scelte.pop(0)
        else:
            nome = _maiuscole(comp)
            tipo = "esito" if comp.startswith(("1X2", "DC")) else "altro"
            tutti_riconosciuti = tutti_riconosciuti and (
                famiglia_mercato(nome) != "Altro" or nome.lower().startswith("risultato esatto")
            )

        nomi.append(nome)
        tipi.add(tipo)
        if param is not None:
            risultato.append(param)
            if scelte and scelte[0].upper() in _PAROLE_SCELTA_IGNORATE:
                scelte.pop(0)  # "SI" o "MULTIG": conferma la scelta già contenuta nell'etichetta
        elif scelte:
            risultato.append(scelte.pop(0))
    stesso_tipo = stesso_tipo and len(tipi) == 1

    mercato = " + ".join(nomi)
    if mercato == "DC":
        mercato = "Doppia Chance"
    risultato.extend(scelte)  # scelte rimaste senza un componente a cui legarsi (es. "SI")
    separatore = " - " if stesso_tipo else " + "
    esito_finale = separatore.join(risultato)
    return mercato, esito_finale, tutti_riconosciuti and bool(mercato)


# --- riconoscimento del layout --------------------------------------------------------------------

_RE_EPLAY = re.compile(
    r"E\s?PLAY\s?24|\bADM\s*:|Giocata del|\d{2}/\d{2}/\d{4}\s+\d{1,2}:\d{2}\s*-\s*\w+\s*-|CERCA\s+SPORT\s+LIVE\s+SCHEDINA", re.I
)
_RE_BETSSON = re.compile(
    r"betsson|\|\s*\d{2}/\d{2}/\d{4}|\b(SINGOLA|MULTIPLA|SISTEMA)\b.*\d{2}/\d{2}/\d{4}|\b(SINGOLA|MULTIPLA|SISTEMA)\s*\(\s*\d+|\bPuntata\b.*\bQuota\s+Totale\b", re.I
)


def riconosci_bookmaker(righe: list[str]) -> Optional[str]:
    testo = "\n".join(righe)
    if _RE_EPLAY.search(testo):
        return EPLAY24
    if _RE_BETSSON.search(testo):
        return BETSSON
    return None


# --- lettura Betsson ------------------------------------------------------------------------------

_RE_TESTATA_BETSSON = re.compile(r"\b(SINGOLA|MULTIPLA|SISTEMA)\b", re.I)
_RE_CONTEGGIO = re.compile(r"\(\s*(\d+)\s*\)?")
_RE_DATA_QUALSIASI = re.compile(r"\d{1,2}/\d{2}/\d{4}")
_RE_INTESTAZIONE_PARTITA = re.compile(
    r"^\W*(?P<paese>[^|]+?)\s*\|\s*(?P<comp>[^|]+?)\s*\|\s*(?P<data>\d{2}/\d{2}/\d{4})(?:\s*(?P<ora>\d{1,2}:\d{2}))?"
)
_RE_RUMORE = re.compile(r"\bLIVE\b|Statistiche|^\W*$|^Schedina$|Rigioca|Condividi", re.I)
_RE_QUOTA_TONDA = re.compile(r"\((\d+[.,:;]\d{2,3}|\d{3})\)")
_RE_INTESTAZIONE_TOTALI = re.compile(r"\b(Puntata|Importo)\b", re.I)


def _stato_da_testo(testo: str) -> Optional[str]:
    maiuscolo = testo.upper()
    if re.search(r"IN\s*CORSO", maiuscolo):
        return STATO_IN_CORSO
    if re.search(r"\bVINT[AO]\b|VINCENTE", maiuscolo):
        return STATO_VINTA
    if re.search(r"\bPERS[AO]\b|PERDENTE", maiuscolo):
        return STATO_PERSA
    return None


def _sport_da_paese(paese: str) -> str:
    maiuscolo = paese.upper()
    for parola, sport in (("TENNIS", "Tennis"), ("BASKET", "Basket"), ("VOLLEY", "Pallavolo")):
        if parola in maiuscolo:
            return sport
    return "Calcio"


def _competizione(paese: str, comp: str) -> str:
    if paese.upper().startswith("SPECIALI"):
        return f"{paese.title()} ({comp})"
    return comp


def _divide_partita(riga: str) -> tuple[str, Optional[str]]:
    m = re.match(r"^(.+?)\s+-\s+(.+)$", riga)
    if not m:
        return riga.strip(), None
    return m.group(1).strip(), m.group(2).strip()


def _quota_tonda(testo: str) -> Optional[Decimal]:
    """Quota tra parentesi: "1.52", "1:52" oppure "165" (senza separatore, cioè 1.65)."""
    if testo.isdigit():
        testo = f"{testo[0]}.{testo[1:]}"
    return decimale(testo)


def _estrai_mercato_betsson(blocco: list[str]) -> tuple[str, str, Optional[Decimal]]:
    """Da righe tipo "Doppia Chance: X2 (1.52)" ricava (etichetta, scelta, quota).

    Le etichette lunghe vanno a capo e l'OCR può mettere la scelta nel mezzo:
    "Doppia Chance + Goal/No" / "X2 + Goal (2.22)" / "Goal:".
    """
    indice = next((i for i, r in enumerate(blocco) if _RE_QUOTA_TONDA.search(r)), None)
    if indice is None:
        unito = " ".join(blocco)
        etichetta, _, scelta = unito.partition(":")
        return etichetta, scelta.strip(), None
    riga = blocco[indice]
    m = _RE_QUOTA_TONDA.search(riga)
    quota = _quota_tonda(m.group(1))
    prima = riga[: m.start()].strip()
    precedenti, successive = blocco[:indice], blocco[indice + 1 :]
    if ":" in prima:
        etichetta, scelta = prima.split(":", 1)
        return " ".join(precedenti + [etichetta]), scelta.strip(), quota
    if "\t" in prima:  # senza due punti l'etichetta e la scelta sono separate da un grande spazio
        etichetta, scelta = prima.rsplit("\t", 1)
        return " ".join(precedenti + [etichetta]), scelta.strip(), quota
    # niente due punti sulla riga della quota: l'etichetta continua nelle righe seguenti, fino ai due punti
    seguito = []
    for r in successive:
        seguito.append(r.split(":")[0])
        if ":" in r:
            break
    return " ".join(precedenti + seguito), prima, quota


_RE_PARTITA_BETSSON = re.compile(r"^\S.*\s-\s\S.*$")
_RE_RUMORE_INIZIALE = re.compile(r"^\W*(?:\w{1,2}\W+)?(?=[A-ZÀ-Ü]{3})")


def _pulisci_paese(paese: str) -> str:
    """Toglie le icone lette come lettere davanti al nome ("lo) CLUB INTERNAZIONALI" -> "CLUB INTERNAZIONALI")."""
    return _RE_RUMORE_INIZIALE.sub("", paese.strip())


def _segmenta_giocate_betsson(righe: list[str]) -> list[tuple[Optional[re.Match], list[str]]]:
    """Divide le righe in giocate: (intestazione della partita se presente, righe della giocata).

    Alcune viste (schedine con molte giocate) non hanno l'intestazione "PAESE | competizione | data": allora una
    giocata comincia con la riga "Casa - Trasferta", ma solo dopo che la precedente ha la sua quota. In questo modo
    un'etichetta di mercato che contiene un trattino non viene scambiata per una nuova partita.
    """
    giocate: list[tuple[Optional[re.Match], list[str]]] = []
    for riga in righe:
        intestazione = _RE_INTESTAZIONE_PARTITA.match(riga)
        if intestazione:
            giocate.append((intestazione, []))
        elif _RE_RUMORE.search(riga):
            continue
        elif not giocate:
            if _RE_PARTITA_BETSSON.match(riga):
                giocate.append((None, [riga]))
        elif _RE_PARTITA_BETSSON.match(riga) and any(_RE_QUOTA_TONDA.search(r) for r in giocate[-1][1]):
            giocate.append((None, [riga]))
        else:
            giocate[-1][1].append(riga)
    return giocate


def _leggi_betsson(righe: list[str], bozza: BozzaSchedina) -> None:
    testata = next(
        (
            i
            for i, r in enumerate(righe)
            if (_RE_TESTATA_BETSSON.search(r) and (_RE_DATA.search(r) or _RE_CONTEGGIO.search(r)))
            or (_stato_da_testo(r) and _RE_DATA_QUALSIASI.search(r))
        ),
        None,
    )
    inizio_blocchi = 0
    stato_testata: Optional[str] = None
    if testata is not None:
        bozza.piazzata_il = data_ora(righe[testata])
        stato_testata = _stato_da_testo(righe[testata])
        inizio_blocchi = testata + 1
    else:
        bozza.avvisi.append("Intestazione della schedina non visibile: controlla data, ora e tipo.")
        if bozza.piazzata_il is None:
            bozza.avvisi.append("Orario di piazzamento non letto.")
    if testata is not None and bozza.piazzata_il is None:
        bozza.avvisi.append("Orario di piazzamento non letto.")

    fine = len(righe)
    indice_totali: Optional[int] = None
    for i in range(inizio_blocchi, len(righe)):
        if _RE_INTESTAZIONE_TOTALI.search(righe[i]) and re.search(r"Quota|Vincita|Bonus", righe[i], re.I):
            indice_totali, fine = i, i
            break

    giocate = _segmenta_giocate_betsson(righe[inizio_blocchi:fine])
    dichiarate = _RE_CONTEGGIO.search(righe[testata]) if testata is not None else None
    if dichiarate and int(dichiarate.group(1)) > len(giocate):
        bozza.avvisi.append(
            f"La schedina ha {dichiarate.group(1)} giocate ma nello screenshot ne leggo {len(giocate)}: "
            "se ne hai un altro con le altre, usa Unisci."
        )
    for m, blocco in giocate:
        sel = BozzaSelezione()
        if m is None:
            sel.avvisi.append("Campionato e orario d'inizio non visibili: completali.")
        else:
            paese = _pulisci_paese(m.group("paese"))
            sel.sport = _sport_da_paese(paese)
            sel.competizione = _competizione(paese, correggi_competizione(m.group("comp").strip()))
            giorno = _data_senza_ora(m.group("data"))
            ore, minuti = (int(x) for x in m.group("ora").split(":")) if m.group("ora") else (None, None)
            if giorno and ore is not None and ore < 24 and minuti < 60:  # "25:30" è letto male: meglio nessun orario
                sel.inizio_evento = giorno.replace(hour=ore, minute=minuti)
            else:
                sel.avvisi.append("Orario d'inizio della partita non letto.")
        if blocco:
            sel.squadra_casa, sel.squadra_trasferta = _divide_partita(blocco[0])
            etichetta, scelta, sel.quota = _estrai_mercato_betsson(blocco[1:])
        else:
            etichetta, scelta, sel.quota = "", "", None
        sel.testo_mercato = f"{etichetta}: {scelta}".strip(": ")
        if sel.squadra_trasferta is None and sel.squadra_casa:
            sel.avvisi.append("Partita senza due squadre: controlla il nome dell'evento.")
        sel.mercato, sel.esito_giocato, riconosciuto = normalizza_mercato(etichetta, scelta)
        sel.mercato_giocatore = bool(_RE_GIOCATORE.search(etichetta))
        if not sel.mercato:
            sel.avvisi.append("Mercato non letto.")
        elif not riconosciuto:
            sel.avvisi.append("Mercato non riconosciuto: controlla il nome e la scelta.")
        if sel.quota is None:
            sel.avvisi.append("Quota non letta.")
        bozza.selezioni.append(sel)

    stato_totali = None
    if indice_totali is not None:
        titoli = " ".join(righe[indice_totali : indice_totali + 3])
        stato_totali = _stato_da_testo(titoli)
        # la prima riga con dei numeri sotto l'intestazione; se la vincita è illeggibile restano puntata e quota totale
        # (una riga di rumore più in basso, con tre cifre sparse, non deve prendere il loro posto)
        riga_numeri = next(
            (r for r in righe[indice_totali + 1 : indice_totali + 4] if len(numeri_in_riga(r)) >= 2), None
        )
        if riga_numeri:
            numeri = numeri_in_riga(riga_numeri)
            if len(numeri) >= 4:
                bozza.stake, bozza.bonus_importo, bozza.quota_totale, bozza.vincita = numeri[:4]
            elif len(numeri) == 3:
                bozza.stake, bozza.quota_totale, bozza.vincita = numeri[:3]
            else:
                bozza.stake, bozza.quota_totale = numeri
                bozza.avvisi.append("Vincita potenziale non letta: controlla l'immagine.")
        else:
            bozza.avvisi.append("Puntata e quota totale non visibili: controlla l'immagine.")
    else:
        bozza.avvisi.append("Puntata e quota totale non visibili: controlla l'immagine.")

    bozza.stato = stato_testata or stato_totali or STATO_IN_CORSO
    ref = next((codice_adm(r) for r in righe if re.search(r"\bRef\b", r, re.I)), None)
    bozza.riferimento = ref


# --- lettura Eplay24 ------------------------------------------------------------------------------

_RE_INTESTAZIONE_EPLAY = re.compile(
    r"(?P<dt>\d{2}/\d{2}/\d{4}[\s.]+\d{1,2}:\d{2})\s*-\s*(?P<sport>[^-]+?)\s*-\s*(?P<comp>.+)$"
)
_RE_PARTITA_EPLAY = re.compile(r"^(?P<casa>.+?)\s+vs\s+(?P<osp>.+?)\s*(?:\(\s*(?P<g1>\d+)\s*:\s*(?P<g2>\d+)\s*\))?\s*[©@®&]*$", re.I)
_RE_QUOTA_PILLOLA = re.compile(r"[|!{\[]?\s*(\d+[.,:;]{1,2}\d{2})\s*$")
_RE_QUOTA_SENZA_SEPARATORE = re.compile(
    r"(?:\bSI|\bNO|OVER|UNDER|\b1X|\bX2|\b12|\b[12X]|GOAL)\s*[|!{\[]?\s*([1-9])(\d{2})\s*$", re.I
)
_RE_SCELTA_FINALE = re.compile(
    r"(?P<scelta>(?:1X|X2|12|1|2|X)\s*\+\s*\S+|SI|SÌ|NO|OVER|UNDER|GOAL|NOGOAL|1X|X2|12|1|2|X)\s*[|!{\[]*\s*$", re.I
)
_RE_PUNTEGGIO = re.compile(r"^\(?\s*\d+\s*:\s*\d+\s*\)?[©@®&\s]*")
_RE_PUNTINO = re.compile(r"^[@®©&»()\s—-]+|^[DOQ0doqnIl]\.?\s+(?=\S)")


def _valore_dopo(righe: list[str], schema: str) -> Optional[Decimal]:
    for r in righe:
        m = re.search(schema + r"\s*:?\s*(\d[\d.,]*)\s*€?", r, re.I)
        if m:
            return decimale(m.group(1))
    return None


def _stato_eplay(righe: list[str]) -> str:
    testo = " ".join(r for r in [r for r in righe if r][:8] if "importo" not in r.lower()).upper()
    if re.search(r"DA\s*\|?\s*NON\s*PAGARE", testo):
        return STATO_PERSA
    if re.search(r"PAGATO|DA\s*\|?\s*PAGARE", testo):
        return STATO_VINTA
    return STATO_IN_CORSO  # "VENDUTO" o nessuno stato: la schedina è ancora aperta


def _dividi_pillola(riga: str) -> tuple[str, str, Optional[Decimal]]:
    """Riga con la scelta e la quota in un riquadro rosso a destra -> (resto dell'etichetta, scelta, quota)."""
    m = _RE_QUOTA_PILLOLA.search(riga)  # la riga è stata scelta proprio perché contiene la quota
    quota = decimale(re.sub(r"[.,:;]+", ".", m.group(1)))
    prima = re.sub(r"\s+[Il|!]\s*$", "", riga[: m.start()].rstrip(" |!{[\t"))  # barra del riquadro letta come I
    if "\t" in prima:
        etichetta, scelta = prima.rsplit("\t", 1)
        return etichetta.strip(), scelta.strip(), quota
    s = _RE_SCELTA_FINALE.search(prima)
    if s:
        return prima[: s.start()].strip(), s.group("scelta").strip(), quota
    return prima, "", quota


_RE_QUOTA_EVENTO = re.compile(r"Quota\s+totale\s+evento\s*:?\s*(\d+[.,:;]{1,2}\d{2})", re.I)


def _gruppi_di_righe(blocco: list[str]) -> list[list[str]]:
    """Le righe di testo divise dalle righe vuote: ogni gruppo è un mercato (l'etichetta può andare a capo)."""
    gruppi: list[list[str]] = []
    corrente: list[str] = []
    for riga in blocco:
        if riga:
            corrente.append(riga)
        elif corrente:
            gruppi.append(corrente)
            corrente = []
    if corrente:
        gruppi.append(corrente)
    return gruppi


def _coppie_per_gruppo(gruppi: list[list[str]]) -> list[tuple[str, str]]:
    """(etichetta, scelta) per ogni gruppo. Un gruppo senza riquadro è la continuazione dell'etichetta vicina."""
    coppie: list[list[str]] = []
    for gruppo in gruppi:
        sinistre: list[str] = []
        destre: list[str] = []
        for riga in gruppo:
            if "\t" in riga:
                sinistra, _, destra = riga.rpartition("\t")
            else:
                trovata = _RE_SCELTA_FINALE.search(riga)
                sinistra, destra = (riga[: trovata.start()], trovata.group("scelta")) if trovata else (riga, "")
            sinistre.append(sinistra.strip())
            destre.append(destra.strip(" |!{[]"))
        coppie.append([" ".join(p for p in sinistre if p), " ".join(p for p in destre if p)])
    unite: list[list[str]] = []
    precedente_senza_scelta = ""
    for etichetta, scelta in coppie:
        etichetta = f"{precedente_senza_scelta} {etichetta}".strip()
        if scelta:
            unite.append([etichetta, scelta])
            precedente_senza_scelta = ""
        else:
            precedente_senza_scelta = etichetta
    if precedente_senza_scelta and unite:
        unite[-1][0] = f"{unite[-1][0]} {precedente_senza_scelta}".strip()
    elif precedente_senza_scelta:
        unite.append([precedente_senza_scelta, ""])
    return [(e, c) for e, c in unite]


def _mercato_con_quota_evento(blocco: list[str]) -> list[tuple[str, str]]:
    """Bet builder: più mercati sulla stessa partita; ogni riga ha l'etichetta e, nel riquadro rosso, la sola scelta.

    La quota è una sola, "Quota totale evento". Si restituisce una coppia (etichetta, scelta) per ogni riga.
    """
    if "" in blocco:
        gruppi = _gruppi_di_righe(blocco)
        if len(gruppi) >= 2:
            return _coppie_per_gruppo(gruppi)
    blocco = [r for r in blocco if r]
    etichette: list[str] = []
    scelte: list[str] = []
    parti: list[str] = []
    for riga in blocco:
        if "\t" in riga:
            sinistra, _, destra = riga.rpartition("\t")
        else:
            trovata = _RE_SCELTA_FINALE.search(riga)
            sinistra, destra = (riga[: trovata.start()], trovata.group("scelta")) if trovata else (riga, "")
        parti.append(sinistra.strip())
        if destra.strip():
            etichette.append(" ".join(p for p in parti if p))
            scelte.append(destra.strip(" |!{[]"))
            parti = []
    if parti and etichette:  # coda dell'etichetta senza un riquadro: appartiene all'ultima riga
        etichette[-1] = " ".join([etichette[-1], *parti]).strip()
    elif parti:
        etichette.append(" ".join(parti))
    scelte += [""] * (len(etichette) - len(scelte))
    return list(zip(etichette, scelte)) or [("", "")]


def _righe_con_quota(gruppi: list[list[str]]) -> list[tuple[str, str, Decimal]]:
    """(etichetta, scelta, quota) per ogni gruppo che ha una quota nel riquadro rosso.

    Un gruppo senza quota è la continuazione dell'etichetta del gruppo con quota vicino (prima il successivo).
    """
    righe: list[list] = []
    in_attesa = ""
    for gruppo in gruppi:
        indice = next((k for k, r in enumerate(gruppo) if _RE_QUOTA_PILLOLA.search(r)), None)
        if indice is None:
            in_attesa = f"{in_attesa} {' '.join(gruppo)}".strip()
            continue
        resto, scelta, quota = _dividi_pillola(gruppo[indice])
        etichetta = " ".join(gruppo[:indice] + [resto] + gruppo[indice + 1 :])
        righe.append([f"{in_attesa} {etichetta}".strip(), scelta, quota])
        in_attesa = ""
    if in_attesa and righe:
        righe[-1][0] = f"{righe[-1][0]} {in_attesa}".strip()
    return [(e, c, q) for e, c, q in righe]


def _mercato_eplay(blocco: list[str]) -> list[tuple[list[tuple[str, str]], Optional[Decimal]]]:
    """[([(etichetta, scelta), ...], quota), ...]: una voce per ogni giocata della partita, dopo la riga con le squadre.

    - "Quota totale evento": più mercati, una sola quota (bet builder): una voce con più coppie.
    - Più righe, ognuna con la sua quota: giocate diverse sulla stessa partita (come una multipla): una voce per riga.
    - Altrimenti una voce sola.
    """
    for k, riga in enumerate(blocco):
        evento = _RE_QUOTA_EVENTO.search(riga)
        if evento:
            coppie = _mercato_con_quota_evento(blocco[:k] + blocco[k + 1 :])
            return [(coppie, decimale(re.sub(r"[.,:;]+", ".", evento.group(1))))]

    if "" in blocco:
        righe = _righe_con_quota(_gruppi_di_righe(blocco))
        if len(righe) >= 2:
            return [([(etichetta, scelta)], quota) for etichetta, scelta, quota in righe]

    blocco = [r for r in blocco if r]
    indice = next((k for k, r in enumerate(blocco) if _RE_QUOTA_PILLOLA.search(r)), None)
    if indice is None:
        # quota senza separatore decimale ("OVER 147"): si legge come 1.47 solo se segue subito una scelta
        for k, riga in enumerate(blocco):
            senza = _RE_QUOTA_SENZA_SEPARATORE.search(riga)
            if senza:
                blocco = [*blocco[:k], f"{riga[: senza.start(1)].rstrip()} |{senza.group(1)}.{senza.group(2)}", *blocco[k + 1 :]]
                indice = k
                break
    if indice is None:
        return [([(" ".join(blocco), "")], None)]
    resto, scelta, quota = _dividi_pillola(blocco[indice])
    return [([(" ".join(blocco[:indice] + [resto] + blocco[indice + 1 :]), scelta)], quota)]


def _applica_bet_builder(sel: BozzaSelezione, coppie: list[tuple[str, str]]) -> bool:
    """Riempie la giocata con i componenti del bet builder; restituisce True se tutti i mercati sono riconosciuti."""
    componenti: list[dict] = []
    riconosciuti = True
    for etichetta, scelta in coppie:
        mercato, esito, riconosciuto = normalizza_mercato(etichetta, scelta)
        riconosciuti = riconosciuti and riconosciuto and bool(mercato)
        componenti.append(
            {"mercato": mercato, "esito_giocato": esito or None, "mercato_giocatore": bool(_RE_GIOCATORE.search(etichetta))}
        )
    sel.componenti = componenti
    sel.mercato = " + ".join(c["mercato"] or "?" for c in componenti)
    sel.esito_giocato = " + ".join(c["esito_giocato"] for c in componenti if c["esito_giocato"]) or None
    sel.mercato_giocatore = any(c["mercato_giocatore"] for c in componenti)
    sel.testo_mercato = " | ".join(f"{e} {c}".strip() for e, c in coppie)
    return riconosciuti


def _segmenta_giocate_eplay(righe: list[str]) -> list[tuple[Optional[re.Match], Optional[re.Match], list[str]]]:
    """Divide le righe in giocate: (intestazione data-sport-campionato, riga della partita, righe del mercato).

    Più partite sotto la stessa intestazione ("10/10/2026 15:00 - Calcio - Serie A") condividono data e campionato:
    ogni riga "Casa vs Trasferta" apre una giocata nuova. Dopo un'intestazione, una riga che non è "A vs B" è l'evento
    di uno sport senza due squadre (tennis): il suo nome è la prima riga del blocco.
    """
    giocate: list[list] = []
    intestazione: Optional[re.Match] = None
    dopo_intestazione = False
    for riga in righe:
        if not riga:
            if giocate and giocate[-1][2]:
                giocate[-1][2].append("")
            continue
        trovata = _RE_INTESTAZIONE_EPLAY.search(riga)
        if trovata:
            intestazione, dopo_intestazione = trovata, True
            continue
        partita = _RE_PARTITA_EPLAY.match(_RE_PUNTINO.sub("", riga).strip())
        if partita:
            giocate.append([intestazione, partita, []])
        elif dopo_intestazione and not _RE_RUMORE.search(riga):
            giocate.append([intestazione, None, [riga]])
        elif giocate:
            giocate[-1][2].append(riga)
        dopo_intestazione = False
    return [tuple(g) for g in giocate]


def _leggi_eplay(righe: list[str], bozza: BozzaSchedina) -> None:
    for r in righe:
        if "Giocata del" in r:
            bozza.piazzata_il = data_ora(r)
            break
    if bozza.piazzata_il is None:
        bozza.avvisi.append("Orario di piazzamento non letto.")
    bozza.riferimento = next((codice_adm(r) for r in righe if "ADM" in r.upper()), None)
    bozza.stato = _stato_eplay(righe)

    indice_totali = next(
        (i for i, r in enumerate(righe) if re.search(r"Quota\s+totale(?!\s+evento)|Importo\s+pagato", r, re.I)),
        len(righe),
    )
    for intestazione, partita, blocco in _segmenta_giocate_eplay(righe[:indice_totali]):
        sel = BozzaSelezione()
        if intestazione is None:
            sel.avvisi.append("Campionato e orario d'inizio non visibili: completali.")
        else:
            sel.sport = intestazione.group("sport").strip()
            sel.competizione = correggi_competizione(intestazione.group("comp").strip())
            sel.inizio_evento = data_ora(intestazione.group("dt"))
        if partita:
            sel.squadra_casa, sel.squadra_trasferta = partita.group("casa").strip(), partita.group("osp").strip()
            if partita.group("g1") is not None and bozza.stato != STATO_IN_CORSO:
                sel.risultato_evento = f"{partita.group('g1')}-{partita.group('g2')}"
        elif blocco:
            sel.squadra_casa = blocco[0].strip()  # tennis e simili: un solo soggetto
            blocco = blocco[1:]
            sel.avvisi.append("Partita senza due squadre: controlla il nome dell'evento.")
        blocco = [
            _RE_PUNTINO.sub("", _RE_PUNTEGGIO.sub("", r)).strip() for r in blocco if not r or not _RE_RUMORE.search(r)
        ]
        for coppie, quota in _mercato_eplay(blocco):
            giocata = replace(sel, avvisi=list(sel.avvisi), quota=quota)
            if len(coppie) >= 2:
                riconosciuto = _applica_bet_builder(giocata, coppie)
            else:
                etichetta, scelta = coppie[0]
                giocata.testo_mercato = f"{etichetta} {scelta}".strip()
                giocata.mercato, giocata.esito_giocato, riconosciuto = normalizza_mercato(etichetta, scelta)
                giocata.mercato_giocatore = bool(_RE_GIOCATORE.search(etichetta))
            if not giocata.mercato:
                giocata.avvisi.append("Mercato non letto.")
            elif not riconosciuto:
                giocata.avvisi.append("Mercato non riconosciuto: controlla il nome e la scelta.")
            if giocata.quota is None:
                giocata.avvisi.append("Quota non letta.")
            bozza.selezioni.append(giocata)

    totali = righe[indice_totali:]
    bozza.quota_totale = _valore_dopo(totali, r"Quota\s+totale")
    bozza.stake = _valore_dopo(totali, r"Importo\s+pagato")
    bozza.bonus_importo = _valore_dopo(totali, r"Importo\s+bonus")
    bozza.vincita = _valore_dopo(totali, r"Vincita(?:\s+potenziale)?")
    if bozza.stake is None:
        bozza.avvisi.append("Puntata non letta.")


# --- controlli e completamento --------------------------------------------------------------------


def _prodotto_quote(selezioni: list[BozzaSelezione]) -> Optional[Decimal]:
    if not selezioni or any(s.quota is None for s in selezioni):
        return None
    prodotto = Decimal("1")
    for s in selezioni:
        prodotto *= s.quota
    return prodotto


def _distanza_uno(a: str, b: str) -> bool:
    """True se le due scritture differiscono per un solo carattere (sostituito, aggiunto o tolto)."""
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    corta, lunga = sorted((a, b), key=len)
    return len(lunga) - len(corta) == 1 and any(lunga[:i] + lunga[i + 1 :] == corta for i in range(len(lunga)))


def _distanza(a: str, b: str) -> int:
    """Numero minimo di caratteri da cambiare, aggiungere o togliere per passare da `a` a `b` (Levenshtein)."""
    precedente = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        corrente = [i]
        for j, cb in enumerate(b, start=1):
            corrente.append(min(precedente[j] + 1, corrente[j - 1] + 1, precedente[j - 1] + (ca != cb)))
        precedente = corrente
    return precedente[-1]


def _deduci_quota_mancante(bozza: BozzaSchedina) -> None:
    """Se una sola giocata non ha la quota ma c'è il totale, la quota è quella che fa tornare il totale."""
    mancanti = [s for s in bozza.selezioni if s.quota is None]
    if len(mancanti) != 1 or len(bozza.selezioni) < 2 or bozza.quota_totale is None:
        return
    prodotto_altre = Decimal("1")
    for s in bozza.selezioni:
        if s.quota is not None:
            prodotto_altre *= s.quota
    necessaria = _arrotonda(bozza.quota_totale / prodotto_altre)
    if necessaria >= Decimal("1.01"):
        mancanti[0].quota = necessaria
        # l'avviso generico c'è quasi sempre, ma una quota mancante può arrivare senza (bet builder letto male)
        mancanti[0].avvisi = [a for a in mancanti[0].avvisi if a != "Quota non letta."]
        mancanti[0].avvisi.append(f"Quota non letta: {necessaria} è quella che fa tornare la quota totale, controllala.")


def _ripara_totale_senza_separatore(bozza: BozzaSchedina) -> None:
    """"Quota totale: 315" è 3.15 senza il separatore decimale: lo si ripristina se torna con le quote."""
    prodotto = _prodotto_quote(bozza.selezioni)
    totale = bozza.quota_totale
    if prodotto is None or totale is None or totale < 100 or totale != totale.to_integral_value():
        return
    candidato = totale / 100
    if abs(prodotto - candidato) / candidato <= TOLLERANZA_QUOTA:
        bozza.quota_totale = candidato


def _ripara_quota(bozza: BozzaSchedina) -> None:
    """Se la quota totale non torna con le quote, prova a correggere una sola quota letta male.

    Le cifre sbagliate dall'OCR (1 al posto del separatore "|", 3 al posto di 1) sono l'errore più frequente.
    Si corregge solo se esiste UNA giocata la cui quota, cambiata di un carattere, fa tornare il totale.
    """
    if bozza.quota_totale is None or any(s.quota is None for s in bozza.selezioni) or len(bozza.selezioni) < 2:
        return
    prodotto = _prodotto_quote(bozza.selezioni)
    if abs(prodotto - bozza.quota_totale) / bozza.quota_totale <= TOLLERANZA_QUOTA:
        return
    soluzioni: list[tuple[BozzaSelezione, Decimal]] = []
    for scelta in bozza.selezioni:
        altre = prodotto / scelta.quota
        necessaria = _arrotonda(bozza.quota_totale / altre)
        torna = abs(altre * necessaria - bozza.quota_totale) / bozza.quota_totale <= Decimal("0.01")
        if torna and necessaria > 1 and _distanza_uno(f"{scelta.quota:.2f}", f"{necessaria:.2f}"):
            soluzioni.append((scelta, necessaria))
    if len(soluzioni) == 1:
        scelta, necessaria = soluzioni[0]
        scelta.avvisi.append(f"Quota letta {scelta.quota}, corretta in {necessaria} perché così torna con il totale.")
        scelta.quota = necessaria


def _ripara_puntata(bozza: BozzaSchedina) -> None:
    """Eplay24 mostra puntata, bonus e vincita: se non tornano, prova a correggere la puntata letta male."""
    if bozza.stake is None or bozza.quota_totale is None or bozza.vincita is None:
        return
    bonus = bozza.bonus_importo or Decimal("0")
    atteso = bozza.stake * bozza.quota_totale + bonus
    if abs(atteso - bozza.vincita) / bozza.vincita <= Decimal("0.01"):
        return
    necessaria = _arrotonda((bozza.vincita - bonus) / bozza.quota_totale)
    if necessaria > 0 and _distanza_uno(f"{bozza.stake:.2f}", f"{necessaria:.2f}"):
        bozza.avvisi.append(f"Puntata letta {bozza.stake}, corretta in {necessaria} perché così torna con la vincita.")
        bozza.stake = necessaria
        return
    # La quota totale è arrotondata a 2 decimali, quindi la puntata esatta può non uscire dal conto ("50,00" dà 49.99):
    # si prova un importo tondo (intero o mezzo euro) che spiega la vincita entro quell'arrotondamento, ma solo se
    # somiglia a quanto letto (al massimo due caratteri diversi: "920,00" è un "50,00" letto male).
    for passo in (Decimal("1"), Decimal("0.5")):
        tondo = (necessaria / passo).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * passo
        torna = abs(tondo * bozza.quota_totale + bonus - bozza.vincita) <= tondo * Decimal("0.005") + _CENT
        if tondo > 0 and torna and _distanza(f"{bozza.stake:.2f}", f"{tondo:.2f}") <= 2:
            bozza.avvisi.append(f"Puntata letta {bozza.stake}, corretta in {tondo} perché così torna con la vincita.")
            bozza.stake = tondo
            return


def _scarta_valori_non_validi(bozza: BozzaSchedina) -> None:
    """Un importo o una quota letti come zero o negativi sono errori dell'OCR: si tolgono e si segnalano."""
    for nome, etichetta in (("stake", "Puntata"), ("quota_totale", "Quota totale"), ("vincita", "Vincita")):
        valore = getattr(bozza, nome)
        if valore is not None and valore <= 0:
            setattr(bozza, nome, None)
            bozza.avvisi.append(f"{etichetta} non valida: controlla lo screenshot.")
    if bozza.quota_totale is not None and bozza.quota_totale < 1:
        bozza.quota_totale = None
        bozza.avvisi.append("Quota totale non valida: controlla lo screenshot.")
    for s in bozza.selezioni:
        if s.quota is not None and s.quota < Decimal("1.01"):
            s.quota = None
            s.avvisi.append("Quota non valida (sotto 1.01): controllala.")


def _completa(bozza: BozzaSchedina) -> None:
    """Esiti delle giocate, bonus multipla e controlli di quadratura."""
    _scarta_valori_non_validi(bozza)
    if bozza.stato == STATO_VINTA:
        for s in bozza.selezioni:
            s.esito = "vinta"
    elif bozza.stato == STATO_PERSA:
        if len(bozza.selezioni) == 1:
            bozza.selezioni[0].esito = "persa"
        elif bozza.selezioni:
            bozza.avvisi.append("Schedina persa: indica quale giocata ha fallito (lo screenshot non lo dice).")

    if len(bozza.selezioni) == 1 and bozza.selezioni[0].quota is None and bozza.quota_totale is not None:
        # singola: la quota della giocata è la quota totale (se letta come "315" va ripristinata a 3.15)
        unica = bozza.selezioni[0]
        totale = bozza.quota_totale
        unica.quota = totale / 100 if totale >= 100 and totale == totale.to_integral_value() else totale
        unica.avvisi.append("Quota presa dalla quota totale: controllala.")
    _deduci_quota_mancante(bozza)
    _ripara_totale_senza_separatore(bozza)
    _ripara_quota(bozza)
    if bozza.bookmaker == EPLAY24:
        _ripara_puntata(bozza)
    prodotto = _prodotto_quote(bozza.selezioni)
    if prodotto is not None and bozza.quota_totale is not None:
        scarto = abs(prodotto - bozza.quota_totale) / bozza.quota_totale
        if scarto > TOLLERANZA_QUOTA:
            mancano = prodotto < bozza.quota_totale
            bozza.avvisi.append(
                f"La quota totale letta ({bozza.quota_totale}) non torna con le quote delle giocate "
                f"({_arrotonda(prodotto)}): "
                + (
                    "forse mancano delle giocate (se ne hai un altro screenshot, usa Unisci)."
                    if mancano
                    else "controlla le quote."
                )
            )

    if len(bozza.selezioni) > 1 and bozza.stake and prodotto:
        base = bozza.stake * prodotto
        pct = None
        if bozza.vincita:
            pct = (bozza.vincita / base - 1) * 100
        elif bozza.bonus_importo:
            pct = bozza.bonus_importo / base * 100
        if pct is not None:
            if pct < -SOGLIA_BONUS_PCT:
                bozza.avvisi.append("La vincita è inferiore a puntata × quote: controlla puntata e quote.")
            elif pct > BONUS_PCT_MASSIMO:
                bozza.avvisi.append("Il bonus multipla risulta troppo alto: controlla puntata e vincita.")
            elif pct >= SOGLIA_BONUS_PCT:
                bozza.bonus_multipla_pct = pct.quantize(_CENT, rounding=ROUND_HALF_UP)
    elif len(bozza.selezioni) == 1 and bozza.stake and prodotto and bozza.vincita:
        atteso = bozza.stake * prodotto
        if abs(bozza.vincita - atteso) / atteso > Decimal("0.01"):
            bozza.avvisi.append("La vincita non torna con puntata × quota: controlla puntata e quota.")

    if not bozza.selezioni:
        bozza.avvisi.append("Nessuna giocata riconosciuta nello screenshot.")
        if bozza.bookmaker == EPLAY24 and bozza.stake is None:
            bozza.avvisi.append("Sembra la schedina ancora da giocare: carica lo screenshot della ricevuta.")


def leggi_schedina(righe: list[str]) -> BozzaSchedina:
    """Bozza di schedina dalle righe di testo di uno screenshot (vedi il docstring del modulo)."""
    righe = pulisci_righe(righe)
    bozza = BozzaSchedina()
    bozza.bookmaker = riconosci_bookmaker(righe)
    if bozza.bookmaker != EPLAY24:
        righe = [r for r in righe if r]
    if bozza.bookmaker == EPLAY24:
        _leggi_eplay(righe, bozza)
    elif bozza.bookmaker == BETSSON:
        _leggi_betsson(righe, bozza)
    else:
        bozza.avvisi.append("Non sembra una schedina di Betsson o Eplay24: compila i dati a mano.")
        return bozza
    _completa(bozza)
    return bozza


def _numero_avvisi(bozza: BozzaSchedina) -> int:
    return len(bozza.avvisi) + sum(len(s.avvisi) for s in bozza.selezioni)


def vale_un_secondo_tentativo(bozza: BozzaSchedina) -> bool:
    """True se la lettura ha dei dubbi: conviene riprovare con un'altra preparazione dell'immagine."""
    return _numero_avvisi(bozza) > 0


def scegli_lettura(prima: BozzaSchedina, seconda: BozzaSchedina) -> BozzaSchedina:
    """Delle due letture tiene quella con più giocate e, a parità, con meno avvisi (la prima se pari)."""
    if len(seconda.selezioni) != len(prima.selezioni):
        return seconda if len(seconda.selezioni) > len(prima.selezioni) else prima
    return seconda if _numero_avvisi(seconda) < _numero_avvisi(prima) else prima


def riferimento_bozza(bozza: BozzaSchedina) -> str:
    """Identificativo stabile per l'importazione: il codice ADM se letto, altrimenti bookmaker + ora + puntata."""
    if bozza.riferimento:
        return f"ADM {bozza.riferimento}"
    ora = bozza.piazzata_il.strftime("%Y%m%d%H%M") if bozza.piazzata_il else "senzaora"
    stake = f"{bozza.stake:.2f}" if bozza.stake is not None else "senzapuntata"
    return f"ocr:{(bozza.bookmaker or 'ignoto').lower()}:{ora}:{stake}"
