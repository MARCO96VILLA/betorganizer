from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import Callable, Optional

from app.models.enums import StatoGiocata

DUE_DECIMALI = Decimal("0.01")
TRE_DECIMALI = Decimal("0.001")

FASCE_QUOTA = [
    (Decimal("1.00"), Decimal("1.50"), "1.00–1.50"),
    (Decimal("1.50"), Decimal("2.00"), "1.50–2.00"),
    (Decimal("2.00"), Decimal("3.00"), "2.00–3.00"),
    (Decimal("3.00"), Decimal("5.00"), "3.00–5.00"),
    (Decimal("5.00"), None, "5.00+"),
]


def arrotonda_percentuale(valore: Decimal) -> Decimal:
    return valore.quantize(DUE_DECIMALI, rounding=ROUND_HALF_UP)


def arrotonda_importo(valore: Decimal) -> Decimal:
    return valore.quantize(DUE_DECIMALI, rounding=ROUND_HALF_UP)


def arrotonda_quota(valore: Decimal) -> Decimal:
    return valore.quantize(TRE_DECIMALI, rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class GiocataStat:
    profitto: Decimal
    stake: Decimal
    quota_totale: Decimal
    stato: StatoGiocata
    piazzata_il: datetime
    regolata_il: Optional[datetime] = None
    sport: tuple[str, ...] = ()
    squadre: tuple[str, ...] = ()
    campionati: tuple[str, ...] = ()
    bookmaker: str = ""
    tipo_giocata: str = ""
    tags: list[str] = field(default_factory=list)
    e_free_bet: bool = False


def filtra_rilevanti(giocate: list[GiocataStat], includi_free_bet: bool = False) -> list[GiocataStat]:
    """Giocate regolate (esclude pendenti e annullate) usate per le metriche di sezione 5.6.

    Le free bet sono escluse per impostazione predefinita (sezione 5.4).
    """
    return [
        g
        for g in giocate
        if g.stato not in (StatoGiocata.PENDENTE, StatoGiocata.ANNULLATA)
        and (includi_free_bet or not g.e_free_bet)
    ]


@dataclass(frozen=True)
class Metriche:
    numero_giocate: int
    profitto: Decimal
    giocato: Decimal
    yield_: Optional[Decimal]
    rendimento_capitale: Optional[Decimal]
    win_rate: Decimal
    quota_media: Decimal
    quota_media_ponderata: Decimal
    stake_medio: Decimal


def calcola_metriche(
    rilevanti: list[GiocataStat], capitale_medio: Optional[Decimal] = None
) -> Optional[Metriche]:
    """Metriche aggregate di sezione 5.6. `rilevanti` deve essere già filtrata da `filtra_rilevanti`."""
    n = len(rilevanti)
    if n == 0:
        return None

    profitto = sum((g.profitto for g in rilevanti), Decimal("0"))
    giocato = sum((g.stake for g in rilevanti), Decimal("0"))
    vinte = sum(1 for g in rilevanti if g.stato == StatoGiocata.VINTA)

    yield_ = arrotonda_percentuale(profitto / giocato * 100) if giocato > 0 else None
    rendimento_capitale = (
        arrotonda_percentuale(profitto / capitale_medio * 100)
        if capitale_medio and capitale_medio > 0
        else None
    )
    win_rate = arrotonda_percentuale(Decimal(vinte) / Decimal(n) * 100)
    quota_media = arrotonda_quota(sum((g.quota_totale for g in rilevanti), Decimal("0")) / n)
    quota_media_ponderata = (
        arrotonda_quota(sum((g.quota_totale * g.stake for g in rilevanti), Decimal("0")) / giocato)
        if giocato > 0
        else Decimal("0")
    )
    stake_medio = arrotonda_importo(giocato / n)

    return Metriche(
        numero_giocate=n,
        profitto=arrotonda_importo(profitto),
        giocato=arrotonda_importo(giocato),
        yield_=yield_,
        rendimento_capitale=rendimento_capitale,
        win_rate=win_rate,
        quota_media=quota_media,
        quota_media_ponderata=quota_media_ponderata,
        stake_medio=stake_medio,
    )


@dataclass(frozen=True)
class Drawdown:
    valore_assoluto: Decimal
    percentuale: Optional[Decimal]
    data_inizio: datetime
    data_fine: datetime


def calcola_drawdown(rilevanti_ordinate: list[GiocataStat]) -> Optional[Drawdown]:
    """Drawdown massimo sulla curva cumulativa del profitto, ordinata per regolata_il."""
    if not rilevanti_ordinate:
        return None

    cumulato = Decimal("0")
    picco = None
    picco_data = None
    max_drawdown = Decimal("-1")
    drawdown_inizio = drawdown_fine = None
    drawdown_picco_valore = None

    for g in rilevanti_ordinate:
        cumulato += g.profitto
        if picco is None or cumulato > picco:
            picco = cumulato
            picco_data = g.regolata_il
        else:
            corrente = picco - cumulato
            if corrente > max_drawdown:
                max_drawdown = corrente
                drawdown_inizio = picco_data
                drawdown_fine = g.regolata_il
                drawdown_picco_valore = picco

    if drawdown_inizio is None:
        return None

    percentuale = (
        arrotonda_percentuale(max_drawdown / drawdown_picco_valore * 100)
        if drawdown_picco_valore and drawdown_picco_valore > 0
        else None
    )

    return Drawdown(
        valore_assoluto=arrotonda_importo(max_drawdown),
        percentuale=percentuale,
        data_inizio=drawdown_inizio,
        data_fine=drawdown_fine,
    )


@dataclass(frozen=True)
class Serie:
    max_vinte_consecutive: int
    max_perse_consecutive: int


def calcola_serie(rilevanti_ordinate: list[GiocataStat]) -> Serie:
    """Striscia più lunga di vinte e di perse consecutive (sezione 5.6)."""
    cur_vinte = cur_perse = max_vinte = max_perse = 0
    for g in rilevanti_ordinate:
        if g.stato == StatoGiocata.VINTA:
            cur_vinte += 1
            cur_perse = 0
        elif g.stato == StatoGiocata.PERSA:
            cur_perse += 1
            cur_vinte = 0
        else:
            cur_vinte = cur_perse = 0
        max_vinte = max(max_vinte, cur_vinte)
        max_perse = max(max_perse, cur_perse)
    return Serie(max_vinte_consecutive=max_vinte, max_perse_consecutive=max_perse)


@dataclass(frozen=True)
class VoceBreakdown:
    chiave: str
    numero_giocate: int
    profitto: Decimal
    yield_: Optional[Decimal]


SOGLIA_MINIMA_CAMPIONE = 30
SOGLIA_STIMA_INCERTA = 200


def calcola_breakdown(
    rilevanti: list[GiocataStat], chiave_fn: Callable[[GiocataStat], list[str]]
) -> list[VoceBreakdown]:
    """Aggregazione per una dimensione (sport, bookmaker, ...), sezione 5.8.

    `chiave_fn` restituisce una lista di chiavi per ogni giocata (più di una per i tag).
    Sotto le 30 giocate una riga mostra solo conteggio e profitto assoluto, mai lo yield.
    """
    gruppi: dict[str, list[GiocataStat]] = {}
    for g in rilevanti:
        for chiave in chiave_fn(g):
            gruppi.setdefault(chiave, []).append(g)

    voci = []
    for chiave, membri in gruppi.items():
        numero = len(membri)
        profitto = sum((g.profitto for g in membri), Decimal("0"))
        giocato = sum((g.stake for g in membri), Decimal("0"))
        yield_ = (
            arrotonda_percentuale(profitto / giocato * 100)
            if numero >= SOGLIA_MINIMA_CAMPIONE and giocato > 0
            else None
        )
        voci.append(
            VoceBreakdown(
                chiave=chiave,
                numero_giocate=numero,
                profitto=arrotonda_importo(profitto),
                yield_=yield_,
            )
        )
    return voci


def fascia_quota(quota_totale: Decimal) -> str:
    for minimo, massimo, etichetta in FASCE_QUOTA:
        if quota_totale >= minimo and (massimo is None or quota_totale < massimo):
            return etichetta
    return FASCE_QUOTA[0][2]


def margine_atteso_casuale(margine: Decimal = Decimal("0.05")) -> Decimal:
    """Rendimento atteso di un giocatore casuale dato un margine bookmaker tipico.

    Stima grezza (sezione 5.7): a parità di margine m, il rendimento atteso di chi
    scommette a caso è -m/(1+m), indipendentemente dalla quota scelta.
    """
    return arrotonda_percentuale(-margine / (1 + margine) * 100)
