"""Conversioni di fuso orario. Il database conserva sempre istanti UTC "naive"; l'utente ragiona
in ora italiana, quindi gli orari in ingresso (import) e le analisi per fascia oraria passano da qui.
"""

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

FUSO_LOCALE = ZoneInfo("Europe/Rome")


def da_locale_a_utc(dt: datetime) -> datetime:
    """Orario italiano (naive, oppure con tz) -> UTC naive, come lo conserva il database."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=FUSO_LOCALE)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def da_utc_a_locale(dt: datetime) -> datetime:
    """UTC (naive o con tz) -> orario italiano naive."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(FUSO_LOCALE).replace(tzinfo=None)
