"""Analisi dello storico a livello di gamba (selezione), di mercato e di comportamento.

Pura: nessun I/O, nessun DB. Gli orari in ingresso sono UTC naive (come nel database); le
fasce orarie e i giorni si calcolano in ora italiana tramite `domain.tempo`.

Principio di onestà (CLAUDE.md): su campioni piccoli si mostrano conteggi e tassi con il loro
intervallo di confidenza, mai rendimenti percentuali presentati come segnale.
"""

import math
import re
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import Callable, Iterable, Optional

from app.domain.stats import SOGLIA_MINIMA_CAMPIONE, arrotonda_importo, arrotonda_percentuale
from app.domain.tempo import da_utc_a_locale
from app.models.enums import EsitoSelezione, StatoGiocata

GIORNI_SETTIMANA = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"]


# --- dati in ingresso ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SelezioneAn:
    sport: str
    squadra_casa: str
    mercato: str
    quota: Decimal
    esito: EsitoSelezione
    competizione: Optional[str] = None
    squadra_trasferta: Optional[str] = None
    esito_giocato: Optional[str] = None
    inizio_evento: Optional[datetime] = None
    mercato_giocatore: bool = False
    bet_builder: bool = False


@dataclass(frozen=True)
class GiocataAn:
    id: int
    stato: StatoGiocata
    stake: Decimal
    profitto: Decimal
    quota_totale: Decimal
    piazzata_il: datetime
    selezioni: tuple[SelezioneAn, ...]
    regolata_il: Optional[datetime] = None
    bonus_multipla_pct: Decimal = Decimal("0")
    bookmaker: str = ""
    e_free_bet: bool = False
    orario_approssimato: bool = False
    tags: tuple[str, ...] = ()


def _e_regolata(g: GiocataAn) -> bool:
    return g.stato not in (StatoGiocata.PENDENTE, StatoGiocata.ANNULLATA)


def regolate_rilevanti(giocate: Iterable[GiocataAn], includi_free_bet: bool = False) -> list[GiocataAn]:
    """Giocate regolate che concorrono alle metriche (esclude pendenti, annullate e, di default, free bet)."""
    return [g for g in giocate if _e_regolata(g) and (includi_free_bet or not g.e_free_bet)]


# --- famiglie di mercato --------------------------------------------------------------------------

# l'ordine conta: la prima regola che corrisponde vince (es. "MG Casa + U/O Cartellini" è Cartellini)
_REGOLE_FAMIGLIA: list[tuple[str, re.Pattern]] = [
    ("Cartellini", re.compile(r"cartellin", re.I)),
    ("Corner", re.compile(r"corner|calci d'angolo", re.I)),
    ("Tiri", re.compile(r"\btiri\b", re.I)),
    ("Parate", re.compile(r"\bparate\b", re.I)),
    ("Handicap", re.compile(r"handicap", re.I)),
    ("Tempi", re.compile(r"\b[12]T\b|\btemp[oi]\b", re.I)),
    ("Multigol", re.compile(r"\bMG\b", re.I)),
    ("Gol/NoGol", re.compile(r"gol/nogol|gg/ng|\bsegna\b", re.I)),
    ("Under/Over gol", re.compile(r"\bU/O\b", re.I)),
    ("Esito", re.compile(r"1X2|doppia chance|\bDC\b|^1X\b|\bvince\b|vincente", re.I)),
]


FAMIGLIA_BET_BUILDER = "Bet builder"


def famiglia_selezione(selezione) -> str:
    """Famiglia di una selezione: un bet builder (più mercati, una quota) ha la sua, perché la quota non si divide."""
    if getattr(selezione, "bet_builder", False):
        return FAMIGLIA_BET_BUILDER
    return famiglia_mercato(selezione.mercato, selezione.mercato_giocatore)


def famiglia_mercato(mercato: str, mercato_giocatore: bool = False) -> str:
    """Famiglia di appartenenza di un mercato, per confrontare giocate diverse sullo stesso tipo."""
    if mercato_giocatore or mercato.lower().startswith("giocatori"):
        return "Giocatori"
    for nome, schema in _REGOLE_FAMIGLIA:
        if schema.search(mercato):
            return nome
    return "Altro"


def e_mercato_combinato(mercato: str) -> bool:
    """True se il mercato unisce più componenti in un'unica selezione (es. 'DC + MG Totale')."""
    return " + " in mercato


_PREFISSI_ESITO = re.compile(r"^(1X2|DC|Doppia Chance|1X)\b", re.I)


def squadra_puntata(sel: SelezioneAn) -> Optional[str]:
    """Squadra su cui la selezione punta esplicitamente, se determinabile; altrimenti None.

    Copre i mercati con lato esplicito (Casa/Ospite, Squadra 1/2) e quelli di esito
    (1X2, doppia chance) in cui la scelta indica un lato.
    """
    testo = sel.mercato
    casa = bool(re.search(r"\bcasa\b|squadra 1\b", testo, re.I))
    ospite = bool(re.search(r"\bospite\b|squadra 2\b", testo, re.I))
    if casa != ospite:
        return sel.squadra_casa if casa else sel.squadra_trasferta
    if casa and ospite:
        return None

    if _PREFISSI_ESITO.search(testo) and sel.esito_giocato:
        primo = sel.esito_giocato.split("+")[0].strip().upper()
        if primo in ("1", "1X"):
            return sel.squadra_casa
        if primo in ("2", "X2"):
            return sel.squadra_trasferta
    return None


# --- tasso di centro sulle gambe -------------------------------------------------------------------


@dataclass(frozen=True)
class VoceGamba:
    chiave: str
    gambe: int
    vinte: int
    tasso: Decimal
    ic_basso: Decimal
    ic_alto: Decimal
    probabilita_implicita: Decimal
    vinte_attese: Decimal
    quota_media: Decimal
    campione_ridotto: bool


def selezioni_affidabili(giocate: Iterable[GiocataAn]) -> list[tuple[GiocataAn, SelezioneAn]]:
    """Coppie (giocata, selezione) con esito vinta/persa utilizzabili per statistiche per gamba.

    Esclude le selezioni di una multipla persa regolata in blocco (tutte segnate come perse):
    in quel caso l'esito della singola gamba non è informativo.
    """
    coppie = []
    for g in giocate:
        regolata_in_blocco = (
            g.stato == StatoGiocata.PERSA
            and len(g.selezioni) > 1
            and all(s.esito == EsitoSelezione.PERSA for s in g.selezioni)
        )
        if regolata_in_blocco:
            continue
        for s in g.selezioni:
            if s.esito in (EsitoSelezione.VINTA, EsitoSelezione.PERSA):
                coppie.append((g, s))
    return coppie


def intervallo_wilson(successi: int, n: int, z: float = 1.96) -> tuple[Decimal, Decimal]:
    """Intervallo di confidenza di Wilson (95% di default) per una proporzione, in punti percentuali."""
    if n == 0:
        return Decimal("0.00"), Decimal("0.00")
    p = successi / n
    denominatore = 1 + z * z / n
    centro = (p + z * z / (2 * n)) / denominatore
    scarto = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominatore
    basso = max(0.0, centro - scarto) * 100
    alto = min(1.0, centro + scarto) * 100
    return arrotonda_percentuale(Decimal(str(basso))), arrotonda_percentuale(Decimal(str(alto)))


def calcola_tasso_gambe(
    coppie: list[tuple[GiocataAn, SelezioneAn]],
    chiave_fn: Callable[[GiocataAn, SelezioneAn], list[str]],
) -> list[VoceGamba]:
    """Tasso di centro delle gambe per una dimensione, confrontato con la probabilità implicita nelle quote."""
    gruppi: dict[str, list[SelezioneAn]] = {}
    for g, s in coppie:
        for chiave in chiave_fn(g, s):
            gruppi.setdefault(chiave, []).append(s)

    voci = []
    for chiave, sels in gruppi.items():
        n = len(sels)
        vinte = sum(1 for s in sels if s.esito == EsitoSelezione.VINTA)
        implicite = [Decimal("1") / s.quota for s in sels]
        ic_basso, ic_alto = intervallo_wilson(vinte, n)
        voci.append(
            VoceGamba(
                chiave=chiave,
                gambe=n,
                vinte=vinte,
                tasso=arrotonda_percentuale(Decimal(vinte) / n * 100),
                ic_basso=ic_basso,
                ic_alto=ic_alto,
                probabilita_implicita=arrotonda_percentuale(sum(implicite, Decimal("0")) / n * 100),
                vinte_attese=sum(implicite, Decimal("0")).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP),
                quota_media=(sum((s.quota for s in sels), Decimal("0")) / n).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_UP
                ),
                campione_ridotto=n < SOGLIA_MINIMA_CAMPIONE,
            )
        )
    return voci


FASCE_QUOTA_GAMBA = [
    (Decimal("1.00"), Decimal("1.30"), "sotto 1.30"),
    (Decimal("1.30"), Decimal("1.45"), "1.30–1.45"),
    (Decimal("1.45"), Decimal("1.60"), "1.45–1.60"),
    (Decimal("1.60"), Decimal("1.80"), "1.60–1.80"),
    (Decimal("1.80"), Decimal("2.20"), "1.80–2.20"),
    (Decimal("2.20"), None, "2.20 e oltre"),
]


def fascia_quota_gamba(quota: Decimal) -> str:
    for minimo, massimo, etichetta in FASCE_QUOTA_GAMBA:
        if quota >= minimo and (massimo is None or quota < massimo):
            return etichetta
    return FASCE_QUOTA_GAMBA[0][2]


# --- aggregazione per giocata -----------------------------------------------------------------------


@dataclass(frozen=True)
class VoceGruppo:
    chiave: str
    numero: int
    vinte: int
    perse: int
    giocato: Decimal
    profitto: Decimal
    yield_: Optional[Decimal]


def aggrega_per_chiave(
    rilevanti: list[GiocataAn], chiave_fn: Callable[[GiocataAn], list[str]]
) -> list[VoceGruppo]:
    """Conteggio vinte/perse, giocato e profitto per dimensione. Lo yield compare solo da 30 giocate."""
    gruppi: dict[str, list[GiocataAn]] = {}
    for g in rilevanti:
        for chiave in chiave_fn(g):
            gruppi.setdefault(chiave, []).append(g)

    voci = []
    for chiave, membri in gruppi.items():
        giocato = sum((g.stake for g in membri), Decimal("0"))
        profitto = sum((g.profitto for g in membri), Decimal("0"))
        voci.append(
            VoceGruppo(
                chiave=chiave,
                numero=len(membri),
                vinte=sum(1 for g in membri if g.stato == StatoGiocata.VINTA),
                perse=sum(1 for g in membri if g.stato == StatoGiocata.PERSA),
                giocato=arrotonda_importo(giocato),
                profitto=arrotonda_importo(profitto),
                yield_=(
                    arrotonda_percentuale(profitto / giocato * 100)
                    if len(membri) >= SOGLIA_MINIMA_CAMPIONE and giocato > 0
                    else None
                ),
            )
        )
    return voci


def fascia_oraria(piazzata_il: datetime) -> str:
    ora = da_utc_a_locale(piazzata_il).hour
    if ora < 6:
        return "Notte (00–06)"
    if ora < 12:
        return "Mattina (06–12)"
    if ora < 18:
        return "Pomeriggio (12–18)"
    return "Sera (18–24)"


def giorno_settimana(piazzata_il: datetime) -> str:
    return GIORNI_SETTIMANA[da_utc_a_locale(piazzata_il).weekday()]


def fascia_gambe(numero: int) -> str:
    if numero == 1:
        return "1 giocata (singola)"
    if numero <= 5:
        return f"{numero} giocate"
    if numero <= 7:
        return "6–7 giocate"
    return "8 o più giocate"


def fascia_stake(stake: Decimal) -> str:
    if stake < 10:
        return "meno di 10 €"
    if stake < 20:
        return "10–20 €"
    if stake < 50:
        return "20–50 €"
    return "50 € o più"


def anticipo_ore(giocata: GiocataAn) -> Optional[float]:
    """Ore tra il piazzamento e l'inizio del primo evento; None se mancano gli orari o l'orario di gioco è stimato."""
    if giocata.orario_approssimato:
        return None
    inizi = [s.inizio_evento for s in giocata.selezioni if s.inizio_evento]
    if not inizi:
        return None
    return (min(inizi) - giocata.piazzata_il).total_seconds() / 3600


def fascia_anticipo(ore: float) -> str:
    if ore <= 0:
        return "A evento iniziato"
    if ore < 1:
        return "Meno di 1 ora prima"
    if ore < 6:
        return "1–6 ore prima"
    if ore < 24:
        return "6–24 ore prima"
    return "Più di 24 ore prima"


def mese_di(data: datetime) -> str:
    return da_utc_a_locale(data).strftime("%Y-%m")


def giorno_di(data: datetime) -> str:
    return da_utc_a_locale(data).strftime("%Y-%m-%d")


# --- quasi-vincite ----------------------------------------------------------------------------------


@dataclass(frozen=True)
class QuasiVincita:
    giocata_id: int
    stake: Decimal
    mancato_ritorno: Decimal
    gamba_fallita: SelezioneAn
    gambe: int


@dataclass(frozen=True)
class AnalisiQuasiVincite:
    multiple_perse: int
    perse_per_una_gamba: int
    stake_perso_per_una_gamba: Decimal
    mancato_ritorno: Decimal
    famiglie_gamba_fallita: list[tuple[str, int]]
    elenco: list[QuasiVincita]


def analizza_quasi_vincite(rilevanti: list[GiocataAn]) -> AnalisiQuasiVincite:
    """Multiple perse per una sola gamba (le altre tutte vinte).

    Considera solo multiple con gambe regolate individualmente: una multipla persa e regolata in
    blocco non permette di sapere quale gamba abbia fallito.
    """
    multiple_perse = 0
    quasi: list[QuasiVincita] = []
    for g in rilevanti:
        if g.stato != StatoGiocata.PERSA or len(g.selezioni) < 2:
            continue
        if all(s.esito == EsitoSelezione.PERSA for s in g.selezioni):
            continue
        multiple_perse += 1
        indici_persi = [i for i, s in enumerate(g.selezioni) if s.esito == EsitoSelezione.PERSA]
        if len(indici_persi) != 1:
            continue
        if any(s.esito != EsitoSelezione.VINTA for i, s in enumerate(g.selezioni) if i != indici_persi[0]):
            continue
        prodotto = Decimal("1")
        for s in g.selezioni:
            prodotto *= s.quota
        mancato = g.stake * prodotto * (Decimal("1") + g.bonus_multipla_pct / 100)
        quasi.append(
            QuasiVincita(
                giocata_id=g.id,
                stake=g.stake,
                mancato_ritorno=arrotonda_importo(mancato),
                gamba_fallita=g.selezioni[indici_persi[0]],
                gambe=len(g.selezioni),
            )
        )

    conteggio = Counter(famiglia_selezione(q.gamba_fallita) for q in quasi)
    return AnalisiQuasiVincite(
        multiple_perse=multiple_perse,
        perse_per_una_gamba=len(quasi),
        stake_perso_per_una_gamba=arrotonda_importo(sum((q.stake for q in quasi), Decimal("0"))),
        mancato_ritorno=arrotonda_importo(sum((q.mancato_ritorno for q in quasi), Decimal("0"))),
        famiglie_gamba_fallita=sorted(conteggio.items(), key=lambda kv: (-kv[1], kv[0])),
        elenco=sorted(quasi, key=lambda q: -q.mancato_ritorno),
    )


# --- esposizione sugli eventi ------------------------------------------------------------------------


@dataclass(frozen=True)
class EsposizioneEvento:
    evento: str
    data: Optional[str]
    giocate: int
    stake_totale: Decimal
    giocate_pendenti: int
    stake_pendente: Decimal
    profitto_regolato: Decimal


def _chiave_evento(s: SelezioneAn) -> tuple[str, Optional[str]]:
    nome = f"{s.squadra_casa} - {s.squadra_trasferta}" if s.squadra_trasferta else s.squadra_casa
    data = giorno_di(s.inizio_evento) if s.inizio_evento else None
    return nome, data


def esposizione_eventi(giocate: Iterable[GiocataAn], minimo_giocate: int = 2) -> list[EsposizioneEvento]:
    """Eventi presenti in più giocate: la concentrazione del rischio su una stessa partita.

    Ogni giocata conta una volta per evento anche se contiene più selezioni sulla stessa partita.
    Le free bet e le annullate non sono esposizione.
    """
    gruppi: dict[tuple[str, Optional[str]], dict[int, GiocataAn]] = {}
    for g in giocate:
        if g.stato == StatoGiocata.ANNULLATA or g.e_free_bet:
            continue
        for s in g.selezioni:
            gruppi.setdefault(_chiave_evento(s), {})[g.id] = g

    risultato = []
    for (evento, data), per_id in gruppi.items():
        membri = list(per_id.values())
        if len(membri) < minimo_giocate:
            continue
        pendenti = [g for g in membri if g.stato == StatoGiocata.PENDENTE]
        regolate = [g for g in membri if g.stato != StatoGiocata.PENDENTE]
        risultato.append(
            EsposizioneEvento(
                evento=evento,
                data=data,
                giocate=len(membri),
                stake_totale=arrotonda_importo(sum((g.stake for g in membri), Decimal("0"))),
                giocate_pendenti=len(pendenti),
                stake_pendente=arrotonda_importo(sum((g.stake for g in pendenti), Decimal("0"))),
                profitto_regolato=arrotonda_importo(sum((g.profitto for g in regolate), Decimal("0"))),
            )
        )
    return sorted(risultato, key=lambda e: (-e.giocate, -e.stake_totale, e.evento))


# --- serie temporali ---------------------------------------------------------------------------------


@dataclass(frozen=True)
class PuntoCumulato:
    data: datetime
    giocata_id: int
    profitto: Decimal
    cumulato: Decimal


def serie_cumulata(rilevanti: list[GiocataAn]) -> list[PuntoCumulato]:
    """Profitto cumulato giocata per giocata, in ordine di regolazione."""
    ordinate = sorted((g for g in rilevanti if g.regolata_il), key=lambda g: (g.regolata_il, g.id))
    cumulato = Decimal("0")
    punti = []
    for g in ordinate:
        cumulato += g.profitto
        punti.append(
            PuntoCumulato(
                data=g.regolata_il, giocata_id=g.id, profitto=g.profitto, cumulato=arrotonda_importo(cumulato)
            )
        )
    return punti


@dataclass(frozen=True)
class QuotaAttesa:
    """Confronto tra giocate multiple vinte e quante ne prevedeva il prezzo (prodotto delle probabilità implicite)."""

    giocate: int
    vinte: int
    vinte_attese: Decimal


def vinte_attese_giocate(rilevanti: list[GiocataAn]) -> QuotaAttesa:
    """Quante giocate ci si aspetterebbe vinte se le quote fossero esattamente la probabilità reale."""
    totale = Decimal("0")
    contate = 0
    vinte = 0
    for g in rilevanti:
        if g.quota_totale <= 0 or g.stato not in (StatoGiocata.VINTA, StatoGiocata.PERSA):
            continue
        totale += Decimal("1") / g.quota_totale
        contate += 1
        if g.stato == StatoGiocata.VINTA:
            vinte += 1
    return QuotaAttesa(
        giocate=contate, vinte=vinte, vinte_attese=totale.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    )


@dataclass(frozen=True)
class ValoreBonus:
    giocate_vinte_con_bonus: int
    bonus_incassato: Decimal


def valore_bonus(rilevanti: list[GiocataAn]) -> ValoreBonus:
    """Quanto hanno aggiunto in totale i bonus multipla sulle giocate vinte (free bet escluse)."""
    totale = Decimal("0")
    contate = 0
    for g in rilevanti:
        if g.stato != StatoGiocata.VINTA or g.e_free_bet or g.bonus_multipla_pct <= 0:
            continue
        ritorno = g.profitto + g.stake
        senza_bonus = ritorno / (Decimal("1") + g.bonus_multipla_pct / 100)
        totale += ritorno - senza_bonus
        contate += 1
    return ValoreBonus(giocate_vinte_con_bonus=contate, bonus_incassato=arrotonda_importo(totale))


# --- prima di giocare ---------------------------------------------------------------------------------

MARGINE_IPOTETICO = Decimal("0.05")
MINIMO_GAMBE_STORICO = 10


@dataclass(frozen=True)
class SelezioneBozza:
    famiglia: str
    fascia_quota: str
    quota: Decimal
    probabilita_implicita: Decimal
    storico_famiglia: Optional[VoceGamba]
    storico_fascia: Optional[VoceGamba]


@dataclass(frozen=True)
class AnalisiBozza:
    selezioni: list[SelezioneBozza]
    quota_totale: Decimal
    probabilita_pareggio: Decimal
    margine_ipotetico: Decimal
    ritorno_atteso_per_euro: Decimal
    probabilita_dallo_storico: Optional[Decimal]
    ritorno_atteso_storico: Optional[Decimal]


def analizza_bozza(
    bozza: list[SelezioneAn],
    coppie_storico: list[tuple[GiocataAn, SelezioneAn]],
    bonus_multipla_pct: Decimal = Decimal("0"),
    margine: Decimal = MARGINE_IPOTETICO,
) -> AnalisiBozza:
    """Quello che si sa di una schedina prima di giocarla, dalle quote e dallo storico dell'utente.

    - `probabilita_pareggio`: probabilità di vincerla sotto la quale si perde a lungo andare (1 / (quota × bonus)).
    - `ritorno_atteso_per_euro`: ritorno medio per euro se ogni giocata avesse il margine ipotetico `margine`
      sul prezzo: (1 − margine)^N, senza bonus. È una stima di scuola, non il margine reale del bookmaker.
    - `probabilita_dallo_storico`: prodotto dei tassi di centro dello storico per tipo di mercato, solo se
      **tutte** le giocate hanno almeno MINIMO_GAMBE_STORICO osservazioni; altrimenti None.
    """
    voci_famiglia = {
        v.chiave: v for v in calcola_tasso_gambe(coppie_storico, lambda g, s: [famiglia_selezione(s)])
    }
    voci_fascia = {
        v.chiave: v for v in calcola_tasso_gambe(coppie_storico, lambda g, s: [fascia_quota_gamba(s.quota)])
    }

    selezioni = []
    quota_totale = Decimal("1")
    tassi: list[Decimal] = []
    tutte_con_storico = True
    for s in bozza:
        famiglia = famiglia_selezione(s)
        fascia = fascia_quota_gamba(s.quota)
        voce_famiglia = voci_famiglia.get(famiglia)
        selezioni.append(
            SelezioneBozza(
                famiglia=famiglia,
                fascia_quota=fascia,
                quota=s.quota,
                probabilita_implicita=arrotonda_percentuale(Decimal("100") / s.quota),
                storico_famiglia=voce_famiglia,
                storico_fascia=voci_fascia.get(fascia),
            )
        )
        quota_totale *= s.quota
        if voce_famiglia is not None and voce_famiglia.gambe >= MINIMO_GAMBE_STORICO:
            tassi.append(voce_famiglia.tasso / 100)
        else:
            tutte_con_storico = False

    moltiplicatore_bonus = Decimal("1") + bonus_multipla_pct / 100
    probabilita_storico: Optional[Decimal] = None
    ritorno_storico: Optional[Decimal] = None
    if bozza and tutte_con_storico:
        prodotto = Decimal("1")
        for t in tassi:
            prodotto *= t
        probabilita_storico = arrotonda_percentuale(prodotto * 100)
        ritorno_storico = (prodotto * quota_totale * moltiplicatore_bonus).quantize(
            Decimal("0.001"), rounding=ROUND_HALF_UP
        )

    ritorno_atteso = (Decimal("1") - margine) ** len(bozza) if bozza else Decimal("1")
    return AnalisiBozza(
        selezioni=selezioni,
        quota_totale=quota_totale.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP),
        probabilita_pareggio=arrotonda_percentuale(Decimal("100") / (quota_totale * moltiplicatore_bonus)),
        margine_ipotetico=arrotonda_percentuale(margine * 100),
        ritorno_atteso_per_euro=ritorno_atteso.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP),
        probabilita_dallo_storico=probabilita_storico,
        ritorno_atteso_storico=ritorno_storico,
    )


@dataclass(frozen=True)
class Sovrapposizione:
    giocata_id: int
    stake: Decimal
    evento: str


def sovrapposizioni_bozza(bozza: list[SelezioneAn], giocate_aperte: Iterable[GiocataAn]) -> list[Sovrapposizione]:
    """Schedine ancora aperte che contengono già una delle partite della bozza (stesse squadre; stessa data se nota)."""
    chiavi_bozza = {_chiave_evento(s) for s in bozza}
    trovate = []
    for g in giocate_aperte:
        if g.stato != StatoGiocata.PENDENTE or g.e_free_bet:
            continue
        for s in g.selezioni:
            nome, data = _chiave_evento(s)
            corrisponde = any(
                nome == n and (data is None or d is None or data == d) for n, d in chiavi_bozza
            )
            if corrisponde:
                trovate.append(Sovrapposizione(giocata_id=g.id, stake=g.stake, evento=nome))
                break
    return trovate
