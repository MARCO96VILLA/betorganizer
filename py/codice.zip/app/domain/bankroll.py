from dataclasses import dataclass
from decimal import Decimal

from app.domain.payout import arrotonda_importo


@dataclass(frozen=True)
class RisultatoSaldi:
    saldo_liquido: Decimal
    capitale_in_gioco: Decimal
    capitale_totale: Decimal


def calcola_saldi(
    depositi: Decimal,
    prelievi: Decimal,
    rettifiche: Decimal,
    profitti_giocate_regolate: Decimal,
    stake_giocate_pendenti: Decimal,
    bonus: Decimal = Decimal("0"),
) -> RisultatoSaldi:
    """Saldi di un bankroll (sezione 5.5).

    `stake_giocate_pendenti` deve già escludere le free bet: lo stake di una free bet
    non è mai stato addebitato al bankroll, quindi non va sottratto qui.
    `bonus` sono i crediti promozionali accreditati dai bookmaker: valgono come saldo reale ma restano
    distinti dai depositi (non sono capitale versato dall'utente).
    """
    saldo_liquido = (
        depositi - prelievi + rettifiche + bonus + profitti_giocate_regolate - stake_giocate_pendenti
    )
    capitale_in_gioco = stake_giocate_pendenti
    capitale_totale = saldo_liquido + capitale_in_gioco

    return RisultatoSaldi(
        saldo_liquido=arrotonda_importo(saldo_liquido),
        capitale_in_gioco=arrotonda_importo(capitale_in_gioco),
        capitale_totale=arrotonda_importo(capitale_totale),
    )
