from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Optional

from app.models.enums import TipoGiocata, TipoRegola


@dataclass(frozen=True)
class RegolaDef:
    tipo: TipoRegola
    valore: Any


@dataclass(frozen=True)
class CandidataGiocata:
    tipo_giocata: TipoGiocata
    quota_totale: Decimal
    stake: Decimal
    numero_selezioni: int
    sport: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ContestoRegole:
    capitale_totale: Decimal
    giocate_piazzate_oggi: int
    perdita_netta_oggi: Decimal
    ultima_giocata_persa_regolata_il: Optional[datetime] = None
    ora: Optional[datetime] = None


@dataclass(frozen=True)
class ViolazioneRegola:
    tipo: TipoRegola
    descrizione: str


def _valuta_una(regola: RegolaDef, candidata: CandidataGiocata, contesto: ContestoRegole) -> Optional[str]:
    tipo, valore = regola.tipo, regola.valore

    if tipo == TipoRegola.QUOTA_MINIMA:
        soglia = Decimal(str(valore))
        if candidata.quota_totale < soglia:
            return f"Quota {candidata.quota_totale} sotto la quota minima {soglia}"

    elif tipo == TipoRegola.QUOTA_MASSIMA:
        soglia = Decimal(str(valore))
        if candidata.quota_totale > soglia:
            return f"Quota {candidata.quota_totale} sopra la quota massima {soglia}"

    elif tipo == TipoRegola.STAKE_MASSIMO_ASSOLUTO:
        soglia = Decimal(str(valore))
        if candidata.stake > soglia:
            return f"Stake {candidata.stake} sopra il massimo assoluto {soglia}"

    elif tipo == TipoRegola.STAKE_MASSIMO_PERCENTUALE:
        percentuale = Decimal(str(valore))
        soglia = contesto.capitale_totale * percentuale
        if candidata.stake > soglia:
            return f"Stake {candidata.stake} sopra il {percentuale * 100}% del capitale ({soglia})"

    elif tipo == TipoRegola.MAX_GIOCATE_GIORNO:
        soglia = int(valore)
        if contesto.giocate_piazzate_oggi >= soglia:
            return f"Già {contesto.giocate_piazzate_oggi} schedine piazzate oggi (limite {soglia})"

    elif tipo == TipoRegola.MAX_SELEZIONI_MULTIPLA:
        soglia = int(valore)
        if candidata.numero_selezioni > soglia:
            return f"{candidata.numero_selezioni} selezioni sopra il limite {soglia}"

    elif tipo == TipoRegola.SPORT_AMMESSI:
        ammessi = set(valore)
        non_ammessi = [s for s in candidata.sport if s not in ammessi]
        if non_ammessi:
            return f"Sport non ammessi: {', '.join(non_ammessi)}"

    elif tipo == TipoRegola.TIPI_GIOCATA_AMMESSI:
        ammessi = set(valore)
        if candidata.tipo_giocata.value not in ammessi:
            return f"Tipo di schedina '{candidata.tipo_giocata.value}' non ammesso"

    elif tipo == TipoRegola.COOLDOWN_DOPO_PERDITA_MINUTI:
        minuti = int(valore)
        if contesto.ultima_giocata_persa_regolata_il is not None:
            ora = contesto.ora or datetime.now(contesto.ultima_giocata_persa_regolata_il.tzinfo)
            trascorsi = ora - contesto.ultima_giocata_persa_regolata_il
            if trascorsi < timedelta(minutes=minuti):
                minuti_rimanenti = minuti - int(trascorsi.total_seconds() // 60)
                return f"Cooldown dopo una perdita: ancora {minuti_rimanenti} minuti"

    elif tipo == TipoRegola.PERDITA_MASSIMA_GIORNALIERA:
        soglia = Decimal(str(valore))
        if contesto.perdita_netta_oggi >= soglia:
            return f"Perdita netta di oggi ({contesto.perdita_netta_oggi}) oltre il limite {soglia}"

    return None


def valuta_regole(
    regole: list[RegolaDef], candidata: CandidataGiocata, contesto: ContestoRegole
) -> list[ViolazioneRegola]:
    """Valuta ogni regola attiva contro una giocata candidata (sezione 8). Non blocca mai:
    restituisce solo l'elenco delle violazioni, da mostrare come avviso e salvare come snapshot.
    """
    violazioni = []
    for regola in regole:
        descrizione = _valuta_una(regola, candidata, contesto)
        if descrizione:
            violazioni.append(ViolazioneRegola(tipo=regola.tipo, descrizione=descrizione))
    return violazioni


@dataclass(frozen=True)
class GiocataAderenza:
    profitto: Decimal
    tipi_violati: list[TipoRegola] = field(default_factory=list)


@dataclass(frozen=True)
class Aderenza:
    numero_giocate: int
    numero_conformi: int
    punteggio: Decimal
    costo_per_regola: list[tuple]  # (TipoRegola, Decimal profitto), dal più costoso


def calcola_aderenza(giocate: list[GiocataAderenza]) -> Optional[Aderenza]:
    """Analisi di aderenza (sezione 8): punteggio e costo per regola.

    Il costo di una regola è il profitto complessivo delle giocate che l'hanno violata:
    più è negativo, più quella regola (se rispettata) avrebbe risparmiato.
    """
    n = len(giocate)
    if n == 0:
        return None

    conformi = sum(1 for g in giocate if not g.tipi_violati)
    punteggio = (Decimal(conformi) / Decimal(n) * 100).quantize(Decimal("0.01"))

    costo: dict[TipoRegola, Decimal] = {}
    for g in giocate:
        for tipo in set(g.tipi_violati):
            costo[tipo] = costo.get(tipo, Decimal("0")) + g.profitto

    costo_ordinato = sorted(costo.items(), key=lambda kv: kv[1])

    return Aderenza(
        numero_giocate=n,
        numero_conformi=conformi,
        punteggio=punteggio,
        costo_per_regola=costo_ordinato,
    )
