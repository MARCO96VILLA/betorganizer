from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./data/bet_tracker.db"
    invite_code: str = "change-me"
    jwt_secret: str = "change-me-too"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60 * 24 * 30
    cookie_name: str = "bt_session"
    cookie_secure: bool = False
    cors_origins: list[str] = ["http://localhost:5173"]


settings = Settings()
