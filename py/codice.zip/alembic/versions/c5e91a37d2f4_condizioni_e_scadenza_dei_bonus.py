"""condizioni e scadenza dei bonus

Revision ID: c5e91a37d2f4
Revises: b2d84f6a1c37
Create Date: 2026-10-18 15:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'c5e91a37d2f4'
down_revision: Union[str, None] = 'b2d84f6a1c37'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('movimento_bankroll') as batch_op:
        batch_op.add_column(sa.Column('scadenza', sa.DateTime(), nullable=True))
        batch_op.add_column(sa.Column('condizioni', sa.JSON(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table('movimento_bankroll') as batch_op:
        batch_op.drop_column('condizioni')
        batch_op.drop_column('scadenza')
