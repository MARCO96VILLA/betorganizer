"""aggiungi bankroll_id a strategia

Revision ID: ef338fd2cf8f
Revises: 1ab36d4850cd
Create Date: 2026-07-26 17:26:02.994616

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = 'ef338fd2cf8f'
down_revision: Union[str, None] = '1ab36d4850cd'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # SQLite non supporta ALTER dei vincoli: si usa la batch mode (copy-and-move).
    with op.batch_alter_table('strategia') as batch_op:
        batch_op.add_column(sa.Column('bankroll_id', sa.Integer(), nullable=False))
        batch_op.create_index(op.f('ix_strategia_bankroll_id'), ['bankroll_id'], unique=False)
        batch_op.create_foreign_key('fk_strategia_bankroll_id', 'bankroll', ['bankroll_id'], ['id'])


def downgrade() -> None:
    with op.batch_alter_table('strategia') as batch_op:
        batch_op.drop_constraint('fk_strategia_bankroll_id', type_='foreignkey')
        batch_op.drop_index(op.f('ix_strategia_bankroll_id'))
        batch_op.drop_column('bankroll_id')
