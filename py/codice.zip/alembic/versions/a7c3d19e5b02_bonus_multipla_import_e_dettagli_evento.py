"""bonus multipla, riferimento esterno, orario approssimato e dettagli evento

Revision ID: a7c3d19e5b02
Revises: 1e94ff47c756
Create Date: 2026-10-18 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = 'a7c3d19e5b02'
down_revision: Union[str, None] = '1e94ff47c756'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('giocata') as batch_op:
        batch_op.add_column(
            sa.Column('bonus_multipla_pct', sa.Numeric(6, 2), nullable=False, server_default='0')
        )
        batch_op.add_column(
            sa.Column('riferimento_esterno', sqlmodel.sql.sqltypes.AutoString(), nullable=True)
        )
        batch_op.add_column(
            sa.Column('orario_approssimato', sa.Boolean(), nullable=False, server_default=sa.false())
        )
        batch_op.create_index(
            batch_op.f('ix_giocata_riferimento_esterno'), ['riferimento_esterno'], unique=False
        )
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.add_column(sa.Column('inizio_evento', sa.DateTime(), nullable=True))
        batch_op.add_column(
            sa.Column('risultato_evento', sqlmodel.sql.sqltypes.AutoString(), nullable=True)
        )
        batch_op.add_column(
            sa.Column('mercato_giocatore', sa.Boolean(), nullable=False, server_default=sa.false())
        )


def downgrade() -> None:
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.drop_column('mercato_giocatore')
        batch_op.drop_column('risultato_evento')
        batch_op.drop_column('inizio_evento')
    with op.batch_alter_table('giocata') as batch_op:
        batch_op.drop_index(batch_op.f('ix_giocata_riferimento_esterno'))
        batch_op.drop_column('orario_approssimato')
        batch_op.drop_column('riferimento_esterno')
        batch_op.drop_column('bonus_multipla_pct')
