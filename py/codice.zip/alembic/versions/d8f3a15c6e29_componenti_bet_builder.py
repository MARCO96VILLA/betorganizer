"""componenti del bet builder

Revision ID: d8f3a15c6e29
Revises: c5e91a37d2f4
Create Date: 2026-10-18 16:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'd8f3a15c6e29'
down_revision: Union[str, None] = 'c5e91a37d2f4'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.add_column(sa.Column('componenti', sa.JSON(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.drop_column('componenti')
