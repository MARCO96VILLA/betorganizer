"""bookmaker sui movimenti del bankroll

Revision ID: b2d84f6a1c37
Revises: a7c3d19e5b02
Create Date: 2026-10-18 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = 'b2d84f6a1c37'
down_revision: Union[str, None] = 'a7c3d19e5b02'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('movimento_bankroll') as batch_op:
        batch_op.add_column(
            sa.Column('bookmaker', sqlmodel.sql.sqltypes.AutoString(), nullable=True)
        )
        batch_op.create_index(
            batch_op.f('ix_movimento_bankroll_bookmaker'), ['bookmaker'], unique=False
        )


def downgrade() -> None:
    with op.batch_alter_table('movimento_bankroll') as batch_op:
        batch_op.drop_index(batch_op.f('ix_movimento_bankroll_bookmaker'))
        batch_op.drop_column('bookmaker')
