"""squadre campionato mercato in selezione

Revision ID: 9e41fac40cd5
Revises: ef338fd2cf8f
Create Date: 2026-07-27 14:15:22.777917

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = '9e41fac40cd5'
down_revision: Union[str, None] = 'ef338fd2cf8f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # SQLite non supporta ALTER/DROP di colonne: si usa la batch mode (copy-and-move).
    # squadra_casa e mercato nascono NOT NULL: eventuali righe esistenti vengono
    # popolate con un valore segnaposto prima di applicare il vincolo, dato che non
    # c'è modo di ricostruire il dato da 'descrizione' in modo affidabile.
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.add_column(sa.Column('squadra_casa', sqlmodel.sql.sqltypes.AutoString(), nullable=True))
        batch_op.add_column(sa.Column('squadra_trasferta', sqlmodel.sql.sqltypes.AutoString(), nullable=True))
        batch_op.add_column(sa.Column('mercato', sqlmodel.sql.sqltypes.AutoString(), nullable=True))

    op.execute("UPDATE selezione SET squadra_casa = descrizione, mercato = '' WHERE squadra_casa IS NULL")

    with op.batch_alter_table('selezione') as batch_op:
        batch_op.alter_column('squadra_casa', nullable=False)
        batch_op.alter_column('mercato', nullable=False)
        batch_op.drop_column('descrizione')


def downgrade() -> None:
    with op.batch_alter_table('selezione') as batch_op:
        batch_op.add_column(sa.Column('descrizione', sa.VARCHAR(), nullable=True))

    op.execute("UPDATE selezione SET descrizione = squadra_casa || ' | ' || mercato")

    with op.batch_alter_table('selezione') as batch_op:
        batch_op.alter_column('descrizione', nullable=False)
        batch_op.drop_column('mercato')
        batch_op.drop_column('squadra_trasferta')
        batch_op.drop_column('squadra_casa')
