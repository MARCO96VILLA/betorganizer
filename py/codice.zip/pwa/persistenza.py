"""Backup, ripristino e snapshot del database (versione locale e passaggio dati dall'app con server).

Solo libreria standard (nessun thread né sottoprocesso): gira uguale in Python normale e in Pyodide.

Il **backup** è un archivio zip `.bettracker` con due file:

- `bet_tracker.db`: copia coerente del database (API di backup di SQLite, mai la copia del file a database aperto);
- `meta.json`: `{formato, schema, creato_il, app, conteggi, ...}`.

Regole che valgono per tutto il modulo:

- il database dell'utente non si modifica mai finché il file nuovo non è stato scritto e controllato: si scrive su un file
  temporaneo accanto all'originale e poi si rinomina (`os.replace`, atomico);
- prima di ogni sostituzione si fa uno snapshot automatico (`prima-del-ripristino`);
- ogni errore diventa un `ErroreBackup` con un messaggio in italiano pronto da mostrare, e il database resta com'era.

Chi chiama deve chiudere le proprie connessioni al database prima di `ripristina`/`ripristina_snapshot` e riaprirle dopo
(e, se `da_migrare` è vero, eseguire `alembic upgrade head`).
"""

from __future__ import annotations

import io
import json
import os
import re
import sqlite3
import tempfile
import zipfile
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

FORMATO = 1
APP = "bet-tracker"
ESTENSIONE = ".bettracker"
NOME_DB = "bet_tracker.db"
NOME_META = "meta.json"
NOME_ULTIMO_BACKUP = "ultimo_backup.json"
ETICHETTA_PRIMA_DEL_RIPRISTINO = "prima-del-ripristino"
MASSIMO_SNAPSHOT = 5
DIMENSIONE_MASSIMA_DB = 1024 * 1024 * 1024  # un database di scommesse personali è di pochi MB: oltre 1 GB è anomalo

_NOME_SNAPSHOT = re.compile(r"^(\d{8}T\d{12}Z)(?:-(\d+))?--([a-z0-9-]+)\.db$")


class ErroreBackup(Exception):
    """Errore con un messaggio in italiano già pronto per l'utente. `codice` distingue i casi per chi chiama."""

    def __init__(self, messaggio: str, codice: str = "errore"):
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.codice = codice


def _adesso() -> datetime:
    return datetime.now(timezone.utc)


# --- versioni dello schema -------------------------------------------------------------------------------------


def cartella_alembic() -> str:
    """Cartella che contiene `alembic/versions`: la radice del backend (Docker, sviluppo) o /srv (Pyodide)."""
    esplicita = os.environ.get("PWA_ALEMBIC_DIR")
    if esplicita:
        return esplicita
    radice = Path(__file__).resolve().parent.parent
    return str(radice if (radice / "alembic" / "versions").is_dir() else Path("/srv"))


def catena_schemi(cartella: Optional[str] = None) -> list[str]:
    """Versioni dello schema dalla più vecchia alla più nuova, lette dai file di migrazione (senza importare Alembic)."""
    versioni = Path(cartella or cartella_alembic()) / "alembic" / "versions"
    figlio_di: dict[Optional[str], str] = {}
    for file in versioni.glob("*.py"):
        testo = file.read_text(encoding="utf-8")
        revisione = re.search(r"""^revision\s*(?::[^=\n]+)?=\s*['"]([^'"]+)['"]""", testo, re.M)
        precedente = re.search(r"""^down_revision\s*(?::[^=\n]+)?=\s*(?:['"]([^'"]*)['"]|None)""", testo, re.M)
        if revisione:
            padre = precedente.group(1) if precedente and precedente.group(1) else None
            if padre in figlio_di:
                raise RuntimeError("Le migrazioni non sono una catena lineare")
            figlio_di[padre] = revisione.group(1)
    catena: list[str] = []
    corrente = figlio_di.get(None)
    while corrente is not None:
        catena.append(corrente)
        corrente = figlio_di.get(corrente)
    if not catena or len(catena) != len(figlio_di):
        raise RuntimeError("Le migrazioni non hanno una sola testa")
    return catena


def schema_testa(cartella: Optional[str] = None) -> str:
    return catena_schemi(cartella)[-1]


# --- piccoli strumenti su SQLite --------------------------------------------------------------------------------


def _apri(percorso: str) -> sqlite3.Connection:
    return sqlite3.connect(percorso, isolation_level=None)


def _integrita(connessione: sqlite3.Connection) -> bool:
    try:
        righe = connessione.execute("PRAGMA integrity_check").fetchall()
    except sqlite3.DatabaseError:
        return False
    return len(righe) == 1 and righe[0][0] == "ok"


def _schema_del_database(connessione: sqlite3.Connection) -> Optional[str]:
    try:
        riga = connessione.execute("SELECT version_num FROM alembic_version").fetchone()
    except sqlite3.DatabaseError:
        return None
    return riga[0] if riga else None


def _conta(connessione: sqlite3.Connection, tabella: str) -> int:
    try:
        return int(connessione.execute(f'SELECT COUNT(*) FROM "{tabella}"').fetchone()[0])
    except sqlite3.DatabaseError:
        return 0


def _conteggi(connessione: sqlite3.Connection) -> dict[str, int]:
    return {"schedine": _conta(connessione, "giocata"), "movimenti": _conta(connessione, "movimento_bankroll")}


def _scrivi_atomico(percorso: str, contenuto: bytes) -> None:
    temporaneo = percorso + ".tmp"
    try:
        with open(temporaneo, "wb") as f:
            f.write(contenuto)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporaneo, percorso)
    finally:
        if os.path.exists(temporaneo):
            os.remove(temporaneo)


# --- creazione del backup --------------------------------------------------------------------------------------


def _isola_utente(percorso: str, utente_id: int) -> None:
    """Toglie da una COPIA del database tutto ciò che non è dell'utente, poi compatta (così nel file non restano tracce).

    Gli id restano quelli originali. La password non viaggia: nella copia l'hash è sostituito da un segnaposto.
    """
    connessione = _apri(percorso)
    try:
        connessione.execute("BEGIN")
        sue_strategie = "SELECT id FROM strategia WHERE utente_id = ?"
        sue_giocate = "SELECT id FROM giocata WHERE utente_id = ?"
        sui_bankroll = "SELECT id FROM bankroll WHERE utente_id = ?"
        # le tabelle che dipendono da altre (senza `utente_id`) si svuotano per prime
        connessione.execute(f"DELETE FROM regola WHERE strategia_id NOT IN ({sue_strategie})", (utente_id,))
        connessione.execute(f"DELETE FROM configurazione_sistema WHERE giocata_id NOT IN ({sue_giocate})", (utente_id,))
        connessione.execute(f"DELETE FROM selezione WHERE giocata_id NOT IN ({sue_giocate})", (utente_id,))
        connessione.execute(f"DELETE FROM movimento_bankroll WHERE bankroll_id NOT IN ({sui_bankroll})", (utente_id,))
        # poi ogni tabella con `utente_id` (anche quelle che verranno aggiunte in futuro)
        tabelle = [r[0] for r in connessione.execute("SELECT name FROM sqlite_master WHERE type = 'table'")]
        for tabella in tabelle:
            colonne = [r[1] for r in connessione.execute(f'PRAGMA table_info("{tabella}")')]
            if "utente_id" in colonne:
                connessione.execute(f'DELETE FROM "{tabella}" WHERE utente_id != ?', (utente_id,))
        connessione.execute("DELETE FROM utente WHERE id != ?", (utente_id,))
        connessione.execute("UPDATE utente SET password_hash = '!'")
        connessione.execute("COMMIT")
        connessione.execute("VACUUM")
    except sqlite3.DatabaseError as errore:
        raise ErroreBackup("Non è stato possibile preparare la copia dei dati.", "copia") from errore
    finally:
        connessione.close()


def _timbra_schema(connessione: sqlite3.Connection, schema: str) -> None:
    """Un database creato senza Alembic (come nei test) non ha la tabella delle versioni: la si aggiunge nella copia."""
    connessione.execute("CREATE TABLE IF NOT EXISTS alembic_version (version_num VARCHAR(32) NOT NULL PRIMARY KEY)")
    if _schema_del_database(connessione) is None:
        connessione.execute("INSERT INTO alembic_version (version_num) VALUES (?)", (schema,))


def crea_backup_da_connessione(
    connessione: sqlite3.Connection,
    meta_extra: Optional[dict[str, Any]] = None,
    solo_utente_id: Optional[int] = None,
) -> bytes:
    """Come `crea_backup`, partendo da una connessione già aperta (il database può essere anche in memoria).

    Con `solo_utente_id` la copia contiene soltanto i dati di quell'utente (passaggio dall'app con server alla locale).
    """
    with tempfile.TemporaryDirectory() as cartella:
        copia = os.path.join(cartella, NOME_DB)
        try:
            destinazione = sqlite3.connect(copia)
            try:
                connessione.backup(destinazione)
            finally:
                destinazione.close()
        except sqlite3.Error as errore:
            raise ErroreBackup("Non è stato possibile copiare il database: il backup non è stato creato.", "copia") from errore
        if solo_utente_id is not None:
            _isola_utente(copia, solo_utente_id)
        verifica = _apri(copia)
        try:
            if not _integrita(verifica):
                raise ErroreBackup(
                    "Il database presenta errori: il backup non è stato creato. I tuoi dati non sono stati toccati.",
                    "integrita",
                )
            _timbra_schema(verifica, schema_testa())
            schema = _schema_del_database(verifica)
            conteggi = _conteggi(verifica)
        finally:
            verifica.close()
        meta = dict(meta_extra or {})
        meta.update(
            {
                "formato": FORMATO,
                "schema": schema,
                "creato_il": _adesso().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "app": APP,
                "conteggi": conteggi,
            }
        )
        uscita = io.BytesIO()
        with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as archivio:
            archivio.write(copia, NOME_DB)
            archivio.writestr(NOME_META, json.dumps(meta, ensure_ascii=False, indent=2))
        return uscita.getvalue()


def crea_backup(percorso_db: str, meta_extra: Optional[dict[str, Any]] = None) -> bytes:
    """Archivio `.bettracker` (bytes) con una copia coerente del database. Il database non viene modificato."""
    if not os.path.exists(percorso_db):
        raise ErroreBackup("Non c'è ancora nessun dato da salvare.", "assente")
    try:
        connessione = sqlite3.connect(percorso_db)
    except sqlite3.Error as errore:
        raise ErroreBackup("Non è stato possibile aprire il database: il backup non è stato creato.", "copia") from errore
    try:
        return crea_backup_da_connessione(connessione, meta_extra)
    finally:
        connessione.close()


# --- lettura e controllo di un backup ---------------------------------------------------------------------------


def _verdetto(esito: str, messaggio: str, **altro: Any) -> dict[str, Any]:
    """`valido` è vero solo se il file si può ripristinare (anche se prima va migrato: vedi `da_migrare`)."""
    base = {
        "valido": esito in ("valido", "da_migrare"),
        "esito": esito,
        "messaggio": messaggio,
        "da_migrare": esito == "da_migrare",
        "meta": None,
        "schema_backup": None,
        "schema_codice": None,
    }
    base.update(altro)
    return base


def _analizza(dati: bytes) -> tuple[dict[str, Any], Optional[bytes]]:
    """Controlla il file e, se è ripristinabile, restituisce anche i byte del database."""
    if not isinstance(dati, (bytes, bytearray)) or not zipfile.is_zipfile(io.BytesIO(dati)):
        return _verdetto("non_zip", "Questo file non è un backup di Bet Tracker (.bettracker)."), None
    try:
        archivio = zipfile.ZipFile(io.BytesIO(dati))
        nomi = set(archivio.namelist())
        if NOME_DB not in nomi or NOME_META not in nomi:
            return _verdetto("incompleto", "Il file non contiene i dati di un backup di Bet Tracker."), None
        if archivio.getinfo(NOME_DB).file_size > DIMENSIONE_MASSIMA_DB:
            return _verdetto("incompleto", "Il file è troppo grande per essere un backup di Bet Tracker."), None
        if archivio.testzip() is not None:
            return _verdetto("danneggiato", "Il file è danneggiato e non si può leggere. I tuoi dati non sono stati toccati."), None
        meta = json.loads(archivio.read(NOME_META).decode("utf-8"))
        contenuto = archivio.read(NOME_DB)
    except (zipfile.BadZipFile, zlib.error, OSError, ValueError, KeyError, NotImplementedError):
        return _verdetto("danneggiato", "Il file è danneggiato e non si può leggere. I tuoi dati non sono stati toccati."), None

    if not isinstance(meta, dict) or meta.get("app") != APP:
        return _verdetto("formato_sconosciuto", "Questo file non è un backup di Bet Tracker (.bettracker)."), None
    formato = meta.get("formato")
    if not isinstance(formato, int) or isinstance(formato, bool) or formato != FORMATO:
        return _verdetto(
            "formato_sconosciuto",
            "Questo backup ha un formato che questa versione dell'app non riconosce. "
            "Probabilmente è stato creato da una versione più recente: aggiorna l'app e riprova.",
            meta=meta,
        ), None

    with tempfile.TemporaryDirectory() as cartella:
        percorso = os.path.join(cartella, NOME_DB)
        with open(percorso, "wb") as f:
            f.write(contenuto)
        connessione = _apri(percorso)
        try:
            if not _integrita(connessione):
                return _verdetto(
                    "database_corrotto",
                    "Il database dentro il backup è danneggiato e non si può usare. I tuoi dati non sono stati toccati.",
                    meta=meta,
                ), None
            schema = _schema_del_database(connessione)
            meta["conteggi"] = _conteggi(connessione)
        finally:
            connessione.close()
    if schema is None:
        return _verdetto("database_corrotto", "Il backup non contiene un database di Bet Tracker riconoscibile.", meta=meta), None
    meta["schema"] = schema

    catena = catena_schemi()
    testa = catena[-1]
    comuni = {"meta": meta, "schema_backup": schema, "schema_codice": testa}
    if schema not in catena:
        return _verdetto(
            "schema_piu_nuovo",
            "Questo backup è stato creato da una versione più recente dell'app e non si può aprire con questa. "
            "Aggiorna l'app e riprova. I tuoi dati non sono stati toccati.",
            **comuni,
        ), None
    if schema != testa:
        return _verdetto(
            "da_migrare",
            "Questo backup è stato creato da una versione precedente dell'app: i dati verranno aggiornati dopo il ripristino.",
            **comuni,
        ), contenuto
    return _verdetto("valido", "Il backup è valido.", **comuni), contenuto


def leggi_backup(dati: bytes) -> dict[str, Any]:
    """Controlla un file `.bettracker` senza toccare nulla e restituisce un verdetto con `meta` e `messaggio`.

    `esito`: valido | da_migrare (valido, schema più vecchio) | non_zip | incompleto | danneggiato | formato_sconosciuto |
    database_corrotto | schema_piu_nuovo. `valido` è vero solo per i primi due.
    """
    return _analizza(dati)[0]


# --- sostituzione del database ----------------------------------------------------------------------------------


def _sostituisci_database(contenuto: bytes, percorso_db: str) -> None:
    """Scrive il nuovo database accanto all'originale, lo controlla e lo rinomina sopra: l'originale resta intatto se
    qualcosa va storto prima del rinomino."""
    temporaneo = percorso_db + ".ripristino.tmp"
    try:
        os.makedirs(os.path.dirname(os.path.abspath(percorso_db)), exist_ok=True)
        with open(temporaneo, "wb") as f:
            f.write(contenuto)
            f.flush()
            os.fsync(f.fileno())
        controllo = _apri(temporaneo)
        try:
            if not _integrita(controllo):
                raise ErroreBackup("Il database da ripristinare è danneggiato. I tuoi dati non sono stati toccati.", "database_corrotto")
        finally:
            controllo.close()
        os.replace(temporaneo, percorso_db)
    except ErroreBackup:
        raise
    except OSError as errore:
        raise ErroreBackup(
            "Non è stato possibile sostituire i dati (il database è in uso o lo spazio è finito). "
            "I tuoi dati non sono stati toccati.",
            "sostituzione",
        ) from errore
    finally:
        if os.path.exists(temporaneo):
            os.remove(temporaneo)
    for suffisso in ("-wal", "-shm", "-journal"):  # code di un database precedente non devono finire sul nuovo
        if os.path.exists(percorso_db + suffisso):
            os.remove(percorso_db + suffisso)


def ripristina(dati: bytes, percorso_db: str, cartella_snapshot: str) -> dict[str, Any]:
    """Sostituisce il database con quello del backup, dopo uno snapshot `prima-del-ripristino`.

    Solleva `ErroreBackup` (database invariato) se il file non è valido o se qualcosa va storto. Restituisce il verdetto
    di `leggi_backup` più `snapshot` (nome dello snapshot fatto, o None se non c'era ancora un database).
    """
    verdetto, contenuto = _analizza(dati)
    if not verdetto["valido"] or contenuto is None:
        raise ErroreBackup(verdetto["messaggio"], verdetto["esito"])
    snapshot = None
    if os.path.exists(percorso_db):
        snapshot = crea_snapshot(percorso_db, cartella_snapshot, ETICHETTA_PRIMA_DEL_RIPRISTINO)["nome"]
    _sostituisci_database(contenuto, percorso_db)
    return {**verdetto, "snapshot": snapshot}


# --- snapshot ---------------------------------------------------------------------------------------------------


def _etichetta_pulita(etichetta: str) -> str:
    pulita = re.sub(r"[^a-z0-9]+", "-", etichetta.lower()).strip("-")
    return pulita or "snapshot"


def _descrivi_snapshot(cartella: str, nome: str) -> Optional[dict[str, Any]]:
    trovato = _NOME_SNAPSHOT.match(nome)
    if not trovato:
        return None
    quando = datetime.strptime(trovato.group(1), "%Y%m%dT%H%M%S%fZ").replace(tzinfo=timezone.utc)
    percorso = os.path.join(cartella, nome)
    return {
        "nome": nome,
        "etichetta": trovato.group(3),
        "creato_il": quando.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "dimensione": os.path.getsize(percorso),
        "percorso": percorso,
    }


def elenco_snapshot(cartella: str) -> list[dict[str, Any]]:
    """Gli snapshot presenti, dal più recente al più vecchio."""
    if not os.path.isdir(cartella):
        return []
    voci = [v for v in (_descrivi_snapshot(cartella, n) for n in os.listdir(cartella)) if v]
    return sorted(voci, key=lambda v: (v["creato_il"], v["nome"]), reverse=True)


def crea_snapshot(
    percorso_db: str, cartella: str, etichetta: str, massimo: int = MASSIMO_SNAPSHOT
) -> dict[str, Any]:
    """Copia coerente del database in `cartella`. Per ogni etichetta si tengono gli ultimi `massimo` snapshot (così uno
    `prima-del-ripristino` non viene scalzato da quelli automatici)."""
    if not os.path.exists(percorso_db):
        raise ErroreBackup("Non c'è ancora nessun dato da salvare.", "assente")
    etichetta = _etichetta_pulita(etichetta)
    os.makedirs(cartella, exist_ok=True)
    marca = _adesso().strftime("%Y%m%dT%H%M%S%fZ")
    nome, n = f"{marca}--{etichetta}.db", 1
    while os.path.exists(os.path.join(cartella, nome)):
        nome, n = f"{marca}-{n}--{etichetta}.db", n + 1
    destinazione = os.path.join(cartella, nome)
    temporaneo = destinazione + ".tmp"
    try:
        sorgente = sqlite3.connect(percorso_db)
        try:
            copia = sqlite3.connect(temporaneo)
            try:
                sorgente.backup(copia)
            finally:
                copia.close()
        finally:
            sorgente.close()
        os.replace(temporaneo, destinazione)
    except (sqlite3.Error, OSError) as errore:
        raise ErroreBackup("Non è stato possibile fare la copia di sicurezza dei dati.", "snapshot") from errore
    finally:
        if os.path.exists(temporaneo):
            os.remove(temporaneo)
    for vecchio in [v for v in elenco_snapshot(cartella) if v["etichetta"] == etichetta][max(massimo, 1):]:
        os.remove(vecchio["percorso"])
    return _descrivi_snapshot(cartella, nome)


def ripristina_snapshot(nome: str, percorso_db: str, cartella: str) -> dict[str, Any]:
    """Rimette un vecchio snapshot al posto del database (prima ne fa uno nuovo, `prima-del-ripristino`)."""
    if os.path.basename(nome) != nome or not _NOME_SNAPSHOT.match(nome):
        raise ErroreBackup("Copia di sicurezza non trovata.", "assente")
    sorgente = os.path.join(cartella, nome)
    if not os.path.isfile(sorgente):
        raise ErroreBackup("Copia di sicurezza non trovata.", "assente")
    with open(sorgente, "rb") as f:
        contenuto = f.read()
    with tempfile.TemporaryDirectory() as controllo_dir:
        percorso = os.path.join(controllo_dir, NOME_DB)
        with open(percorso, "wb") as f:
            f.write(contenuto)
        connessione = _apri(percorso)
        try:
            if not _integrita(connessione):
                raise ErroreBackup("Questa copia di sicurezza è danneggiata e non si può usare.", "database_corrotto")
            schema = _schema_del_database(connessione)
        finally:
            connessione.close()
    catena = catena_schemi()
    if schema is None:
        raise ErroreBackup("Questa copia di sicurezza non contiene un database di Bet Tracker riconoscibile.", "database_corrotto")
    if schema not in catena:
        raise ErroreBackup(
            "Questa copia di sicurezza è stata creata da una versione più recente dell'app e non si può aprire con questa.",
            "schema_piu_nuovo",
        )
    snapshot = None
    if os.path.exists(percorso_db):
        snapshot = crea_snapshot(percorso_db, cartella, ETICHETTA_PRIMA_DEL_RIPRISTINO)["nome"]
    _sostituisci_database(contenuto, percorso_db)
    return {"snapshot": snapshot, "da_migrare": schema != catena[-1], "schema_backup": schema}


# --- promemoria "ultimo backup" ---------------------------------------------------------------------------------


def registra_ultimo_backup(cartella_dati: str, quando: Optional[datetime] = None) -> str:
    """Annota la data dell'ultimo backup scaricato (`ultimo_backup.json` nella cartella dei dati)."""
    quando = (quando or _adesso()).astimezone(timezone.utc)
    testo = quando.strftime("%Y-%m-%dT%H:%M:%SZ")
    os.makedirs(cartella_dati, exist_ok=True)
    _scrivi_atomico(
        os.path.join(cartella_dati, NOME_ULTIMO_BACKUP), json.dumps({"data": testo}).encode("utf-8")
    )
    return testo


def leggi_ultimo_backup(cartella_dati: str) -> Optional[datetime]:
    """Data dell'ultimo backup, o None se non ce n'è mai stato (o se il file è illeggibile)."""
    try:
        with open(os.path.join(cartella_dati, NOME_ULTIMO_BACKUP), encoding="utf-8") as f:
            testo = json.load(f)["data"]
        return datetime.strptime(testo, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except (OSError, ValueError, KeyError, TypeError):
        return None


def giorni_dall_ultimo_backup(cartella_dati: str, adesso: Optional[datetime] = None) -> Optional[int]:
    ultimo = leggi_ultimo_backup(cartella_dati)
    if ultimo is None:
        return None
    return max(((adesso or _adesso()) - ultimo).days, 0)


def frase_ultimo_backup(giorni: Optional[int]) -> str:
    """Riga neutra per Impostazioni: nessun incoraggiamento, nessun giudizio."""
    if giorni is None:
        return "Nessun backup ancora"
    if giorni == 0:
        return "Ultimo backup: oggi"
    if giorni == 1:
        return "Ultimo backup: ieri"
    return f"Ultimo backup: {giorni} giorni fa"
