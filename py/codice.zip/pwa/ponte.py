"""Avvio e ponte della versione locale (PWA): l'app FastAPI esistente, nel browser, con un solo utente.

Si usa così, dal Worker di Pyodide (vedi `docs/PIANO-PWA-LOCALE.md`):

    import pwa.ponte as ponte
    ponte.avvia("/data/bet_tracker.db")              # migra il database e prepara l'utente locale
    stato, intestazioni, corpo = await ponte.chiama("GET", "/api/giocate", ...)

Nessuna modifica all'app: qui si impostano solo l'ambiente, i thread (che nel browser non esistono) e la verifica
della sessione, sostituita dall'unico utente del dispositivo.
"""

from __future__ import annotations

import os
import re
import sqlite3
from urllib.parse import urlsplit

from pwa.asgi import chiama_asgi, correggi_thread

EMAIL_LOCALE = "locale@example.com"
NOME_LOCALE = "Io"
PERCORSO_ALEMBIC = os.environ.get("PWA_ALEMBIC_DIR", "/srv")

_app = None
_percorso_db = None
ETICHETTA_AUTOMATICA = "automatico"
ETICHETTA_MIGRAZIONE = "prima-della-migrazione"
INTERVALLO_AUTOMATICO_ORE = 24


def _imposta_ambiente(percorso_db: str) -> None:
    os.makedirs(os.path.dirname(percorso_db), exist_ok=True)
    os.environ["DATABASE_URL"] = f"sqlite:///{percorso_db}"
    # non servono: nella versione locale non ci sono né registrazione né sessioni
    os.environ.setdefault("INVITE_CODE", "locale")
    os.environ.setdefault("JWT_SECRET", "locale-non-usato-" + "x" * 32)


def schema_atteso(cartella: str = PERCORSO_ALEMBIC) -> str:
    """Ultima versione dello schema secondo le migrazioni del codice, senza importare Alembic (è lento all'avvio)."""
    cartella_versioni = os.path.join(cartella, "alembic", "versions")
    revisioni, precedenti = set(), set()
    for nome in os.listdir(cartella_versioni):
        if not nome.endswith(".py"):
            continue
        with open(os.path.join(cartella_versioni, nome), encoding="utf-8") as f:
            testo = f.read()
        revisione = re.search(r"""^revision\s*(?::[^=
]+)?=\s*['"]([^'"]+)['"]""", testo, re.M)
        precedente = re.search(r"""^down_revision\s*(?::[^=
]+)?=\s*(?:['"]([^'"]*)['"]|None)""", testo, re.M)
        if revisione:
            revisioni.add(revisione.group(1))
            if precedente and precedente.group(1):
                precedenti.add(precedente.group(1))
    teste = revisioni - precedenti
    if len(teste) != 1:
        raise RuntimeError(f"Le migrazioni non hanno una sola testa: {sorted(teste)}")
    return teste.pop()


def schema_corrente(percorso_db: str):
    """Versione dello schema del database dell'utente, o None se non esiste ancora."""
    if not os.path.exists(percorso_db):
        return None
    connessione = sqlite3.connect(percorso_db)
    try:
        return connessione.execute("SELECT version_num FROM alembic_version").fetchone()[0]
    except (sqlite3.OperationalError, TypeError):
        return None
    finally:
        connessione.close()


def migra(cartella: str = PERCORSO_ALEMBIC) -> str:
    """Porta il database alla versione dello schema del codice (`alembic upgrade head`)."""
    from alembic import command
    from alembic.config import Config

    configurazione = Config(os.path.join(cartella, "alembic.ini"))
    configurazione.set_main_option("script_location", os.path.join(cartella, "alembic"))
    command.upgrade(configurazione, "head")
    from alembic.script import ScriptDirectory

    return ScriptDirectory.from_config(configurazione).get_current_head()


def garantisci_utente_locale() -> int:
    """Crea (la prima volta) l'unico utente del dispositivo con il suo bankroll; restituisce il suo id."""
    from sqlmodel import Session, select

    from app.db import engine
    from app.models import Bankroll, Utente

    with Session(engine) as sessione:
        utente = sessione.exec(select(Utente)).first()
        if utente is None:
            utente = Utente(email=EMAIL_LOCALE, password_hash="!", nome=NOME_LOCALE)
            sessione.add(utente)
            sessione.commit()
            sessione.refresh(utente)
            sessione.add(Bankroll(utente_id=utente.id, nome="Principale"))
            sessione.commit()
        return utente.id


def avvia(percorso_db: str = "/data/bet_tracker.db") -> dict:
    """Prepara tutto e restituisce un riepilogo (versione dello schema, id dell'utente)."""
    global _app, _percorso_db
    from pwa import persistenza

    correggi_thread()
    _imposta_ambiente(percorso_db)
    _percorso_db = percorso_db
    versione = schema_atteso()
    corrente = schema_corrente(percorso_db)
    if corrente != versione:
        if corrente is not None:
            # prima di aggiornare lo schema di dati veri si fa sempre una copia di sicurezza
            persistenza.crea_snapshot(percorso_db, _cartella_snapshot(), ETICHETTA_MIGRAZIONE)
        migra()  # database nuovo o da aggiornare; se è già all'ultima versione si salta (risparmia secondi)
    utente_id = garantisci_utente_locale()
    _snapshot_automatico()

    import fastapi
    from sqlmodel import Session, select

    from app.auth import get_current_user
    from app.db import get_session
    from app.main import app
    from app.models import Utente

    def utente_locale(sessione: Session = fastapi.Depends(get_session)) -> Utente:
        return sessione.exec(select(Utente)).first()

    app.dependency_overrides[get_current_user] = utente_locale
    from pwa import ocr_browser

    ocr_browser.installa(app)  # la lettura degli screenshot usa tesseract.js nel browser
    _app = app
    return {"schema": versione, "utente_id": utente_id}


async def chiama(metodo: str, percorso: str, intestazioni=None, corpo: bytes = b""):
    """Esegue una richiesta (percorso con eventuale query) sull'app e restituisce (status, intestazioni, corpo)."""
    if _app is None:
        raise RuntimeError("Il motore locale non è stato avviato")
    parti = urlsplit(percorso)
    return await chiama_asgi(_app, metodo, parti.path, parti.query, intestazioni, corpo)


async def chiama_js(metodo, percorso, intestazioni, corpo):
    """Come `chiama`, ma con i tipi che arrivano da JavaScript (Worker): intestazioni come lista di coppie e corpo
    come Uint8Array; restituisce un dizionario {status, headers, body} con il corpo in bytes."""
    # il null di JavaScript arriva come un oggetto speciale (JsNull), non come None
    coppie = [tuple(c) for c in intestazioni.to_py()] if hasattr(intestazioni, "to_py") else []
    dati = corpo.to_bytes() if hasattr(corpo, "to_bytes") else b""
    stato, header, risposta = await chiama(metodo, percorso, coppie, dati)
    return {"status": stato, "headers": header, "body": risposta}


# --- copie di sicurezza, backup e ripristino -------------------------------------------------------------------


def _cartella_dati() -> str:
    return os.path.dirname(_percorso_db)


def _cartella_snapshot() -> str:
    return os.path.join(_cartella_dati(), "snapshot")


def _snapshot_automatico() -> None:
    """Una copia automatica al giorno (se non ce n'è già una recente); se ne tengono le ultime 5."""
    from datetime import datetime, timedelta, timezone

    from pwa import persistenza

    recenti = [v for v in persistenza.elenco_snapshot(_cartella_snapshot()) if v["etichetta"] == ETICHETTA_AUTOMATICA]
    if recenti:
        ultima = datetime.strptime(recenti[0]["creato_il"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - ultima < timedelta(hours=INTERVALLO_AUTOMATICO_ORE):
            return
    persistenza.crea_snapshot(_percorso_db, _cartella_snapshot(), ETICHETTA_AUTOMATICA)


def info_dati() -> dict:
    """Per Impostazioni: quando è stato fatto l'ultimo backup e quali copie automatiche ci sono."""
    from pwa import persistenza

    giorni = persistenza.giorni_dall_ultimo_backup(_cartella_dati())
    copie = [
        {k: v for k, v in copia.items() if k != "percorso"}
        for copia in persistenza.elenco_snapshot(_cartella_snapshot())
    ]
    return {"ultimo_backup_giorni": giorni, "frase": persistenza.frase_ultimo_backup(giorni), "copie": copie}


def registra_backup() -> dict:
    from pwa import persistenza

    persistenza.registra_ultimo_backup(_cartella_dati())
    return info_dati()


def verifica_backup(dati: bytes) -> dict:
    """Controlla un file `.bettracker` senza toccare nulla (per mostrare cosa contiene prima di ripristinare)."""
    from pwa import persistenza

    return persistenza.leggi_backup(dati)


def _riapri_dopo(operazione) -> dict:
    """Esegue un ripristino con il database chiuso e poi riavvia il motore (migrazione compresa se serve)."""
    from app.db import engine
    from pwa import persistenza

    engine.dispose()
    try:
        risultato = operazione()
        esito = {"ok": True, **{k: v for k, v in risultato.items() if k not in ("percorso",)}}
    except persistenza.ErroreBackup as errore:
        esito = {"ok": False, "messaggio": str(errore)}
    finally:
        avvia(_percorso_db)
    return esito


def ripristina_backup(dati: bytes) -> dict:
    from pwa import persistenza

    return _riapri_dopo(lambda: persistenza.ripristina(dati, _percorso_db, _cartella_snapshot()))


def ripristina_copia(nome: str) -> dict:
    from pwa import persistenza

    return _riapri_dopo(lambda: persistenza.ripristina_snapshot(nome, _percorso_db, _cartella_snapshot()))


def verifica_backup_js(corpo) -> dict:
    return verifica_backup(corpo.to_bytes())


def ripristina_backup_js(corpo) -> dict:
    return ripristina_backup(corpo.to_bytes())
