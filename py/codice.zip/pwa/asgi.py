"""Chiama l'app FastAPI direttamente (protocollo ASGI), senza rete e senza thread.

Serve alla versione locale (PWA), dove l'app gira nel browser dentro Pyodide: il frontend manda la richiesta al Worker,
che la passa qui. È anche la base del client di test usato da pytest dentro Pyodide (`cliente_asgi.py`).
"""

from __future__ import annotations

import anyio.to_thread

SERVER = ("locale", 80)


async def _esegui_in_linea(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
    return func(*args)


def correggi_thread() -> None:
    """Nel browser non esistono i thread, che FastAPI usa per le funzioni normali: le si esegue in linea."""
    anyio.to_thread.run_sync = _esegui_in_linea


async def chiama_asgi(app, metodo: str, percorso: str, query: str = "", intestazioni=None, corpo: bytes = b""):
    """Restituisce (status, intestazioni come lista di coppie di testo, corpo in bytes)."""
    header = [(b"host", b"locale")]
    for nome, valore in intestazioni or []:
        header.append((nome.lower().encode("latin-1"), valore.encode("latin-1")))
    scope = {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": metodo.upper(),
        "scheme": "http",
        "path": percorso,
        "raw_path": percorso.encode(),
        "query_string": query.encode(),
        "root_path": "",
        "headers": header,
        "client": ("127.0.0.1", 0),
        "server": SERVER,
    }
    inviato = False

    async def receive():
        nonlocal inviato
        if not inviato:
            inviato = True
            return {"type": "http.request", "body": corpo, "more_body": False}
        return {"type": "http.disconnect"}

    risposta = {"status": 500, "intestazioni": [], "corpo": bytearray()}

    async def send(messaggio):
        if messaggio["type"] == "http.response.start":
            risposta["status"] = messaggio["status"]
            risposta["intestazioni"] = [(k.decode("latin-1"), v.decode("latin-1")) for k, v in messaggio["headers"]]
        elif messaggio["type"] == "http.response.body":
            risposta["corpo"].extend(messaggio.get("body", b""))

    await app(scope, receive, send)
    return risposta["status"], risposta["intestazioni"], bytes(risposta["corpo"])
