"""Motore OCR della versione locale (PWA): Python chiede il testo a tesseract.js, che gira in JavaScript.

Perché un protocollo a due tempi. Python nel browser (Pyodide) è sincrono: non ha thread e non può aspettare una
risposta di JavaScript nel mezzo di una funzione. Allora il motore, quando non ha il testo di un'immagine, **interrompe**
la richiesta con `DaEseguire`; JavaScript legge l'immagine con tesseract.js e **ripete la stessa richiesta** portando
con sé il testo ottenuto. Python ricomincia da capo, trova il testo e va avanti (fino al prossimo che manca). Tutta la
logica resta in Python e identica al server: preparazione dell'immagine (`ocr.prepara_immagine`), righe dal TSV,
parser e **due tentativi** (gamma normale e gamma alternativa, `scegli_lettura`) in `services/lettura_screenshot.py`.

Il protocollo, a livello HTTP (così il ponte e il trasporto della Fase 2 non devono sapere nulla di OCR):

1. Richiesta: `POST /api/lettura/schedine`, multipart con uno o più `file` e, facoltativo, il campo `ocr_testi`
   = JSON `{"<chiave>": "<TSV di Tesseract>", ...}` (all'inizio assente).
2. Se manca un testo, la risposta è **202** con `content-type: image/png`: il corpo è il PNG già preparato, le
   intestazioni `x-ocr-chiave` (identifica quella lettura) e `x-ocr-gamma` (solo informativa). Non è un errore e
   non contiene dati da mostrare.
3. JavaScript legge il PNG con tesseract.js (lingua `ita`, `--psm 6`, uscita TSV), aggiunge `{chiave: tsv}` a `ocr_testi`
   e **ripete la stessa richiesta** (stessi file). Si ripete finché la risposta non è un 200 con le bozze (di norma
   2 o 3 giri per screenshot: la lettura normale e, se ha avvisi, quella alternativa). Un 200 contiene `schedine`,
   esattamente come sul server.

`chiave` = prime 16 cifre dello SHA-256 dei byte del file + `:` + gamma (es. `3fa2…:2.0`): dipende dal file originale e
non dall'immagine preparata, così con il testo già in mano Python non rifà nemmeno la preparazione. Più file nella stessa
richiesta funzionano (le chiavi sono diverse) e il controllo dei doppioni nello stesso caricamento resta quello del server.
Il client JS è `frontend/src/locale/ocr/leggiScreenshot.js`.

Collegamento (Fase 2): all'avvio del motore, dopo `from app.main import app`, chiamare `ocr_browser.installa(app)`.
Nessun dato lascia il dispositivo e nessuna immagine viene conservata: il PNG vive solo nella risposta.
"""

from __future__ import annotations

import hashlib

from app.services import ocr

CONTENT_TYPE_RICHIESTA = "image/png"
STATUS_RICHIESTA = 202


def chiave_lettura(contenuto: bytes, gamma: float) -> str:
    """Identifica la lettura di un file con una data preparazione (vedi il protocollo nella docstring del modulo)."""
    return f"{hashlib.sha256(contenuto).hexdigest()[:16]}:{gamma}"


class MotoreBrowser(ocr.MotoreOcr):
    """Cerca il testo tra quelli già letti da JavaScript; se manca, interrompe con `DaEseguire`."""

    def disponibile(self) -> bool:
        return True

    def tsv(self, contenuto: bytes, gamma: float) -> str:
        chiave = chiave_lettura(contenuto, gamma)
        letto = ocr.letture_esterne().get(chiave)
        if letto is not None:
            return letto
        # la preparazione può già dare ErroreLettura (file che non è un'immagine): in quel caso non serve JavaScript
        raise ocr.DaEseguire(chiave, ocr.png_preparato(contenuto, gamma), gamma)


async def _gestore(_richiesta, errore: ocr.DaEseguire):
    from fastapi.responses import Response

    return Response(
        content=errore.png,
        status_code=STATUS_RICHIESTA,
        media_type=CONTENT_TYPE_RICHIESTA,
        headers={"x-ocr-chiave": errore.chiave, "x-ocr-gamma": str(errore.gamma), "cache-control": "no-store"},
    )


def installa(app) -> None:
    """Sostituisce il motore OCR con quello del browser e registra la risposta 202 del primo tempo."""
    ocr.imposta_motore(MotoreBrowser())
    app.add_exception_handler(ocr.DaEseguire, _gestore)
