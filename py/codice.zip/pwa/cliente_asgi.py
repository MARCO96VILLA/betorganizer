"""Client di test con la stessa interfaccia essenziale di `TestClient`, ma senza thread: gira dentro Pyodide.

`TestClient` di Starlette usa un thread per eseguire l'app, impossibile nel browser. Questo client chiama l'app via
ASGI (`asgi.py`) e fa avanzare la coroutine a mano: tutto avviene in linea, senza attese reali.
"""

from __future__ import annotations

import json as json_lib
import uuid
from http.cookies import SimpleCookie
from urllib.parse import urlencode, urlsplit

from starlette.datastructures import Headers

from pwa.asgi import chiama_asgi, correggi_thread


def esegui(coroutine):
    """Porta a termine una coroutine che non si sospende mai davvero (tutto è in linea)."""
    try:
        while True:
            sospeso = coroutine.send(None)
            if sospeso is not None:
                raise RuntimeError(f"La richiesta si è messa in attesa di qualcosa di reale: {sospeso!r}")
    except StopIteration as fine:
        return fine.value


def costruisci_multipart(files, data=None):
    """Corpo `multipart/form-data` da una lista di (campo, (nome, contenuto, tipo)) e dati semplici."""
    confine = uuid.uuid4().hex
    parti = []
    for campo, valore in (data or {}).items():
        parti.append(
            (f'--{confine}\r\nContent-Disposition: form-data; name="{campo}"\r\n\r\n').encode() + str(valore).encode() + b"\r\n"
        )
    elenco = files.items() if isinstance(files, dict) else files
    for campo, (nome, contenuto, tipo) in elenco:
        if isinstance(contenuto, str):
            contenuto = contenuto.encode()
        testa = f'--{confine}\r\nContent-Disposition: form-data; name="{campo}"; filename="{nome}"\r\nContent-Type: {tipo}\r\n\r\n'
        parti.append(testa.encode() + contenuto + b"\r\n")
    parti.append(f"--{confine}--\r\n".encode())
    return b"".join(parti), f"multipart/form-data; boundary={confine}"


class RispostaAsgi:
    def __init__(self, status, intestazioni, corpo):
        self.status_code = status
        self.headers = Headers(raw=[(k.lower().encode("latin-1"), v.encode("latin-1")) for k, v in intestazioni])
        self.content = corpo

    @property
    def text(self):
        return self.content.decode("utf-8", errors="replace")

    def json(self):
        return json_lib.loads(self.content)


class ClienteAsgi:
    def __init__(self, app):
        correggi_thread()
        self.app = app
        self.cookies = {}

    def request(self, metodo, url, params=None, json=None, files=None, data=None, headers=None):
        parti = urlsplit(url)
        query = parti.query
        if params:
            query = "&".join(filter(None, [query, urlencode(params, doseq=True)]))
        intestazioni = list((headers or {}).items())
        corpo = b""
        if files:
            corpo, tipo = costruisci_multipart(files, data)
            intestazioni.append(("content-type", tipo))
        elif json is not None:
            corpo = json_lib.dumps(json).encode()
            intestazioni.append(("content-type", "application/json"))
        if self.cookies:
            intestazioni.append(("cookie", "; ".join(f"{k}={v}" for k, v in self.cookies.items())))
        status, risposta_headers, risposta_corpo = esegui(
            chiama_asgi(self.app, metodo, parti.path, query, intestazioni, corpo)
        )
        for nome, valore in risposta_headers:
            if nome.lower() == "set-cookie":
                biscotto = SimpleCookie()
                biscotto.load(valore)
                for chiave, morsello in biscotto.items():
                    if morsello.value in ("", '""') or morsello["max-age"] == "0":
                        self.cookies.pop(chiave, None)
                    else:
                        self.cookies[chiave] = morsello.value
        return RispostaAsgi(status, risposta_headers, risposta_corpo)

    def get(self, url, **kwargs):
        return self.request("GET", url, **kwargs)

    def post(self, url, **kwargs):
        return self.request("POST", url, **kwargs)

    def put(self, url, **kwargs):
        return self.request("PUT", url, **kwargs)

    def patch(self, url, **kwargs):
        return self.request("PATCH", url, **kwargs)

    def delete(self, url, **kwargs):
        return self.request("DELETE", url, **kwargs)
